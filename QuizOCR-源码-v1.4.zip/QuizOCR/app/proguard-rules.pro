# ML Kit：模型加载与组件注册使用反射，需整体保留
-keep class com.google.mlkit.** { *; }
-keep class com.google.android.gms.** { *; }

# CameraX：Provider / CameraSelector 通过反射与类名加载，保留包内类名
-keep class androidx.camera.** { *; }

# 应用组件（Activity / Service）在 Manifest 中声明，保留名称与构造方法
-keep class com.example.quizocr.MainActivity { *; }
-keep class com.example.quizocr.RegionPickerActivity { *; }
-keep class com.example.quizocr.CapturePermissionActivity { *; }
-keep class com.example.quizocr.FloatWindowService { *; }
-keep class com.example.quizocr.ScreenCaptureService { *; }
-keep class com.example.quizocr.QuizAccessibilityService { *; }
