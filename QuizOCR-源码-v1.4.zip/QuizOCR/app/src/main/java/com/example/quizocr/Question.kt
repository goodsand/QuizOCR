package com.example.quizocr

/**
 * 题库中的一道题。
 * @param prompt  题目
 * @param answer  答案
 * @param options 选项内容，按 A、B、C… 顺序排列（数量不限，支持 A~F 甚至更多）
 */
data class Question(
    val prompt: String,
    val answer: String,
    val options: List<String>
) {
    /** 带字母标签的选项，例如 [("A" to "..."), ("B" to "...")] */
    fun labeledOptions(): List<Pair<String, String>> =
        options.mapIndexed { index, text -> (('A' + index).toString()) to text }
}
