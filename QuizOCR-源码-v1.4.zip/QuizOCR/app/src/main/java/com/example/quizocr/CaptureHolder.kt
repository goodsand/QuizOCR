package com.example.quizocr

import android.graphics.Bitmap

/**
 * 悬浮窗与「识别区域设置」页之间的截图传递容器。
 * Bitmap 体积大，不适合通过 Intent 传递，改用同进程单例共享。
 */
object CaptureHolder {
    @Volatile
    var bitmap: Bitmap? = null
}
