package com.example.quizocr

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.graphics.Rect
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.Toast
import androidx.appcompat.view.ContextThemeWrapper
import androidx.core.app.NotificationCompat
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.quizocr.databinding.FloatBallBinding
import com.example.quizocr.databinding.FloatPanelBinding
import java.util.concurrent.Executors
import kotlin.math.abs

/**
 * 悬浮窗服务（前台服务，保证切到其它应用后小球仍在）。
 *
 * 结构为两个独立窗口，互不干扰下层应用：
 * - 小球窗口：68dp 圆形按钮，可拖动，只覆盖自身区域；
 * - 结果面板窗口：深色半透明，可拖动移动、右下角拖动缩放，内置关键词搜索，
 *   复用 [BankAdapter] 展示匹配题目并高亮正确答案。
 *
 * 稳定性要点：
 * - 所有视图创建/添加均做异常保护，任一步失败只提示原因，**不会让服务崩溃（小球消失）**；
 * - 面板高度限制为屏幕 45%，弹出时若会盖住小球，则自动把小球上移；
 * - 题库匹配放到子线程，避免题目量大时阻塞主线程。
 */
class FloatWindowService : Service() {

    companion object {
        const val ACTION_STOP = "com.example.quizocr.action.STOP_FLOAT"

        private const val CHANNEL_ID = "quiz_float_window"
        private const val NOTIFICATION_ID = 20261

        /** 小球直径（dp），需与 float_ball.xml 一致，拖动边界依赖它 */
        private const val BALL_SIZE_DP = 68

        /** 面板最小尺寸（dp），缩放时不允许小于它 */
        private const val PANEL_MIN_W_DP = 240
        private const val PANEL_MIN_H_DP = 160

        /** 小球是否已成功显示；供主界面判断，避免重复启动 */
        @Volatile
        var isRunning = false
            private set

        /** 实时模式下，检测到「文字没命中」后等页面静止多久再走截屏兜底 */
        private const val REALTIME_OCR_IDLE_MS = 900L

        /** 实时 OCR 的最小间隔：再快会让面板反复隐藏，观感很差 */
        private const val REALTIME_OCR_MIN_INTERVAL_MS = 3000L

        /**
         * 兜底最多等多久。
         *
         * 页面一直有小动画 / 计时器时，「等画面静止」可能永远等不到；
         * 超过这个时间就强行截一次，宁可截到一帧过渡画面，也不能让兜底彻底不触发。
         */
        private const val REALTIME_FALLBACK_MAX_WAIT_MS = 2500L

        /** 看门狗的最大间隔：页面一直没结果时，最慢 15 秒主动采一次 */
        private const val WATCHDOG_MAX_MS = 15000L

        /** 看门狗在“已经有结果”时的节拍：换题后最多这么久刷新一次 */
        private const val WATCHDOG_HAS_RESULT_MS = 4000L

        /** 「一个字都没读到」的占位哈希，与正常文本区分 */
        private const val EMPTY_HASH = Int.MIN_VALUE
    }

    private lateinit var windowManager: WindowManager
    private var ballBinding: FloatBallBinding? = null
    private var panelBinding: FloatPanelBinding? = null
    private val adapter = BankAdapter()
    private val mainHandler = Handler(Looper.getMainLooper())

    /** 本次识别中得分最高的那一行，用于回填搜索框 */
    @Volatile
    private var bestQueryLine = ""

    /** 本次识别到的原始文字，作为搜索框的兜底内容 */
    @Volatile
    private var lastRecognizedRaw = ""

    /** 上一次 OCR 的截图指纹（8×8 灰度均值哈希）与结果，用于「同一画面不重复识别」 */
    @Volatile
    private var lastOcrFingerprint = 0L

    @Volatile
    private var lastOcrLines: List<String> = emptyList()

    // ---------------- 实时识屏状态 ----------------

    /** 实时是否正在跑（等价于：开关打开 + 面板可见 + 无障碍已连接） */
    @Volatile
    private var realtimeOn = false

    /** 上次实时处理的文字指纹；文字没变就什么都不做 */
    private var lastRealtimeHash = 0

    /**
     * 上次「页面文字真的变了」的时间，用于判断画面是否已经静止。
     *
     * 只由**内容变化**更新，事件本身不更新：不少页面（WebView 动画、计时器、
     * 轮播广告）每秒抛几十次 content-changed，若按事件计时，页面永远不算静止，
     * 截屏兜底就永远不会触发 —— 这是「兜底没生效」的根因之一。
     */
    @Volatile
    private var lastRealtimeContentAt = 0L

    /** 上次实时 OCR 的时间，用于限频 */
    private var lastRealtimeOcrAt = 0L

    private var lastRealtimeTop: String? = null

    /** 页面代次：切页 / 滚动后 +1，让新画面可以重新兜底一次 */
    private var pageGeneration = 0

    /** 这一屏的兜底指纹（文字指纹 + 页面代次），等待被 OCR 消费 */
    private var pendingFallbackKey: String? = null

    /** 已经对哪一屏做过 OCR 兜底；同一屏不重复截屏 */
    private var lastFallbackKey: String? = null

    /** 本次兜底的触发原因，只用于状态行文案 */
    private var fallbackReason: String = ""

    /** 本次兜底最早是什么时候被要求的，用于「等太久就强行截屏」 */
    private var fallbackRequestedAt = 0L

    /**
     * 最近一次无障碍采集完成的时间。
     *
     * 每次采集（哪怕文字没变）都会刷新它：这是判断「上一屏之后界面又动过没有」
     * 的唯一依据。很多题目页换题只抛 content-changed、不换窗口也不滚动，
     * 只看页面代次/res文字指纹的话，第二题之后就再也兜不了底。
     */
    private var lastScanAt = 0L

    /** 上一次真正执行兜底时的 [lastScanAt]，用来判断之后界面是否又变过 */
    private var lastFallbackScanAt = 0L

    /**
     * 实时通道的水槽：只接收文字，不直接跑 OCR。
     *
     * 匹配放子线程；OCR 兜底延迟到「页面静止」再触发，
     * 否则每 300ms 变一次画面就截一次屏，面板会不停闪。
     */
    private val realtimeSink = object : RealtimeHub.Sink {
        override fun onRealtimeText(text: String, inRegion: Boolean) {
            // 回调来自采集线程，这里立刻切主线程：后面要读 View 的焦点状态，
            // 并且去重判断必须串行，否则两次采集可能同时通过
            mainHandler.post {
                if (!realtimeOn || !panelAdded) return@post
                // 用户正在搜索框里打字：暂停自动刷新，否则刚输入的内容会被实时结果顶掉
                if (panelBinding?.etSearch?.hasFocus() == true) return@post
                lastScanAt = SystemClock.elapsedRealtime()
                val hash = text.hashCode()
                if (hash == lastRealtimeHash) {
                    // 文字没变，但界面又发生了一次采集（换题、弹层、局部刷新）：
                    // 上一屏的兜底结论可能已经过期，允许再兜一次（受 3s 限频）。
                    // 这里**不能**用「已有结果」当挡箭牌：无障碍读不到题干时，
                    // 换题前后文字完全相同，正是这种情况导致面板停在第一题不再变化。
                    requestRealtimeFallback("无障碍文字未命中", text)
                    return@post
                }
                lastRealtimeHash = hash
                lastRealtimeContentAt = SystemClock.elapsedRealtime()
                renderRealtime(text)
                // 文字变了说明换了内容：看门狗回到最快节拍，尽快确认新画面
                watchdogIntervalMs = 3000L
                mainHandler.removeCallbacks(watchdogRunnable)
                mainHandler.postDelayed(watchdogRunnable, watchdogIntervalMs)
            }
        }

        override fun onRealtimeEmpty() {
            mainHandler.post {
                if (!realtimeOn || !panelAdded) return@post
                if (panelBinding?.etSearch?.hasFocus() == true) return@post
                lastScanAt = SystemClock.elapsedRealtime()
                // 重复的空事件不代表画面变了，不能刷新「静止」计时，
                // 否则一个带空节点动画的页面会让兜底永远等不到静止
                if (lastRealtimeHash == EMPTY_HASH) {
                    // 依旧是空内容，但界面被采过：可能已经翻到下一题（WebView 里换题不换窗口）。
                    // 同上，不能因为「已经有结果」就不再兜底，否则第二题永远不刷新
                    requestRealtimeFallback("框内没有可读文字", "")
                    return@post
                }
                lastRealtimeHash = EMPTY_HASH
                lastRealtimeContentAt = SystemClock.elapsedRealtime()
                requestRealtimeFallback("框内没有可读文字", "")
            }
        }

        override fun onRealtimeUnavailable() {
            mainHandler.post {
                if (!realtimeOn) return@post
                stopRealtime()
                panelBinding?.let {
                    it.tvStatus.text = "实时已暂停 · 无障碍未连接"
                    it.tvStatus.setOnClickListener { openAccessibilitySettings() }
                }
            }
        }

        override fun onRealtimePageChanged() {
            mainHandler.post {
                if (!realtimeOn) return@post
                // 换了一屏：上一屏「已经兜过底 / 没匹配到」的结论作废；
                // 文字指纹也清零，这样即便两屏文字完全相同也会重新处理一次
                pageGeneration++
                lastRealtimeHash = 0
                // 新画面：看门狗回到最快节拍
                watchdogIntervalMs = 3000L
            }
        }
    }

    /** 实时匹配线程：文字变化可能很频繁，固定一个线程比每次 new Thread 稳 */
    private val matchExecutor = Executors.newSingleThreadExecutor { r ->
        Thread(r, "realtime-match").apply { isDaemon = true }
    }

    /** 实时模式下延迟触发的 OCR 兜底 */
    private val realtimeOcrRunnable = Runnable { runRealtimeOcr() }

    /**
     * 兜底看门狗：没匹配到结果时，每隔几秒主动采一次当前画面。
     *
     * 为什么必须有它：兜底原本完全依赖无障碍事件驱动，而有些题目页（WebView、
     * 自定义渲染）换题时**一个事件都不抛**。这种情况下第一次兜底之后，
     * 第二题就再也不会触发 —— 表现就是「截屏兜底只执行了一次」。
     * 看门狗用固定节拍补上这个空档，间隔按 3→4.5→…→15 秒退避，匹配到结果即停。
     */
    private var watchdogIntervalMs = 3000L
    private val watchdogRunnable = Runnable { runWatchdog() }

    private fun startWatchdog() {
        if (!realtimeOn) return
        mainHandler.removeCallbacks(watchdogRunnable)
        watchdogIntervalMs = 3000L
        mainHandler.postDelayed(watchdogRunnable, watchdogIntervalMs)
    }

    private fun stopWatchdog() {
        mainHandler.removeCallbacks(watchdogRunnable)
    }

    private fun runWatchdog() {
        if (!realtimeOn || !panelAdded) return

        // 关键：**不管当前有没有结果都要采**。
        // 之前这里「已有结果就不再采集」，而无障碍换题不抛事件时，
        // 第一次命中之后就再没有新的采集 → 面板永远停在第一题的结果上。
        ScreenTextHolder.service?.requestRealtimeScan()

        watchdogIntervalMs = if (lastRealtimeTop != null) {
            // 已有结果：按较慢的节拍守着，换题后最多这么久刷新
            WATCHDOG_HAS_RESULT_MS
        } else {
            // 一直没有结果：慢慢退避，避免在「题库没有这道题」的页面高频截屏
            (watchdogIntervalMs * 3 / 2).coerceIn(3000L, WATCHDOG_MAX_MS)
        }
        mainHandler.postDelayed(watchdogRunnable, watchdogIntervalMs)
    }

    /** 设置页切换「实时识屏」时同步启停 */
    private val realtimeModeListener: (Boolean) -> Unit = { on ->
        if (on && panelAdded) startRealtime() else stopRealtime()
    }

    private lateinit var ballParams: WindowManager.LayoutParams
    private lateinit var panelParams: WindowManager.LayoutParams
    private var panelAdded = false

    /** 实时期间小球是否处于隐藏状态（隐藏用 GONE + NOT_TOUCHABLE，不是 removeView） */
    private var ballHidden = false

    /** 服务正在销毁：此时不要再把小球挂回去 */
    private var shuttingDown = false

    private var downX = 0
    private var downY = 0
    private var startX = 0
    private var startY = 0
    private var moved = false
    /** 本次按下是否已触发长按（长按=收起面板），用于避免抬起时又触发一次识别 */
    private var longPressed = false

    /** 长按小球：收起结果面板（点击小球则是识别/刷新，两者职责分开） */
    private val longPressAction = Runnable {
        longPressed = true
        hidePanel()
    }

    override fun onCreate() {
        super.onCreate()
        // 必须尽快进入前台，否则系统会判定服务超时
        promoteToForeground()

        try {
            QuestionBankRepository.load(this)
            MatchThreshold.load(this)
            ResultTextSize.load(this)
            ResultTextSize.addListener(textSizeListener)
            MatchMode.load(this)
            RealtimeMode.load(this)
            RealtimeMode.addListener(realtimeModeListener)
        } catch (_: Throwable) {
            // 题库/设置加载失败不影响悬浮窗本身
        }

        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager

        // 预热 OCR 模型：首次识别要加载约 10MB 模型（300~800ms），
        // 悬浮窗一开就后台加载，避免第一次识屏慢一大截
        try {
            OcrHelper.warmUp()
        } catch (_: Throwable) {
            // 预热失败不影响正常识别
        }

        val ball = try {
            FloatBallBinding.inflate(LayoutInflater.from(themedContext()))
        } catch (t: Throwable) {
            toast("悬浮球布局加载失败：${t.javaClass.simpleName}")
            stopSelf()
            return
        }
        ballBinding = ball

        ballParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(16)
            y = dp(180)
        }

        try {
            windowManager.addView(ball.root, ballParams)
            isRunning = true
            setupBallTouch(ball)
        } catch (t: Throwable) {
            isRunning = false
            // 最常见原因是「显示在其他应用上层」权限未真正授予
            toast("悬浮球显示失败：${t.javaClass.simpleName}，请确认已允许「显示在其他应用上层」")
            stopSelf()
        }
    }

    /** 服务内 inflate 布局必须带主题上下文，否则 Material 组件与主题属性可能解析失败 */
    private fun themedContext(): Context = ContextThemeWrapper(this, R.style.Theme_QuizOCR)

    // ---------------- 前台服务 ----------------

    private fun promoteToForeground() {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            if (nm.getNotificationChannel(CHANNEL_ID) == null) {
                val channel = NotificationChannel(
                    CHANNEL_ID,
                    "悬浮窗运行状态",
                    NotificationManager.IMPORTANCE_LOW
                ).apply {
                    description = "显示悬浮识别小球的运行状态"
                    setShowBadge(false)
                }
                nm.createNotificationChannel(channel)
            }
        }

        val openIntent = Intent(this, MainActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        }
        val openPi = PendingIntent.getActivity(this, 100, openIntent, pendingFlags())

        val stopIntent = Intent(this, FloatWindowService::class.java).setAction(ACTION_STOP)
        val stopPi = PendingIntent.getService(this, 101, stopIntent, pendingFlags())

        val notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_menu_search)
            .setContentTitle("悬浮识别已开启")
            .setContentText("点击屏幕上的红色「识」小球识别题目")
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setContentIntent(openPi)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "关闭悬浮窗", stopPi)
            .build()

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                startForeground(
                    NOTIFICATION_ID,
                    notification,
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
                )
            } else {
                startForeground(NOTIFICATION_ID, notification)
            }
        } catch (t: Throwable) {
            // 前台化失败不阻断悬浮窗显示（部分 ROM 限制），降级为普通服务
        }
    }

    private fun pendingFlags(): Int =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        } else {
            PendingIntent.FLAG_UPDATE_CURRENT
        }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        return START_STICKY
    }

    // ---------------- 小球 ----------------

    private fun overlayType(): Int =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

    private fun setupBallTouch(ball: FloatBallBinding) {
        ball.root.setOnTouchListener { _, event ->
            try {
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> {
                        downX = event.rawX.toInt()
                        downY = event.rawY.toInt()
                        startX = ballParams.x
                        startY = ballParams.y
                        moved = false
                        longPressed = false
                        mainHandler.removeCallbacks(longPressAction)
                        mainHandler.postDelayed(longPressAction, 600)
                        true
                    }

                    MotionEvent.ACTION_MOVE -> {
                        val dx = event.rawX.toInt() - downX
                        val dy = event.rawY.toInt() - downY
                        if (abs(dx) > dp(6) || abs(dy) > dp(6)) {
                            moved = true
                            // 开始拖动后取消长按，避免拖完松手被判定为收起
                            mainHandler.removeCallbacks(longPressAction)
                        }
                        val metrics = resources.displayMetrics
                        ballParams.x = (startX + dx).coerceIn(0, metrics.widthPixels - dp(BALL_SIZE_DP))
                        ballParams.y = (startY + dy).coerceIn(0, metrics.heightPixels - dp(BALL_SIZE_DP))
                        try {
                            windowManager.updateViewLayout(ball.root, ballParams)
                        } catch (_: Throwable) {
                            // 视图已被移除时忽略
                        }
                        true
                    }

                    MotionEvent.ACTION_UP -> {
                        mainHandler.removeCallbacks(longPressAction)
                        // 单击 = 识别（面板已显示时刷新结果，不再关闭面板）
                        if (!moved && !longPressed) onBallClick()
                        true
                    }

                    MotionEvent.ACTION_CANCEL -> {
                        mainHandler.removeCallbacks(longPressAction)
                        true
                    }

                    else -> false
                }
            } catch (t: Throwable) {
                // 任何点击路径异常都不允许把服务带崩
                toast("操作失败：${t.javaClass.simpleName}")
                true
            }
        }
    }

    // ---------------- 结果面板（懒加载，降低启动期崩溃风险） ----------------

    private fun ensurePanel(): FloatPanelBinding? {
        panelBinding?.let { return it }
        return try {
            val ctx = themedContext()
            val panel = FloatPanelBinding.inflate(LayoutInflater.from(ctx))
            panel.rvResult.layoutManager = LinearLayoutManager(ctx)
            adapter.dark = true
            // 结果字号跟随「设置 → 结果字体大小」
            adapter.useResultTextSize = true
            // 悬浮面板空间有限，卡片用紧凑间距
            adapter.compact = true
            panel.rvResult.adapter = adapter
            panel.btnClose.setOnClickListener { hidePanel() }
            panel.btnRegion.setOnClickListener { openRegionPicker() }
            panel.btnRealtime.setOnClickListener { toggleRealtime() }

            // 拖动面板 / 拖动右下角缩放手柄
            setupPanelDrag(panel.btnDrag)
            setupPanelResize(panel.btnResize)

            // 搜索框默认隐藏：顶部 🔍 控制显隐，行内「搜索」执行搜索
            panel.searchRow.visibility = View.GONE
            panel.btnSearch.setOnClickListener { toggleSearch(panel) }
            panel.btnSearchExec.setOnClickListener { doSearch(panel.etSearch.text.toString()) }
            panel.btnClear.setOnClickListener {
                panel.etSearch.setText("")
                panel.etSearch.requestFocus()
            }
            panel.etSearch.setOnClickListener { focusSearch(true) }
            panel.etSearch.setOnEditorActionListener { _, actionId, _ ->
                if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                    doSearch(panel.etSearch.text.toString())
                    true
                } else {
                    false
                }
            }

            panelBinding = panel
            panel
        } catch (t: Throwable) {
            toast("结果面板创建失败：${t.javaClass.simpleName} ${t.message.orEmpty()}")
            null
        }
    }

    /**
     * 点击小球：始终执行一次识别。
     *
     * 面板已显示时**刷新结果**而不是关闭——之前的实现是开关式（开着再点就关），
     * 导致用户需要点两次才能看到答案。现在关闭面板改由面板上的 ✕ 或长按小球负责。
     */
    private fun onBallClick() {
        try {
            showPanel()
        } catch (t: Throwable) {
            toast("识别失败：${t.javaClass.simpleName}")
        }
    }

    /** 顶部 🔍：显示 / 隐藏搜索框；展开时自动聚焦并弹出键盘，便于直接修改后搜索 */
    private fun toggleSearch(panel: FloatPanelBinding) {
        if (panel.searchRow.visibility == View.VISIBLE) {
            // 收起：先退键盘与焦点，避免输入法残留
            focusSearch(false)
            panel.searchRow.visibility = View.GONE
        } else {
            panel.searchRow.visibility = View.VISIBLE
            panel.etSearch.requestFocus()
            panel.etSearch.setSelection(panel.etSearch.text.length)
            focusSearch(true)
        }
    }

    /**
     * 把本次识别到的文字同步写入搜索框（单行化、限长）。
     * 用户正在编辑搜索框时不覆盖其输入。
     */
    private fun syncRecognizedText(raw: String) {
        val p = panelBinding ?: return
        if (p.etSearch.hasFocus()) return
        // 与匹配时一致：去掉开头的序号，避免回填成「1. 下列…」让人以为没清洗
        val oneLine = StemCleaner.stripLeadingIndex(raw)
            .replace(Regex("\\s+"), " ").trim()
        if (oneLine.isEmpty()) return
        val shown = if (oneLine.length > 120) oneLine.substring(0, 120) else oneLine
        try {
            p.etSearch.setText(shown)
            p.etSearch.setSelection(shown.length)
        } catch (_: Throwable) {
            // 忽略
        }
    }

    /** 取文本中第一条非空行，作为搜索框兜底内容 */
    private fun firstLine(raw: String): String =
        raw.split('\n').map { it.trim() }.firstOrNull { it.isNotBlank() }.orEmpty()

    private fun showPanel() {
        val panel = ensurePanel() ?: return

        // 若上次停在搜索输入状态，先收回焦点：面板恢复 FLAG_NOT_FOCUSABLE 后
        // 才不会成为「活动窗口」，否则无障碍可能先从我们自己这里读（再被包名过滤成空）。
        if (panelAdded) focusSearch(false)

        if (!panelAdded) {
            if (!::panelParams.isInitialized) {
                val metrics = resources.displayMetrics
                val screenW = metrics.widthPixels
                val screenH = metrics.heightPixels
                // 默认占屏宽 94%、屏高 40%；可拖动面板移动、拖右下角改变大小
                val panelW = (screenW - dp(24)).coerceAtLeast(dp(PANEL_MIN_W_DP))
                val panelH = minOf(dp(340), (screenH * 0.40f).toInt())
                    .coerceAtLeast(dp(PANEL_MIN_H_DP))

                panelParams = WindowManager.LayoutParams(
                    panelW,
                    panelH,
                    overlayType(),
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                    PixelFormat.TRANSLUCENT
                ).apply {
                    gravity = Gravity.TOP or Gravity.START
                    x = dp(12)
                    y = (screenH - panelH - dp(16)).coerceAtLeast(dp(80))
                    softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_NOTHING
                }
            } else {
                // 复用上次调整过的尺寸与位置（旋转后做一次范围修正）
                panelParams.flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                        WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                clampPanel()
            }
            try {
                // 每次重新弹出面板，搜索框都恢复为隐藏状态
                panel.searchRow.visibility = View.GONE
                // 面板立刻出现，先给一句进度，避免点完小球后屏幕空白等待
                panel.tvStatus.text = "正在读取页面文字…"
                windowManager.addView(panel.root, panelParams)
                panelAdded = true
                liftBallAbovePanel()
            } catch (t: Throwable) {
                toast("结果面板显示失败：${t.javaClass.simpleName}")
                return
            }
        }

        // 实时模式：面板一出现就进入自动识别，由无障碍事件驱动，不再做一次性采集。
        // 若无障碍没连上，startRealtime 会失败（realtimeOn 仍为 false），
        // 继续走下面的单次采集，用截屏兜底给出结果。
        if (RealtimeMode.enabled) {
            startRealtime()
            if (realtimeOn) {
                // 已经开着实时：点球视为「立即刷新一次」，不等界面变化
                ScreenTextHolder.service?.requestRealtimeScan()
                return
            }
        }

        // 采集期间**不隐藏面板**：以前这里把整块面板设成 INVISIBLE、读完再设回来，
        // 刷新时看起来就是「先关掉、再弹出来」闪一下。
        // 无障碍采集已按包名排除本应用窗口（QuizAccessibilityService.activeRoots
        // 与 collect 里的逐节点判断），面板上的「搜索」「关联题目结果」不会混进题干。
        // 只有截屏通道必须隐藏（否则会被拍进画面），在 captureScreenClean 里单独处理。
        val text = try {
            ScreenTextHolder.capture()
        } catch (_: Throwable) {
            ""
        }

        renderResult(text)
    }

    /** 面板弹出后若会盖住小球，把小球上移到面板上沿之上，避免看起来像“球消失了” */
    private fun liftBallAbovePanel() {
        val ball = ballBinding ?: return
        if (!::panelParams.isInitialized) return
        val panelTop = panelParams.y
        val ballBottom = ballParams.y + dp(BALL_SIZE_DP)
        if (ballBottom > panelTop) {
            ballParams.y = (panelTop - dp(BALL_SIZE_DP) - dp(8)).coerceAtLeast(dp(8))
            try {
                windowManager.updateViewLayout(ball.root, ballParams)
            } catch (_: Throwable) {
                // 忽略
            }
        }
    }

    /**
     * 实时期间隐藏小球，只保留结果面板作为入口。
     *
     * 做法是「GONE + FLAG_NOT_TOUCHABLE」而不是 removeView：
     * - GONE 后 WRAP_CONTENT 窗口会缩成 0，不占位置；
     * - 再叠加 NOT_TOUCHABLE，保证不会变成一块“隐形挡板”把下方点击吞掉
     *   （窗口一旦在 ACTION_DOWN 阶段拿到触摸目标，事件就不会再传给下层）。
     * 相比 removeView/addView，反复显隐不会出现「view 还有 parent」的崩溃风险。
     */
    private fun hideBallWindow() {
        if (ballHidden) return
        val ball = ballBinding ?: return
        ballHidden = true
        try {
            ball.root.visibility = View.GONE
            ballParams.flags = ballParams.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
            windowManager.updateViewLayout(ball.root, ballParams)
        } catch (_: Throwable) {
            // 窗口已不可用：保持 hidden 标记，等下次显隐再校正
        }
    }

    /** 退出实时 / 收起面板后恢复小球 */
    private fun showBallWindow() {
        if (!ballHidden || shuttingDown) return
        val ball = ballBinding ?: return
        ballHidden = false
        try {
            // 先把可见性改回 VISIBLE，再 relayout：否则窗口可能按 GONE 的 0 尺寸重排后不再变大
            ball.root.visibility = View.VISIBLE
            ballParams.flags = ballParams.flags and WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE.inv()
            windowManager.updateViewLayout(ball.root, ballParams)
        } catch (_: Throwable) {
            // 没有悬浮窗权限等：下次面板收起时还会再试
        }
    }

    private fun hidePanel() {
        val panel = panelBinding ?: return
        if (panelAdded) {
            // 面板收起即停止实时：不在用户看不到界面时继续跑，省电也避免误识别
            stopRealtime()
            // 先退出搜索焦点，避免面板隐藏后输入法仍停留
            focusSearch(false)
            try {
                windowManager.removeView(panel.root)
            } catch (_: Throwable) {
                // 视图可能已被移除
            }
            panelAdded = false
        }
    }

    // ---------------- 实时识屏 ----------------

    /**
     * 启动实时：注册水槽 → 更新按钮 → 立刻采一次。
     *
     * 只在「无障碍已连接」时启动。没有无障碍就只剩每秒截屏 OCR，
     * 功耗高、面板还要反复隐藏，观感很差，不如让用户点一下。
     */
    private fun startRealtime() {
        if (realtimeOn) return
        val panel = panelBinding ?: return
        if (!panelAdded) return

        if (!ScreenTextHolder.isConnected) {
            updateRealtimeUi(panel, false)
            panel.tvStatus.text = "实时需要无障碍 · 点此开启"
            panel.tvStatus.setOnClickListener { openAccessibilitySettings() }
            return
        }

        realtimeOn = true
        lastRealtimeHash = 0
        lastRealtimeTop = null
        lastRealtimeContentAt = 0L
        lastRealtimeOcrAt = 0L
        pageGeneration = 0
        pendingFallbackKey = null
        lastFallbackKey = null
        fallbackRequestedAt = 0L
        lastScanAt = 0L
        lastFallbackScanAt = 0L
        RealtimeHub.sink = realtimeSink
        updateRealtimeUi(panel, true)
        // 实时期间收起小球：题干区域要留给识别，面板本身已有「实时 / ✕」入口
        hideBallWindow()
        startWatchdog()

        // 不等界面变化，先按当前画面给一次结果
        ScreenTextHolder.service?.requestRealtimeScan()
    }

    private fun stopRealtime() {
        val wasOn = realtimeOn
        realtimeOn = false
        RealtimeHub.sink = null
        lastRealtimeHash = 0
        lastRealtimeTop = null
        lastRealtimeContentAt = 0L
        lastRealtimeOcrAt = 0L
        pageGeneration = 0
        pendingFallbackKey = null
        lastFallbackKey = null
        fallbackRequestedAt = 0L
        lastScanAt = 0L
        lastFallbackScanAt = 0L
        mainHandler.removeCallbacks(realtimeOcrRunnable)
        stopWatchdog()
        // 退出实时（关开关 / 收起面板）：小球回来
        showBallWindow()
        if (wasOn) panelBinding?.let { updateRealtimeUi(it, false) }
    }

    private fun toggleRealtime() {
        val panel = panelBinding ?: return
        if (realtimeOn) {
            // 走设置项，保证与设置页开关、下次启动状态一致
            RealtimeMode.update(this, false)
            stopRealtime()
            panel.tvStatus.text = "实时已关闭 · 点小球按需识别"
            panel.tvStatus.setOnClickListener(null)
        } else {
            RealtimeMode.update(this, true)
            startRealtime()
            if (realtimeOn) toast("实时已开启：小球暂时隐藏，关闭实时或收起面板后自动恢复")
        }
    }

    private fun updateRealtimeUi(panel: FloatPanelBinding, on: Boolean) {
        panel.btnRealtime.text = if (on) "● 实时" else "实时"
        panel.btnRealtime.setTextColor(
            if (on) 0xFF3DDC84.toInt() else 0xB3FFFFFF.toInt()
        )
    }

    /** 实时匹配：子线程算，主线程只负责更新 */
    private fun renderRealtime(text: String) {
        lastRecognizedRaw = text
        matchExecutor.execute {
            val matches = try {
                searchByLines(splitLines(text))
            } catch (_: Throwable) {
                emptyList()
            }
            mainHandler.post {
                if (!realtimeOn || !panelAdded) return@post
                if (matches.isEmpty()) {
                    // 有文字但没命中：绝大多数情况是无障碍只读到了导航栏 / 按钮这类零星文字，
                    // 题干在 WebView、图片或自绘控件里。此时必须交给截屏 OCR 兜底，
                    // 否则用户看到的永远是「未匹配，点球试试」，兜底形同不存在。
                    // 截屏会按需隐藏面板，面板与识别区域不重叠时不闪。
                    if (lastRealtimeTop == null) {
                        panelBinding?.let {
                            it.tvStatus.text = "● 实时 · 无障碍文字未命中 · 准备截屏兜底…"
                        }
                    }
                    requestRealtimeFallback("无障碍文字未命中", text)
                } else {
                    postRealtimeMatches(matches)
                }
            }
        }
    }

    /**
     * 实时结果更新。
     *
     * 与点击识别的三点差异：
     * - **结果没变就完全不动 UI**，否则每 300ms 重排一次列表，看起来像在抖；
     * - **不回填搜索框**，避免用户正在看的那行字反复变化；
     * - 状态行进「● 实时」，并带上当前区域，方便核对。
     */
    private fun postRealtimeMatches(matches: List<QuizMatch>) {
        val p = panelBinding ?: return
        if (!panelAdded || !realtimeOn) return
        val top = matches.firstOrNull() ?: return
        val key = top.question.prompt + "|" + (top.score * 100).toInt() + "|" + matches.size
        if (key == lastRealtimeTop) return
        lastRealtimeTop = key
        // 无障碍文字已经命中：之前排的截屏兜底没必要再跑
        mainHandler.removeCallbacks(realtimeOcrRunnable)
        p.tvStatus.text = "● 实时 · ${matches.size} 道（${regionScope()}）· 最高 ${(top.score * 100).toInt()}%"
        p.tvStatus.setOnClickListener(null)
        adapter.submit(matches)
    }

    /**
     * 统一兜底入口：无障碍给不出可匹配的文字时，排一次「页面静止后截屏 OCR」。
     *
     * 关键是**排期而不是丢弃**：条件暂时不满足（页面还在动、距上次 OCR 太近）时，
     * 只是把任务挪到条件满足的那一刻；一旦在这里 return 掉，就只能等下一次界面事件，
     * 而很多页面此刻不会再抛事件 —— 表现出来就是「兜底没生效」。
     */
    private fun requestRealtimeFallback(reason: String, text: String) {
        if (!realtimeOn || !panelAdded) return
        fallbackReason = reason
        val key = fallbackKeyOf(text)
        if (key != pendingFallbackKey || fallbackRequestedAt == 0L) {
            pendingFallbackKey = key
            fallbackRequestedAt = SystemClock.elapsedRealtime()
        }
        scheduleRealtimeOcr()
    }

    /**
     * 「这一屏」的指纹：忽略数字、空白和标点。
     *
     * 忽略数字是为了避开倒计时、剩余次数、进度百分比这类每秒都在变的内容——
     * 否则同一屏会被当成新画面，每 3 秒截一次屏。
     */
    private fun fallbackKeyOf(text: String): String {
        var h = 0
        for (c in text) {
            if (c.isDigit() || c.isWhitespace()) continue
            if (c in ".,:;!?%+-/=()[]{}<>，。；：！？、（）【】《》") continue
            h = h * 31 + c.code
        }
        return "$h@$pageGeneration"
    }

    /** 这一屏的兜底是否已经等得太久（页面一直在动，不能再无限等） */
    private fun fallbackWaitedTooLong(now: Long): Boolean =
        fallbackRequestedAt > 0L && now - fallbackRequestedAt >= REALTIME_FALLBACK_MAX_WAIT_MS

    /** 把兜底任务排到「页面静止 + 距上次 OCR 满 3 秒」的那个时刻 */
    private fun scheduleRealtimeOcr() {
        if (!realtimeOn) return
        mainHandler.removeCallbacks(realtimeOcrRunnable)

        val now = SystemClock.elapsedRealtime()
        var wait = REALTIME_OCR_IDLE_MS - (now - lastRealtimeContentAt)
        if (wait < 0L) wait = 0L
        // 等太久了就别再等静止，强行截一次（限频仍然遵守）
        if (fallbackWaitedTooLong(now)) wait = 0L
        val sinceOcr = now - lastRealtimeOcrAt
        if (sinceOcr < REALTIME_OCR_MIN_INTERVAL_MS) {
            wait = maxOf(wait, REALTIME_OCR_MIN_INTERVAL_MS - sinceOcr)
        }
        mainHandler.postDelayed(realtimeOcrRunnable, wait)

        panelBinding?.let {
            if (panelAdded && lastRealtimeTop == null) {
                it.tvStatus.text = "● 实时 · $fallbackReason · 等待画面稳定…"
                it.tvStatus.setOnClickListener(null)
            }
        }
    }

    private fun runRealtimeOcr() {
        if (!realtimeOn || !panelAdded) return

        val now = SystemClock.elapsedRealtime()
        // 限频必须遵守，否则会变成每帧截屏
        val sinceOcr = now - lastRealtimeOcrAt
        if (sinceOcr < REALTIME_OCR_MIN_INTERVAL_MS) {
            scheduleRealtimeOcr()
            return
        }
        // 页面还在变：正常情况下再等等；但已经等太久了就直接截（否则永远等不到）
        val idle = now - lastRealtimeContentAt
        if (idle < REALTIME_OCR_IDLE_MS && !fallbackWaitedTooLong(now)) {
            scheduleRealtimeOcr()
            return
        }

        // 这一屏已经兜过底，且之后界面**没有任何新的采集**（画面没再变过）：不重复截屏
        val key = pendingFallbackKey ?: return
        if (key == lastFallbackKey && lastScanAt <= lastFallbackScanAt) {
            // 已经把这一屏的结论给过了，别让状态行一直停在「等待画面稳定…」
            panelBinding?.let {
                if (panelAdded && it.tvStatus.text?.contains("等待画面稳定") == true) {
                    it.tvStatus.text = "● 实时 · 当前画面未匹配到题目（精度 ${MatchThreshold.percent}%）"
                    it.tvStatus.setOnClickListener(null)
                }
            }
            return
        }

        if (!ScreenCapture.isReady()) {
            panelBinding?.let {
                it.tvStatus.text = "● 实时 · 需要截屏权限才能兜底 · 点此授权"
                it.tvStatus.setOnClickListener { openCapturePermission() }
            }
            return
        }

        // 拿不到任何第三方窗口（桌面、本应用、系统限制）：截屏只会拍到自己
        val st = ScreenTextHolder.lastStats
        if (st.roots == 0 && st.windows > 0) {
            panelBinding?.let {
                it.tvStatus.text = "● 实时 · 当前没有可识别的第三方界面"
                it.tvStatus.setOnClickListener(null)
            }
            return
        }

        lastFallbackKey = key
        lastFallbackScanAt = lastScanAt
        lastRealtimeOcrAt = now
        fallbackRequestedAt = 0L
        screenshotFallback(fallbackReason, silent = true)
    }

    // ---------------- 面板手势：拖动移动 / 右下角缩放 ----------------

    private fun setupPanelDrag(handle: View) {
        var downRawX = 0
        var downRawY = 0
        var fromX = 0
        var fromY = 0
        handle.setOnTouchListener { _, event ->
            try {
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> {
                        downRawX = event.rawX.toInt()
                        downRawY = event.rawY.toInt()
                        fromX = panelParams.x
                        fromY = panelParams.y
                        true
                    }

                    MotionEvent.ACTION_MOVE -> {
                        panelParams.x = fromX + (event.rawX.toInt() - downRawX)
                        panelParams.y = fromY + (event.rawY.toInt() - downRawY)
                        clampPanel()
                        safeUpdatePanel()
                        true
                    }

                    else -> true
                }
            } catch (_: Throwable) {
                true
            }
        }
    }

    private fun setupPanelResize(handle: View) {
        var downRawX = 0
        var downRawY = 0
        var fromW = 0
        var fromH = 0
        handle.setOnTouchListener { _, event ->
            try {
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> {
                        downRawX = event.rawX.toInt()
                        downRawY = event.rawY.toInt()
                        fromW = panelParams.width
                        fromH = panelParams.height
                        true
                    }

                    MotionEvent.ACTION_MOVE -> {
                        val metrics = resources.displayMetrics
                        panelParams.width = (fromW + (event.rawX.toInt() - downRawX))
                            .coerceIn(dp(PANEL_MIN_W_DP), metrics.widthPixels - dp(8))
                        panelParams.height = (fromH + (event.rawY.toInt() - downRawY))
                            .coerceIn(dp(PANEL_MIN_H_DP), metrics.heightPixels - dp(80))
                        clampPanel()
                        safeUpdatePanel()
                        true
                    }

                    else -> true
                }
            } catch (_: Throwable) {
                true
            }
        }
    }

    /** 限制面板不越出屏幕（旋转屏幕后也要能拉回可视范围） */
    private fun clampPanel() {
        if (!::panelParams.isInitialized) return
        val metrics = resources.displayMetrics
        val maxW = (metrics.widthPixels - dp(8)).coerceAtLeast(dp(PANEL_MIN_W_DP))
        val maxH = (metrics.heightPixels - dp(80)).coerceAtLeast(dp(PANEL_MIN_H_DP))
        panelParams.width = panelParams.width.coerceIn(dp(PANEL_MIN_W_DP), maxW)
        panelParams.height = panelParams.height.coerceIn(dp(PANEL_MIN_H_DP), maxH)
        panelParams.x = panelParams.x.coerceIn(
            0,
            (metrics.widthPixels - panelParams.width - dp(4)).coerceAtLeast(0)
        )
        panelParams.y = panelParams.y.coerceIn(
            0,
            (metrics.heightPixels - panelParams.height - dp(4)).coerceAtLeast(0)
        )
    }

    private fun safeUpdatePanel() {
        val panel = panelBinding ?: return
        if (!panelAdded) return
        try {
            windowManager.updateViewLayout(panel.root, panelParams)
        } catch (_: Throwable) {
            // 忽略
        }
    }

    // ---------------- 面板内文字搜索 ----------------

    /**
     * 切换面板的可聚焦状态：平时为 FLAG_NOT_FOCUSABLE（不抢焦点、不影响下层操作），
     * 只有输入搜索词时才临时可聚焦，否则输入法无法弹出。
     */
    private fun focusSearch(enable: Boolean) {
        val panel = panelBinding ?: return
        if (!panelAdded) return
        try {
            val imm = getSystemService(INPUT_METHOD_SERVICE) as? InputMethodManager
            if (enable) {
                panelParams.flags = panelParams.flags and
                        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE.inv()
                panelParams.softInputMode =
                    WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE or
                            WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE
                safeUpdatePanel()
                panel.etSearch.requestFocus()
                panel.etSearch.post {
                    try {
                        imm?.showSoftInput(panel.etSearch, InputMethodManager.SHOW_IMPLICIT)
                    } catch (_: Throwable) {
                        // 忽略
                    }
                }
            } else {
                try {
                    imm?.hideSoftInputFromWindow(panel.etSearch.windowToken, 0)
                } catch (_: Throwable) {
                    // 忽略
                }
                panel.etSearch.clearFocus()
                panelParams.flags = panelParams.flags or
                        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                panelParams.softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_NOTHING
                safeUpdatePanel()
            }
        } catch (_: Throwable) {
            // 输入法不可用时不阻断
        }
    }

    /** 按关键词搜索题库（匹配放子线程，结果回主线程渲染） */
    private fun doSearch(raw: String) {
        val panel = panelBinding ?: return
        if (!panelAdded) return
        val query = raw.trim()
        if (query.isEmpty()) {
            toast("请输入要搜索的关键词")
            return
        }
        focusSearch(false)
        panel.tvStatus.text = "搜索中…"
        adapter.submit(emptyList())
        Thread {
            val matches = try {
                QuestionBankRepository.search(query, limit = 15)
            } catch (_: Throwable) {
                emptyList()
            }
            mainHandler.post {
                val p = panelBinding ?: return@post
                if (!panelAdded) return@post
                if (matches.isEmpty()) {
                    p.tvStatus.text = "未搜到题目 · 精度「${MatchThreshold.percent}%」"
                } else {
                    p.tvStatus.text = "搜索到 ${matches.size} 道题目 · 答案已高亮"
                    adapter.submit(matches)
                }
            }
        }.start()
    }

    /**
     * 识别流程（严格「无障碍优先、截屏兜底」）：
     * 1) 无障碍：只读框选区域内的节点文字，命中题库立即出结果，**完全不启动截屏**；
     * 2) 无障碍给不出可用文字（未连接 / 框内无字 / 文字未命中）时，才用截屏 OCR 兜底；
     * 3) 两条都不行时，明确说明卡在哪一步，而不是笼统报「未识别」。
     */
    private fun renderResult(screenText: String) {
        val panel = panelBinding ?: return
        // 只改状态行，**不清空结果列表**：刷新识别时旧的题目先留着，
        // 新结果到了再整体替换，面板看起来是「原地更新」而不是「关了又开」。
        // 真的没结果时由 postNoResult() 统一清空。
        panel.tvStatus.text = "正在读取页面文字…"
        panel.tvStatus.setOnClickListener(null)

        bestQueryLine = ""
        lastRecognizedRaw = screenText

        Thread {
            // 第一级：无障碍文字（唯一会先执行的通道）
            val textMatches = searchByLines(splitLines(screenText))
            if (textMatches.isNotEmpty()) {
                postMatches(textMatches, fromScreenshot = false)
                return@Thread
            }

            // 没命中：区分「压根没文字」与「有文字但没匹配上」，再决定怎么兜底。
            // 带上本次采集的计数，用户一看就知道是无障碍没给字，还是给了字没匹配上。
            val st = ScreenTextHolder.lastStats
            val reason = when {
                !ScreenTextHolder.isConnected -> "无障碍未连接"
                screenText.isBlank() -> "没有读到文字（节点 ${st.nodes}·含字 ${st.textNodes}）"
                else -> "文字未命中"
            }
            mainHandler.post { screenshotFallback(reason) }
        }.start()
    }

    /**
     * 第二级：截屏 + 按同一区域裁剪 OCR（优先 MediaProjection，其次无障碍截屏）。
     *
     * [silent] 为实时模式的静默兜底：不弹授权、不 toast、不清空状态，
     * 失败时只在状态行提示一句，避免每秒弹一次提示。
     */
    private fun screenshotFallback(reason: String, silent: Boolean = false) {
        val p = panelBinding ?: return
        if (!ScreenCapture.isReady()) {
            if (silent) {
                if (panelAdded) {
                    p.tvStatus.text = "● 实时 · $reason · 需要截屏权限"
                    p.tvStatus.setOnClickListener { openCapturePermission() }
                }
            } else {
                postNeedCapturePermission(reason)
            }
            return
        }
        if (panelAdded) p.tvStatus.text = if (silent) "● 实时 · $reason · 正在截屏…" else "$reason · 正在截屏识别…"
        captureScreenClean { bitmap ->
            if (bitmap == null) {
                if (silent) {
                    // 静默兜底失败也要给一句可操作的提示，否则用户只看到「正在截屏…」卡住
                    if (panelAdded && realtimeOn) {
                        p.tvStatus.text = "● 实时 · 截屏失败 · 可点小球重试"
                        p.tvStatus.setOnClickListener { openCapturePermission() }
                    }
                } else {
                    postNoResult()
                }
                return@captureScreenClean
            }
            // 裁剪是整屏位图的像素拷贝（1080×2400 约 10MB），别放在主线程做
            Thread {
                val cropped = cropByRegion(bitmap)
                val fp = fingerprint(cropped)
                if (fp != 0L && fp == lastOcrFingerprint && lastOcrLines.isNotEmpty()) {
                    // 画面与上次完全一致（连点两次、页面没动）：直接复用结果，省掉 300~500ms OCR
                    recycleQuietly(cropped)
                    recycleQuietly(bitmap)
                    finishOcr(lastOcrLines, silent)
                    return@Thread
                }
                OcrHelper.recognizeLines(cropped) { lines ->
                    lastOcrFingerprint = fp
                    lastOcrLines = lines
                    recycleQuietly(cropped)
                    recycleQuietly(bitmap)
                    finishOcr(lines, silent)
                }
            }.start()
        }
    }

    /** OCR 结果 → 题库匹配 → 刷新面板（在工作线程执行） */
    private fun finishOcr(lines: List<String>, silent: Boolean = false) {
        lastRecognizedRaw = lines.joinToString("\n")
        val matches = try {
            searchByLines(lines)
        } catch (_: Throwable) {
            emptyList()
        }
        if (matches.isEmpty()) {
            if (silent) postRealtimeOcrNoMatch() else postNoResult()
        } else if (silent) {
            mainHandler.post {
                if (realtimeOn && panelAdded) postRealtimeMatches(matches)
            }
        } else {
            postMatches(matches, true)
        }
    }

    /** 实时兜底也没命中：保留一句状态，不弹提示、不动面板尺寸 */
    private fun postRealtimeOcrNoMatch() {
        mainHandler.post {
            if (!realtimeOn || !panelAdded) return@post
            val p = panelBinding ?: return@post
            p.tvStatus.text = "● 实时 · 当前画面未匹配到题目（精度 ${MatchThreshold.percent}%）"
            p.tvStatus.setOnClickListener(null)
            if (lastRealtimeTop != null) {
                lastRealtimeTop = null
                adapter.submit(emptyList())
            }
        }
    }

    private fun recycleQuietly(bitmap: Bitmap?) {
        if (bitmap == null) return
        try {
            if (!bitmap.isRecycled) bitmap.recycle()
        } catch (_: Throwable) {
            // 忽略
        }
    }

    /**
     * 8×8 灰度均值哈希，用于判断「这次截到的画面和上次是不是同一张」。
     *
     * 只取区域内的像素（状态栏时钟不在其中），所以同一道题反复点小球必然命中；
     * 一旦翻页、滚动、弹出键盘，哈希就会变，不会误用旧结果。
     */
    private fun fingerprint(src: Bitmap): Long {
        return try {
            val small = Bitmap.createScaledBitmap(src, 8, 8, true)
            val px = IntArray(64)
            small.getPixels(px, 0, 8, 0, 0, 8, 8)
            if (small !== src) recycleQuietly(small)

            val lum = IntArray(64)
            var sum = 0
            for (i in 0 until 64) {
                val c = px[i]
                val l = ((c shr 16 and 0xFF) * 299 + (c shr 8 and 0xFF) * 587 + (c and 0xFF) * 114) / 1000
                lum[i] = l
                sum += l
            }
            val avg = sum / 64
            var hash = 0L
            for (i in 0 until 64) {
                if (lum[i] >= avg) hash = hash or (1L shl i)
            }
            hash
        } catch (_: Throwable) {
            0L
        }
    }

    /** 按行拆分无障碍/OCR 文本，过滤过短噪声行；单行模式只保留第一行 */
    private fun splitLines(raw: String): List<String> {
        val lines = raw.split('\n')
            .map { it.trim() }
            .filter { it.length >= 4 }
        return if (MatchMode.current == MatchMode.SINGLE) lines.take(1) else lines.take(24)
    }

    /**
     * 按模式匹配题库。
     *
     * 单行：只拿第一行去比对；多行：每一行 + 相邻两行拼接，一次性扫库取最高分。
     * 结果在线程中计算，调用方负责切主线程。
     */
    private fun searchByLines(lines: List<String>): List<QuizMatch> {
        if (lines.isEmpty()) return emptyList()
        val single = MatchMode.current == MatchMode.SINGLE
        // 多行模式：buildQueries 会以第一个选项行为界向上取连续题干，选项部分自然被排除
        val queries = MatchMode.buildQueries(lines, maxLines = if (single) 1 else 24)
        if (queries.isEmpty()) return emptyList()

        val matches = try {
            QuestionBankRepository.searchMulti(queries, limit = 15)
        } catch (_: Throwable) {
            emptyList()
        }

        // 回填搜索框：命中时挑与题目重合最多的候选串，未命中则用首行
        bestQueryLine = if (matches.isEmpty()) {
            firstLine(lastRecognizedRaw)
        } else {
            pickBestQuery(queries, matches.first())
        }
        return matches
    }

    /** 从候选串里挑出与命中题目字符重合最多的那条，作为搜索框回填内容 */
    private fun pickBestQuery(queries: List<String>, top: QuizMatch): String {
        val prompt = top.question.prompt
        var best = queries.firstOrNull().orEmpty()
        var bestHit = -1
        for (q in queries) {
            var hit = 0
            for (ch in q) if (prompt.contains(ch)) hit++
            if (hit > bestHit) {
                bestHit = hit
                best = q
            }
        }
        return best
    }

    private fun postMatches(matches: List<QuizMatch>, fromScreenshot: Boolean) {
        mainHandler.post {
            val p = panelBinding ?: return@post
            if (!panelAdded) return@post
            // 区域写在状态里：用户能一眼核对「这次是按哪个范围识别的」
            val scope = regionScope()
            p.tvStatus.text = if (fromScreenshot) {
                "截屏识别到 ${matches.size} 道题目（$scope）· 答案已高亮"
            } else {
                "无障碍读取到 ${matches.size} 道题目（$scope）· 答案已高亮"
            }
            // 识别的文字同步写入搜索框：优先填命中的那一行，没有则用首行
            syncRecognizedText(bestQueryLine.ifBlank { firstLine(lastRecognizedRaw) })
            adapter.submit(matches)
        }
    }

    private fun postNoResult() {
        mainHandler.post {
            val p = panelBinding ?: return@post
            if (!panelAdded) return@post
            adapter.submit(emptyList())
            // 没有命中题目时，也把识别到的首行回填进搜索框，方便手动修正后搜索
            syncRecognizedText(firstLine(lastRecognizedRaw))
            if (!ScreenTextHolder.isConnected && !ScreenCaptureService.isReady) {
                // 两条通道都没有（或会话刚被系统终止）：引导重新授权
                val err = ScreenCaptureService.lastError
                p.tvStatus.text = if (err.isNullOrBlank()) {
                    "需要截屏权限 · 点此授权"
                } else {
                    "截屏不可用 · 点此重新授权"
                }
                p.tvStatus.setOnClickListener { openCapturePermission() }
                toast(err?.takeIf { it.isNotBlank() }?.let { "截屏不可用：$it" } ?: "该页面读不到文字，请授予截屏权限")
            } else {
                val st = ScreenTextHolder.lastStats
                val customized = ScanRegionStore.isCustomized(this@FloatWindowService)
                val scope = regionScope()
                when {
                    // 页面不提供节点坐标，区域过滤没法用，实际是按整屏读的——要说清楚，
                    // 否则用户会一直怀疑「我框的区域没生效」
                    st.regionUnavailable ->
                        p.tvStatus.text = "该页面无位置信息 · 无障碍按整屏读取 · 未匹配到题目"

                    // 框选区域往往就是失败原因：直接给一个回来的入口，不用再翻设置
                    customized -> {
                        p.tvStatus.text = "框内（$scope）未识别到题目 · 点此调整区域"
                        p.tvStatus.setOnClickListener { openRegionPicker() }
                        toast("框内没读到题目文字，可点状态栏调整识别区域或调低匹配精度")
                    }

                    else -> {
                        p.tvStatus.text = "未识别到题目 · 精度「${MatchThreshold.percent}%」"
                        toast("该界面未识别出题目。请确认题库已导入、识别区域框选正确，或在「设置」里调低匹配精度")
                    }
                }
            }
        }
    }

    /**
     * 截屏通道不可用时的处理。
     *
     * 关键区别：**无障碍已经连接**说明用户已给了读屏权限，此时不该再弹「需要截屏授权」——
     * 失败原因在区域或精度，应该引导回框选；只有无障碍确实没连上，才引导授权截屏。
     */
    private fun postNeedCapturePermission(reason: String) {
        mainHandler.post {
            val p = panelBinding
            val blocked = ScreenCaptureService.persistentUnavailable
            val a11y = ScreenTextHolder.isConnected
            val customized = ScanRegionStore.isCustomized(this@FloatWindowService)
            val scope = regionScope()

            if (p != null && panelAdded) {
                adapter.submit(emptyList())
                when {
                    a11y && customized -> {
                        p.tvStatus.text = "$reason（$scope）· 点此调整区域"
                        p.tvStatus.setOnClickListener { openRegionPicker() }
                    }

                    a11y -> {
                        p.tvStatus.text = "$reason · 点此授权截屏兜底"
                        p.tvStatus.setOnClickListener { openCapturePermission() }
                    }

                    blocked -> {
                        p.tvStatus.text = "该机型限制持续截屏 · 点此开启无障碍"
                        p.tvStatus.setOnClickListener { openAccessibilitySettings() }
                    }

                    else -> {
                        p.tvStatus.text = "需要截屏权限 · 正在打开授权…"
                        p.tvStatus.setOnClickListener { openCapturePermission() }
                    }
                }
            }

            // 无障碍可用：不再自动弹授权框，避免把「框没框准」误当成权限问题
            if (a11y) {
                toast(
                    if (customized) "框内没读到题目，可调整识别区域或调低匹配精度"
                    else "无障碍没读到题目，可授权截屏兜底"
                )
                return@post
            }

            if (blocked) {
                // 不再自动弹授权：否则会「授权 → 被系统终止 → 再授权」死循环，
                // 而且新会话还会顶掉旧会话，让提示越来越乱
                toast("该机型不允许持续截屏。请开启无障碍服务（可直接截屏识别），或改用「拍照识别」")
                return@post
            }
            toast("需要截屏授权，正在打开系统授权框（选「整个屏幕」即可）")
            openCapturePermission()
        }
    }

    /** 5 秒内只拉起一次授权，避免失败后自动续跑反复弹框 */
    private var lastConsentAt = 0L

    private fun openCapturePermission() {
        val now = System.currentTimeMillis()
        if (now - lastConsentAt < 5000) return
        lastConsentAt = now

        // 用户主动授权时清除「机型不支持」标记，允许再试一次
        ScreenCaptureService.clearUnavailableFlag()

        // 授权成功 → 回到目标界面后自动重新识别一次
        ScreenCaptureService.afterReady = {
            try {
                mainHandler.postDelayed({
                    try {
                        showPanel()
                    } catch (_: Throwable) {
                        // 忽略，面板异常不应影响服务
                    }
                }, 150)
            } catch (_: Throwable) {
                // 忽略
            }
        }
        try {
            val intent = Intent(this, CapturePermissionActivity::class.java)
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(intent)
            hidePanel()
        } catch (t: Throwable) {
            ScreenCaptureService.afterReady = null
            toast("无法打开截屏授权：${t.javaClass.simpleName}")
        }
    }

    private fun dp(value: Int): Int =
        (value * resources.displayMetrics.density).toInt()

    /** 从悬浮窗跳转到无障碍设置（悬浮窗内启动 Activity 必须加 NEW_TASK） */
    private fun openAccessibilitySettings() {
        try {
            val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(intent)
            hidePanel()
        } catch (_: Throwable) {
            toast("无法打开无障碍设置，请手动前往 设置 → 无障碍")
        }
    }

    /**
     * 截屏前按需隐藏悬浮球与结果面板，避免把自家界面拍进画面干扰 OCR。
     *
     * **只在真的挡住识别区域时才隐藏**：面板默认停在屏幕下方、取景区域多在中上部，
     * 两者不重叠时完全不用隐藏，也就没有「面板闪一下」和 150ms 的等待。
     * 只有重叠（或用户把面板拖到题目上）才隐，隐完仍要等一帧再截。
     *
     * 恢复逻辑有两个保险：
     * - 回调统一切回主线程再改可见性（View 操作必须在主线程）；
     * - 3 秒兜底定时恢复，即使截屏回调因任何原因丢失，小球也不会一直不见。
     */
    private fun captureScreenClean(onResult: (Bitmap?) -> Unit) {
        val panelRoot = panelBinding?.root
        val ballRoot = ballBinding?.root

        val hidePanel = panelRoot != null && panelAdded && panelIntersectsRegion()
        // 实时期间小球本来就是隐藏的，不要在截屏结束后把它「恢复」出来
        val hideBall = ballRoot != null && !ballHidden && ballIntersectsRegion()

        if (hidePanel) {
            try {
                panelRoot?.visibility = View.INVISIBLE
            } catch (_: Throwable) {
                // 忽略
            }
        }
        if (hideBall) {
            try {
                ballRoot?.visibility = View.INVISIBLE
            } catch (_: Throwable) {
                // 忽略
            }
        }

        var restored = false

        fun restore() {
            if (restored) return
            restored = true
            if (hidePanel) {
                try {
                    panelRoot?.visibility = View.VISIBLE
                } catch (_: Throwable) {
                    // 忽略
                }
            }
            if (hideBall) {
                try {
                    ballRoot?.visibility = View.VISIBLE
                } catch (_: Throwable) {
                    // 忽略
                }
            }
        }

        // 兜底：任何情况下最多 3 秒后恢复，避免悬浮球永久不可见
        mainHandler.postDelayed({ restore() }, 3000)

        // 没隐藏就不用等：隐藏后需要给合成器一帧时间（实测 150ms 足够）
        val delay = if (hidePanel || hideBall) 100L else 0L
        mainHandler.postDelayed({
            try {
                ScreenCapture.capture { bitmap ->
                    mainHandler.post {
                        restore()
                        onResult(bitmap)
                    }
                }
            } catch (t: Throwable) {
                mainHandler.post {
                    restore()
                    onResult(null)
                }
            }
        }, delay)
    }

    /** 未自定义区域时是整屏，任何悬浮窗都算重叠 */
    private fun scanRegionRect(): Rect? {
        return try {
            val rel = ScreenRegion.effectiveRelative(this) ?: return null
            ScreenRegion.rectPx(rel, ScreenRegion.screenSize(this))
        } catch (_: Throwable) {
            null
        }
    }

    /** 结果面板是否压在识别区域上（压上就必须先隐藏再截） */
    private fun panelIntersectsRegion(): Boolean {
        if (!::panelParams.isInitialized) return true
        val region = scanRegionRect() ?: return true
        val panel = Rect(
            panelParams.x,
            panelParams.y,
            panelParams.x + panelParams.width,
            panelParams.y + panelParams.height
        )
        return Rect.intersects(region, panel)
    }

    /** 小球是否落在识别区域内（球只有 68dp，但落在题干上一样会糊住字） */
    private fun ballIntersectsRegion(): Boolean {
        if (!::ballParams.isInitialized) return false
        val region = scanRegionRect() ?: return true
        val size = dp(BALL_SIZE_DP)
        val ballRect = Rect(ballParams.x, ballParams.y, ballParams.x + size, ballParams.y + size)
        return Rect.intersects(region, ballRect)
    }

    /** 打开识别区域设置：优先用悬浮窗框选，无权限时回退到全屏框选页 */
    private fun openRegionPicker() {
        hidePanel()

        // 悬浮窗框选：选择框直接浮在真实屏幕上，框内是真实画面而不是截图底图。
        // 小球先隐藏，避免它落在框内被截进预览图；选择结束（应用或取消）后恢复。
        val ballRoot = ballBinding?.root
        RegionPickService.onFinish = {
            mainHandler.post {
                try {
                    ballRoot?.visibility = View.VISIBLE
                } catch (_: Throwable) {
                    // 忽略
                }
            }
        }
        if (RegionPickService.start(this)) {
            try {
                ballRoot?.visibility = View.INVISIBLE
            } catch (_: Throwable) {
                // 忽略
            }
            return
        }
        RegionPickService.onFinish = null

        // 回退：没有「显示在其他应用上层」权限，沿用截底图的老方式
        mainHandler.postDelayed({
            captureScreenClean { bitmap ->
                CaptureHolder.bitmap = bitmap
                if (bitmap == null) {
                    // 截不到也不阻断：退化为示意模式，仍可按比例设置
                    toast("截屏不可用，将以示意模式设置区域")
                }
                try {
                    val intent = Intent(this, RegionPickerActivity::class.java)
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    startActivity(intent)
                } catch (t: Throwable) {
                    toast("无法打开区域设置：${t.javaClass.simpleName}")
                }
            }
        }, 300)
    }

    /**
     * 当前生效区域的可读描述。
     *
     * 直接读实时设置而不是采集时缓存的文案：没开无障碍、直接走截屏时
     * 采集阶段根本没执行，缓存值会是空的，状态里就会错报成「整屏」。
     */
    private fun regionScope(): String = try {
        ScreenRegion.describe(ScreenRegion.effectiveRelative(this))
    } catch (_: Throwable) {
        "整屏"
    }

    /**
     * 按当前生效区域裁剪截图。
     *
     * 统一走 [ScreenRegion]：区域先换算成屏幕像素，再按「位图/屏幕」缩放系数映射，
     * 这样截图分辨率与屏幕不同（分辨率缩放、ROM 录屏尺寸）也不会偏。
     */
    private fun cropByRegion(src: Bitmap): Bitmap {
        val rel = try {
            ScreenRegion.effectiveRelative(this)
        } catch (_: Throwable) {
            null
        }
        return try {
            ScreenRegion.crop(src, rel, ScreenRegion.screenSize(this))
        } catch (_: Throwable) {
            src
        }
    }

    private fun toast(msg: String) {
        try {
            Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
        } catch (_: Throwable) {
            // 后台 Toast 受限时忽略
        }
    }

    /** 字号调整后立即重绘悬浮面板里已展示的结果 */
    private val textSizeListener: () -> Unit = {
        try {
            adapter.notifyDataSetChanged()
        } catch (_: Throwable) {
            // 面板未创建时忽略
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        shuttingDown = true
        ResultTextSize.removeListener(textSizeListener)
        RealtimeMode.removeListener(realtimeModeListener)
        stopRealtime()
        isRunning = false
        hidePanel()
        ballBinding?.let {
            try {
                windowManager.removeView(it.root)
            } catch (_: Throwable) {
                // 视图可能已被移除
            }
        }
        ballBinding = null
        @Suppress("DEPRECATION")
        try {
            stopForeground(true)
        } catch (_: Throwable) {
            // 忽略
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
