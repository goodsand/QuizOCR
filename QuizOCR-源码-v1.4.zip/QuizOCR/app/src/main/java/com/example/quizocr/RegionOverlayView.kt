package com.example.quizocr

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View

/**
 * 识别区域选择控件：全屏半透明遮罩 + 选区 + 四角手柄 + 九宫格辅助线。
 *
 * 交互：框内拖动整体移动，拖动四角调整大小；区域始终被限制在屏幕内且有最小尺寸。
 */
class RegionOverlayView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    private companion object {
        const val MODE_NONE = 0
        const val MODE_MOVE = 1
        const val MODE_TL = 2
        const val MODE_TR = 3
        const val MODE_BL = 4
        const val MODE_BR = 5
    }

    private val region = RectF()
    private var mode = MODE_NONE
    private var lastX = 0f
    private var lastY = 0f
    private var pendingRelative: RectF? = null

    /** 最近一次的区域比例：尺寸变化（旋转/窗口重建）时按它重新映射，避免被重置成默认值 */
    private val currentRelative = RectF(ScanRegionStore.defaultRegion())

    private val density = resources.displayMetrics.density
    private val handleTouchRadius = 44f * density
    private val minSize = 80f * density

    /** 框外压暗程度（0~1）。悬浮窗框选时调低，方便看清下方真实画面 */
    var maskAlpha: Float = 0.60f
        set(value) {
            field = value.coerceIn(0f, 1f)
            maskPaint.alpha = (field * 255).toInt()
            invalidate()
        }

    private val maskPaint = Paint().apply { color = Color.BLACK }

    private val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        style = Paint.Style.STROKE
        strokeWidth = 2f * density
    }
    private val gridPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0x66FFFFFF
        style = Paint.Style.STROKE
        strokeWidth = 1f * density
    }
    private val handlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        style = Paint.Style.FILL
    }

    init {
        // 属性初始化不会走 setter，这里显式同步一次遮罩透明度
        maskPaint.alpha = (maskAlpha * 255).toInt()
    }

    /** 区域变化回调（参数为相对屏幕比例），用于实时显示比例提示 */
    var onRegionChanged: ((RectF) -> Unit)? = null

    /**
     * 屏幕基准：部分机型上悬浮窗的坐标原点/尺寸会被系统栏挤压，
     * 此时用「屏幕在窗口中的位置 + 整屏尺寸」换算比例，保存结果才能与截图严格对应。
     * 不设置时退化为按视图自身尺寸换算（Activity 全屏场景即如此）。
     */
    private var baseLeft = 0f
    private var baseTop = 0f
    private var baseW = 0f
    private var baseH = 0f

    fun setScreenBase(left: Int, top: Int, width: Int, height: Int) {
        baseLeft = left.toFloat()
        baseTop = top.toFloat()
        baseW = width.toFloat()
        baseH = height.toFloat()
        applyPending()
        onRegionChanged?.invoke(relativeRegion())
    }

    private fun baseWidth(): Float = if (baseW > 0f) baseW else width.coerceAtLeast(1).toFloat()

    private fun baseHeight(): Float = if (baseH > 0f) baseH else height.coerceAtLeast(1).toFloat()

    /** 设置相对屏幕的比例区域（0~1） */
    fun setRelativeRegion(relative: RectF) {
        pendingRelative = RectF(relative)
        if (width > 0 && height > 0) applyPending()
        invalidate()
    }

    fun currentRegion(): RectF = RectF(region)

    /** 当前区域换算成相对比例（同时记住它，供尺寸变化时还原） */
    fun relativeRegion(): RectF {
        val w = baseWidth()
        val h = baseHeight()
        val rel = RectF(
            (region.left + baseLeft) / w,
            (region.top + baseTop) / h,
            (region.right + baseLeft) / w,
            (region.bottom + baseTop) / h
        )
        currentRelative.set(rel)
        return rel
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        applyPending()
    }

    private fun applyPending() {
        if (width <= 0 || height <= 0) return
        // 尺寸变化（旋转 / 窗口重建）时沿用当前比例，不能用默认值覆盖用户已调好的区域
        val rel = pendingRelative ?: RectF(currentRelative)
        pendingRelative = null

        val w = width.toFloat()
        val h = height.toFloat()
        region.set(
            ((rel.left * baseWidth()) - baseLeft).coerceIn(0f, w),
            ((rel.top * baseHeight()) - baseTop).coerceIn(0f, h),
            ((rel.right * baseWidth()) - baseLeft).coerceIn(0f, w),
            ((rel.bottom * baseHeight()) - baseTop).coerceIn(0f, h)
        )
        if (region.width() < minSize) region.right = (region.left + minSize).coerceAtMost(w)
        if (region.height() < minSize) region.bottom = (region.top + minSize).coerceAtMost(h)
        currentRelative.set(relativeRegion())
        invalidate()
        onRegionChanged?.invoke(relativeRegion())
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()

        // 选区外的遮罩（四块，避免复杂的离屏合成）
        canvas.drawRect(0f, 0f, w, region.top, maskPaint)
        canvas.drawRect(0f, region.bottom, w, h, maskPaint)
        canvas.drawRect(0f, region.top, region.left, region.bottom, maskPaint)
        canvas.drawRect(region.right, region.top, w, region.bottom, maskPaint)

        canvas.drawRect(region, borderPaint)

        val cw = region.width() / 3f
        val ch = region.height() / 3f
        for (i in 1..2) {
            canvas.drawLine(
                region.left + cw * i, region.top,
                region.left + cw * i, region.bottom, gridPaint
            )
            canvas.drawLine(
                region.left, region.top + ch * i,
                region.right, region.top + ch * i, gridPaint
            )
        }

        val hs = 7f * density
        canvas.drawCircle(region.left, region.top, hs, handlePaint)
        canvas.drawCircle(region.right, region.top, hs, handlePaint)
        canvas.drawCircle(region.left, region.bottom, hs, handlePaint)
        canvas.drawCircle(region.right, region.bottom, hs, handlePaint)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        val x = event.x
        val y = event.y
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                mode = detectMode(x, y)
                lastX = x
                lastY = y
                return mode != MODE_NONE
            }

            MotionEvent.ACTION_MOVE -> {
                if (mode == MODE_NONE) return false
                applyDrag(x, y)
                lastX = x
                lastY = y
                invalidate()
                onRegionChanged?.invoke(relativeRegion())
                return true
            }

            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                if (mode != MODE_NONE) {
                    mode = MODE_NONE
                    performClick()
                    return true
                }
            }
        }
        return super.onTouchEvent(event)
    }

    override fun performClick(): Boolean {
        super.performClick()
        return true
    }

    private fun detectMode(x: Float, y: Float): Int {
        if (near(x, y, region.left, region.top)) return MODE_TL
        if (near(x, y, region.right, region.top)) return MODE_TR
        if (near(x, y, region.left, region.bottom)) return MODE_BL
        if (near(x, y, region.right, region.bottom)) return MODE_BR
        if (region.contains(x, y)) return MODE_MOVE
        return MODE_NONE
    }

    private fun near(x: Float, y: Float, tx: Float, ty: Float): Boolean {
        val dx = x - tx
        val dy = y - ty
        return dx * dx + dy * dy <= handleTouchRadius * handleTouchRadius
    }

    private fun applyDrag(x: Float, y: Float) {
        val dx = x - lastX
        val dy = y - lastY
        val w = width.toFloat()
        val h = height.toFloat()

        when (mode) {
            MODE_MOVE -> {
                var shiftX = dx
                var shiftY = dy
                if (region.left + shiftX < 0f) shiftX = -region.left
                if (region.right + shiftX > w) shiftX = w - region.right
                if (region.top + shiftY < 0f) shiftY = -region.top
                if (region.bottom + shiftY > h) shiftY = h - region.bottom
                region.offset(shiftX, shiftY)
            }

            MODE_TL -> {
                region.left = (region.left + dx).coerceIn(0f, region.right - minSize)
                region.top = (region.top + dy).coerceIn(0f, region.bottom - minSize)
            }

            MODE_TR -> {
                region.right = (region.right + dx).coerceIn(region.left + minSize, w)
                region.top = (region.top + dy).coerceIn(0f, region.bottom - minSize)
            }

            MODE_BL -> {
                region.left = (region.left + dx).coerceIn(0f, region.right - minSize)
                region.bottom = (region.bottom + dy).coerceIn(region.top + minSize, h)
            }

            MODE_BR -> {
                region.right = (region.right + dx).coerceIn(region.left + minSize, w)
                region.bottom = (region.bottom + dy).coerceIn(region.top + minSize, h)
            }
        }
    }
}
