package com.example.quizocr

import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.quizocr.databinding.FragmentBankBinding
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class BankFragment : Fragment() {

    private var _binding: FragmentBankBinding? = null
    private val binding get() = _binding!!

    private val adapter = BankAdapter()

    private val pickLauncher = registerForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.GetContent()
    ) { uri: Uri? -> uri?.let { importFromUri(it) } }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentBankBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        binding.rvBank.layoutManager = LinearLayoutManager(requireContext())
        binding.rvBank.adapter = adapter
        binding.btnImport.setOnClickListener { pickLauncher.launch("*/*") }
        setupFormatCard()
        refresh()
    }

    /** 「Excel 导入格式」说明卡片：点击标题行展开/收起，状态本地记忆 */
    private fun setupFormatCard() {
        val prefs = requireContext()
            .getSharedPreferences("ui_prefs", android.content.Context.MODE_PRIVATE)

        fun apply(expanded: Boolean) {
            binding.formatBody.visibility = if (expanded) View.VISIBLE else View.GONE
            binding.tvFormatToggle.text = if (expanded) "收起 ▴" else "展开 ▾"
        }

        var expanded = prefs.getBoolean("format_expanded", true)
        apply(expanded)

        binding.rowFormatTitle.setOnClickListener {
            expanded = !expanded
            apply(expanded)
            prefs.edit().putBoolean("format_expanded", expanded).apply()
        }
    }

    private fun refresh() {
        adapter.submitQuestions(QuestionBankRepository.questions)
        val count = QuestionBankRepository.questions.size
        val optCols = QuestionBankRepository.maxOptionCount
        binding.tvStats.text = if (count == 0) {
            "尚未导入题库，点击上方按钮选择 Excel（.xlsx）文件"
        } else {
            val range = if (optCols > 0) "A~${('A' + optCols - 1)}" else "无"
            "已导入 $count 道题（最多选项列：$range）"
        }
    }

    private fun importFromUri(uri: Uri) {
        Toast.makeText(requireContext(), "正在解析 Excel…", Toast.LENGTH_SHORT).show()
        lifecycleScope.launch(Dispatchers.IO) {
            try {
                val rows = XlsxReader.read(requireContext(), uri)
                if (rows.isEmpty()) throw Exception("文件为空或不是有效的 .xlsx")
                val (list, _) = BankImporter.build(rows)
                if (list.isEmpty()) {
                    throw Exception("未识别到题目，请确认首行为表头、第二行起为数据，且第 1 列有题目")
                }
                QuestionBankRepository.setQuestions(list, requireContext())
                withContext(Dispatchers.Main) {
                    refresh()
                    Toast.makeText(requireContext(), "成功导入 ${list.size} 道题", Toast.LENGTH_LONG).show()
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    Toast.makeText(requireContext(), "导入失败：${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    override fun onDestroyView() {
        _binding = null
        super.onDestroyView()
    }
}
