package com.example.quizocr

import android.app.Activity
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Looper
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat

/**
 * 基于 MediaProjection（系统录屏授权）的截屏服务，**不依赖无障碍服务**。
 *
 * 为什么需要前台服务：
 * - targetSdk ≥ Q 时，`MediaProjectionManager.getMediaProjection()` 必须在
 *   `foregroundServiceType="mediaProjection"` 的前台服务中调用；
 * - Android 14 起还要求先注册 `MediaProjection.Callback` 才能创建 VirtualDisplay。
 *
 * 每次截图按需新建 VirtualDisplay + ImageReader，抓到一帧后立即释放：
 * 静态画面下也能稳定拿到画面，不受"内容未变化就没有新帧"的影响。
 */
class ScreenCaptureService : Service() {

    companion object {
        private const val CHANNEL_ID = "screen_capture"
        private const val NOTIF_ID = 2001

        private const val EXTRA_RESULT_CODE = "result_code"
        private const val EXTRA_DATA = "result_data"
        private const val ACTION_STOP = "com.example.quizocr.STOP_CAPTURE"

        /** 抓帧超时（毫秒），超时视为失败 */
        private const val FRAME_TIMEOUT_MS = 1500L

        @Volatile
        private var instance: ScreenCaptureService? = null

        /** 是否已获得截屏授权且服务存活 */
        val isReady: Boolean
            get() = instance?.projection != null

        /**
         * 最近一次截屏会话的失败原因；成功建立会话后清空。
         * 供 UI 直接展示，便于定位「授权后仍反复要求授权」的具体环节。
         */
        @Volatile
        var lastError: String? = null

        /**
         * 会话建立成功后的待执行动作（悬浮窗「授权后自动继续识别」用）。
         * 只保留一个，执行后立即清空，避免重复触发。
         */
        @Volatile
        var afterReady: (() -> Unit)? = null

        /**
         * 该机型是否限制持续录屏：授权后 3 秒内会话就被系统撤销。
         * 置为 true 后不再自动拉起授权框（否则会反复弹、且新会话会顶掉旧会话），
         * 改为引导用户开启无障碍截屏。
         */
        @Volatile
        var persistentUnavailable: Boolean = false
            private set

        /** 用户主动重新授权时清除限制标记，允许再试一次 */
        fun clearUnavailableFlag() {
            persistentUnavailable = false
            lastError = null
        }

        /**
         * 发起一次截屏。
         * @return false 表示当前不可用（未授权 / 服务未运行），调用方应改用其他方式
         */
        fun capture(callback: (Bitmap?) -> Unit): Boolean {
            val svc = instance ?: return false
            if (svc.projection == null) return false
            svc.grab(callback)
            return true
        }

        /** 用授权结果启动服务（必须由 Activity 的授权回调传入 resultCode / data） */
        fun start(context: Context, resultCode: Int, data: Intent) {
            val intent = Intent(context, ScreenCaptureService::class.java).apply {
                putExtra(EXTRA_RESULT_CODE, resultCode)
                putExtra(EXTRA_DATA, data)
            }
            try {
                ContextCompat.startForegroundService(context, intent)
            } catch (_: Throwable) {
                // 启动失败时保持未授权状态，调用方会给出提示
            }
        }

        /** 停止并释放截屏会话 */
        fun stop(context: Context) {
            try {
                context.startService(
                    Intent(context, ScreenCaptureService::class.java).setAction(ACTION_STOP)
                )
            } catch (_: Throwable) {
                // 忽略
            }
        }
    }

    private var projection: MediaProjection? = null
    private var workerThread: HandlerThread? = null
    private var worker: Handler? = null
    private val mainHandler = Handler(Looper.getMainLooper())

    /** 是否是我们主动停止（用于区分「系统终止会话」，避免误记为错误） */
    @Volatile
    private var stopping = false

    /** 会话建立时间，用于判断是否「授权后立刻被终止」 */
    @Volatile
    private var sessionStartAt = 0L

    override fun onCreate() {
        super.onCreate()
        instance = this
        val t = HandlerThread("screen-capture").also { it.start() }
        workerThread = t
        worker = Handler(t.looper)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            // 若是通过 startForegroundService 拉起，必须先完成前台化再退出，否则触发 ANR
            stopping = true
            startAsForeground()
            releaseProjection()
            stopSelf()
            return START_NOT_STICKY
        }

        // 必须在 5 秒内转为前台，否则系统会杀服务。
        // 前台化失败就不要继续取会话了：即使拿到 projection 也会被系统立刻回收，
        // 表现为「授权后每次都要重新授权」。
        if (!startAsForeground()) {
            stopSelf()
            return START_NOT_STICKY
        }

        if (projection != null) return START_NOT_STICKY

        val resultCode = intent?.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED)
            ?: Activity.RESULT_CANCELED
        val data: Intent? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            intent?.getParcelableExtra(EXTRA_DATA, Intent::class.java)
        } else {
            @Suppress("DEPRECATION")
            intent?.getParcelableExtra(EXTRA_DATA)
        }

        if (resultCode != Activity.RESULT_OK || data == null) {
            stopSelf()
            return START_NOT_STICKY
        }

        initProjection(resultCode, data)
        return START_NOT_STICKY
    }

    /** @return 是否成功进入前台；失败会记录原因 */
    private fun startAsForeground(): Boolean {
        return try {
            val notification = buildNotification()
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                startForeground(
                    NOTIF_ID,
                    notification,
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
                )
            } else {
                startForeground(NOTIF_ID, notification)
            }
            true
        } catch (t: Throwable) {
            lastError = "前台服务启动失败：${t.javaClass.simpleName} ${t.message.orEmpty()}".trim()
            false
        }
    }

    private fun initProjection(resultCode: Int, data: Intent) {
        try {
            val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            val proj = manager.getMediaProjection(resultCode, data)
            if (proj == null) {
                lastError = "系统未返回截屏会话，授权可能已失效"
                stopSelf()
                return
            }

            // 先赋值再注册回调：若 registerCallback 后系统立刻回调 onStop，
            // onStop 里置空才不会被随后的赋值覆盖（否则会出现「isReady 为真但会话已死」）
            projection = proj
            proj.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() {
                    stopKeepAlive()
                    if (projection === proj) projection = null
                    if (!stopping) {
                        val now = System.currentTimeMillis()
                        val lived = if (sessionStartAt > 0) now - sessionStartAt else 0L
                        if (lived in 1..3000) {
                            // 授权后极短时间内被撤销：该机型不允许持续录屏
                            persistentUnavailable = true
                            lastError = "该机型限制持续录屏（授权后即被系统终止），请改用无障碍识别"
                        } else {
                            lastError = "截屏会话被系统终止，点此重新授权"
                        }
                    }
                    stopSelf()
                }
            }, mainHandler)

            sessionStartAt = System.currentTimeMillis()
            lastError = null
            // 立刻挂一个 2×2 的保活虚拟显示：部分 ROM 在没有活跃 VirtualDisplay 时
            // 会在一两秒内回收会话，表现为「刚授权就被终止」
            startKeepAlive(proj)

            // 会话建立后执行待续动作（悬浮窗授权完直接出识别结果）。
            // 延迟取较小值：部分 ROM 会在授权后 1~2 秒内回收会话，要抢在之前抓帧。
            val action = afterReady
            afterReady = null
            if (action != null) mainHandler.postDelayed(action, 250)
        } catch (t: Throwable) {
            lastError = "创建截屏会话失败：${t.javaClass.simpleName} ${t.message.orEmpty()}".trim()
            stopSelf()
        }
    }

    // ---- 保活虚拟显示 ----

    private var keepAliveDisplay: VirtualDisplay? = null
    private var keepAliveReader: ImageReader? = null

    private fun startKeepAlive(proj: MediaProjection) {
        if (keepAliveDisplay != null) return
        try {
            val reader = ImageReader.newInstance(2, 2, PixelFormat.RGBA_8888, 1)
            keepAliveReader = reader
            keepAliveDisplay = proj.createVirtualDisplay(
                "quiz-keepalive",
                2,
                2,
                1,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                reader.surface,
                null,
                null
            )
        } catch (_: Throwable) {
            // 保活失败不影响正常抓帧，忽略
            keepAliveReader?.let {
                try {
                    it.close()
                } catch (_: Throwable) {
                    // 忽略
                }
            }
            keepAliveReader = null
            keepAliveDisplay = null
        }
    }

    private fun stopKeepAlive() {
        try {
            keepAliveDisplay?.release()
        } catch (_: Throwable) {
            // 忽略
        }
        keepAliveDisplay = null
        try {
            keepAliveReader?.close()
        } catch (_: Throwable) {
            // 忽略
        }
        keepAliveReader = null
    }

    /**
     * 抓一帧。按需创建 VirtualDisplay，抓到后立即释放，
     * 因此每次调用都能拿到当前画面（不依赖画面是否发生变化）。
     */
    private fun grab(callback: (Bitmap?) -> Unit) {
        val proj = projection
        val handler = worker ?: mainHandler
        if (proj == null) {
            callback(null)
            return
        }

        // 抓帧前释放保活显示：部分 ROM 只允许一个 VirtualDisplay，
        // 两个并存会导致 createVirtualDisplay 直接失败（抓不出图）
        stopKeepAlive()

        val size = screenSizePx()
        val width = size[0]
        val height = size[1]
        val densityDpi = resources.displayMetrics.densityDpi

        val reader = try {
            ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)
        } catch (_: Throwable) {
            callback(null)
            return
        }

        var finished = false
        var display: VirtualDisplay? = null
        val lock = Any()

        fun finish(bitmap: Bitmap?) {
            // 抓帧回调在 worker 线程，可能与超时任务并发，用锁保证只回调一次
            synchronized(lock) {
                if (finished) return
                finished = true
            }
            try {
                display?.release()
            } catch (_: Throwable) {
                // 忽略
            }
            try {
                reader.close()
            } catch (_: Throwable) {
                // 忽略
            }
            // 统一切回主线程：调用方会直接操作 View / 启动 Activity
            mainHandler.post {
                // 抓帧结束后恢复保活显示，避免「无活跃 VirtualDisplay」被系统回收会话
                try {
                    projection?.let { startKeepAlive(it) }
                } catch (_: Throwable) {
                    // 忽略
                }
                callback(bitmap)
            }
        }

        reader.setOnImageAvailableListener({ r ->
            if (finished) return@setOnImageAvailableListener
            val image: Image? = try {
                r.acquireLatestImage()
            } catch (_: Throwable) {
                null
            }
            if (image == null) return@setOnImageAvailableListener
            val bitmap = try {
                imageToBitmap(image, width, height)
            } catch (_: Throwable) {
                null
            } finally {
                try {
                    image.close()
                } catch (_: Throwable) {
                    // 忽略
                }
            }
            finish(bitmap)
        }, handler)

        try {
            display = proj.createVirtualDisplay(
                "quiz-capture",
                width,
                height,
                densityDpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                reader.surface,
                null,
                handler
            )
        } catch (_: Throwable) {
            finish(null)
            return
        }

        handler.postDelayed({ finish(null) }, FRAME_TIMEOUT_MS)
    }

    /** ImageReader 的 Image 转 Bitmap，处理行对齐产生的 padding */
    private fun imageToBitmap(image: Image, width: Int, height: Int): Bitmap {
        val plane = image.planes[0]
        val buffer = plane.buffer
        val pixelStride = plane.pixelStride
        val rowStride = plane.rowStride
        val rowPadding = rowStride - pixelStride * width

        val paddedWidth = width + rowPadding / pixelStride
        val padded = Bitmap.createBitmap(paddedWidth, height, Bitmap.Config.ARGB_8888)
        padded.copyPixelsFromBuffer(buffer)
        if (paddedWidth == width) return padded

        val cropped = Bitmap.createBitmap(padded, 0, 0, width, height)
        padded.recycle()
        return cropped
    }

    /**
     * 截屏尺寸。
     *
     * 必须与 [ScreenRegion.screenSize] 完全一致：录屏抓出来的位图尺寸就是这里给的宽高，
     * 若这里用 `currentWindowMetrics`（部分机型不含系统栏）而裁剪按 real metrics 换算，
     * 区域就会被整体压缩，表现为「框的位置对不上」。
     */
    private fun screenSizePx(): IntArray {
        val p = ScreenRegion.screenSize(this)
        return intArrayOf(p.x, p.y)
    }

    private fun buildNotification(): Notification {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "截屏识别",
                NotificationManager.IMPORTANCE_LOW
            ).apply { setShowBadge(false) }
            nm.createNotificationChannel(channel)
        }

        val flags = PendingIntent.FLAG_UPDATE_CURRENT or
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) PendingIntent.FLAG_IMMUTABLE else 0

        val openIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            flags
        )
        val stopIntent = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            // App 在后台时普通 startService 会被拦，改用 startForegroundService 拉起
            PendingIntent.getForegroundService(
                this,
                1,
                Intent(this, ScreenCaptureService::class.java).setAction(ACTION_STOP),
                flags
            )
        } else {
            PendingIntent.getService(
                this,
                1,
                Intent(this, ScreenCaptureService::class.java).setAction(ACTION_STOP),
                flags
            )
        }

        // 用系统内置图标：VectorDrawable / 自适应图标作通知小图标在个别 ROM 上会加载失败，
        // 导致 startForeground 抛异常、会话被系统回收，表现为「每次都要重新授权」
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("截屏识别已就绪")
            .setContentText("点悬浮球即可截屏识别 · 点「停止」释放授权")
            .setSmallIcon(android.R.drawable.ic_menu_camera)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setOngoing(true)
            .setContentIntent(openIntent)
            .addAction(
                android.R.drawable.ic_menu_close_clear_cancel,
                "停止",
                stopIntent
            )
            .build()
    }

    private fun releaseProjection() {
        stopKeepAlive()
        val p = projection
        projection = null
        try {
            p?.stop()
        } catch (_: Throwable) {
            // 忽略
        }
    }

    override fun onDestroy() {
        stopping = true
        instance = null
        releaseProjection()
        try {
            workerThread?.quitSafely()
        } catch (_: Throwable) {
            // 忽略
        }
        workerThread = null
        worker = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
