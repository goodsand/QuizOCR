package com.example.quizocr

import android.graphics.Color
import android.graphics.Typeface
import android.text.Spannable
import android.text.SpannableStringBuilder
import android.text.style.ForegroundColorSpan
import android.text.style.StyleSpan
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.quizocr.databinding.ItemQuestionBinding
import com.google.android.material.card.MaterialCardView

/**
 * 题目列表适配器。
 * 题库浏览页：仅展示题目（无匹配度、不高亮）；
 * 关联结果页：展示「匹配度」徽章，并把每道题的「正确答案」对应选项突出显示。
 *
 * [dark] 为 true 时适配深色半透明的悬浮结果面板（浅色文字 + 半透明卡片），
 * 题库浏览页保持默认浅色，互不影响。
 */
class BankAdapter : RecyclerView.Adapter<BankAdapter.VH>() {

    private var items: List<QuizMatch> = emptyList()

    /** 深色面板模式（悬浮窗结果面板使用） */
    var dark: Boolean = false

    /** 是否跟随「设置 → 结果字体大小」（仅搜题结果页与悬浮面板启用） */
    var useResultTextSize: Boolean = false

    /** 紧凑模式：缩小卡片外边距、内边距与行距（悬浮结果面板使用） */
    var compact: Boolean = false

    /** 传入匹配结果列表 */
    fun submit(list: List<QuizMatch>) {
        items = list
        notifyDataSetChanged()
    }

    /** 便捷方法：仅展示题目（无匹配度、无高亮），用于题库浏览页 */
    fun submitQuestions(list: List<Question>) {
        submit(list.map { QuizMatch(it) })
    }

    class VH(val binding: ItemQuestionBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val binding = ItemQuestionBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return VH(binding)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val match = items[position]
        val q = match.question
        holder.binding.tvPrompt.text = "${position + 1}. ${q.prompt}"

        if (match.showScore) {
            holder.binding.tvScore.visibility = View.VISIBLE
            holder.binding.tvScore.text = "匹配 ${(match.score * 100).toInt()}%"
        } else {
            holder.binding.tvScore.visibility = View.GONE
        }

        holder.binding.tvAnswer.text =
            "答案：${if (q.answer.isBlank()) "—" else q.answer}"

        applyTheme(holder)
        applyTextSize(holder)
        applySpacing(holder)

        // 选项：本题答案对应的选项标识（如 A/B/C/D 或 对/错 项）突出显示
        val highlightColor = if (dark) {
            Color.parseColor("#FF8A80")
        } else {
            Color.parseColor("#D32F2F")
        }
        val sb = SpannableStringBuilder()
        val labeled = q.labeledOptions()
        labeled.forEachIndexed { i, (id, text) ->
            val start = sb.length
            sb.append("$id. $text")
            if (id in match.highlight) {
                sb.setSpan(
                    ForegroundColorSpan(highlightColor),
                    start, sb.length, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE
                )
                sb.setSpan(
                    StyleSpan(Typeface.BOLD),
                    start, sb.length, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE
                )
            }
            if (i < labeled.lastIndex) sb.append("\n")
        }
        holder.binding.tvOptions.text = sb
    }

    /**
     * 按「设置 → 结果字体大小」缩放结果卡片字号。
     * 未启用时回到布局里的默认值（题干 15 / 选项答案 13 / 徽章 12），
     * 避免 View 复用导致字号串档。
     */
    private fun applyTextSize(holder: VH) {
        val prompt = if (useResultTextSize) ResultTextSize.sp else 15
        val body = (prompt - 2).coerceAtLeast(11)
        val chip = (prompt - 3).coerceAtLeast(10)
        holder.binding.tvPrompt.textSize = prompt.toFloat()
        holder.binding.tvOptions.textSize = body.toFloat()
        holder.binding.tvAnswer.textSize = body.toFloat()
        holder.binding.tvScore.textSize = chip.toFloat()
    }

    /**
     * 卡片密度：紧凑模式下外边距 8→3dp、内边距 12→9dp、段落间距 6→3dp、
     * 选项行距 2→0dp，同一屏能多看约一道题。题库页不启用，保持原有疏朗。
     */
    private fun applySpacing(holder: VH) {
        val ctx = holder.binding.root.context
        val density = ctx.resources.displayMetrics.density
        fun px(v: Int) = (v * density).toInt()

        (holder.binding.root.layoutParams as? ViewGroup.MarginLayoutParams)?.let { lp ->
            val margin = px(if (compact) 3 else 8)
            if (lp.leftMargin != margin || lp.topMargin != margin ||
                lp.rightMargin != margin || lp.bottomMargin != margin
            ) {
                lp.setMargins(margin, margin, margin, margin)
                holder.binding.root.layoutParams = lp
            }
        }

        val padding = px(if (compact) 9 else 12)
        holder.binding.content.setPadding(padding, padding, padding, padding)

        val gap = px(if (compact) 3 else 6)
        (holder.binding.tvOptions.layoutParams as? ViewGroup.MarginLayoutParams)?.let {
            it.topMargin = gap
            holder.binding.tvOptions.layoutParams = it
        }
        (holder.binding.tvAnswer.layoutParams as? ViewGroup.MarginLayoutParams)?.let {
            it.topMargin = gap
            holder.binding.tvAnswer.layoutParams = it
        }
        holder.binding.tvOptions.setLineSpacing(px(if (compact) 0 else 2).toFloat(), 1f)
    }

    /** 按深浅模式设置文字与卡片底色 */
    private fun applyTheme(holder: VH) {
        (holder.binding.root as? MaterialCardView)?.setCardBackgroundColor(
            if (dark) Color.parseColor("#26FFFFFF") else Color.WHITE
        )
        holder.binding.tvPrompt.setTextColor(
            if (dark) Color.parseColor("#F2FFFFFF") else Color.parseColor("#212121")
        )
        holder.binding.tvOptions.setTextColor(
            if (dark) Color.parseColor("#B3FFFFFF") else Color.parseColor("#424242")
        )
        holder.binding.tvAnswer.setTextColor(
            if (dark) Color.parseColor("#7FB3FF") else Color.parseColor("#0D47A1")
        )
    }

    override fun getItemCount() = items.size
}
