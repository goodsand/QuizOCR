package com.example.quizocr

import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowInsetsControllerCompat
import com.example.quizocr.databinding.ActivityHelpBinding

/**
 * 内置使用说明（设置 → 关于）。
 *
 * 内容放在 assets/help.html，不联网、不依赖外部资源：
 * - 关闭 JavaScript 与文件访问，纯静态页面，避免任何脚本与本地文件读取风险；
 * - 版本号在加载时用真实 versionName 替换占位符，升级版本后说明页不会写着旧版本；
 * - 禁止深色模式强制反色，保证配色与文档一致。
 */
class HelpActivity : AppCompatActivity() {

    private lateinit var binding: ActivityHelpBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityHelpBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // 白色顶栏配深色图标，与主界面浅色主题一致
        window.statusBarColor = Color.WHITE
        WindowInsetsControllerCompat(window, window.decorView)
            .isAppearanceLightStatusBars = true

        binding.btnBack.setOnClickListener { finish() }

        val version = versionName()
        binding.tvVersion.text = "v$version"

        binding.webView.apply {
            setBackgroundColor(Color.WHITE)
            // 纯静态说明页：不需要脚本，也不需要读写本地文件
            settings.javaScriptEnabled = false
            settings.allowFileAccess = false
            settings.allowContentAccess = false
            isVerticalScrollBarEnabled = false
            overScrollMode = View.OVER_SCROLL_NEVER
            // 页面自带浅色配色：禁止系统深色模式强制反色，否则白底会被翻成黑底
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                isForceDarkAllowed = false
            }
        }

        // 读取 assets 后替换版本占位符再加载：禁用 JS 也能显示正确版本
        val html = try {
            assets.open("help.html").bufferedReader().use { it.readText() }
                .replace("{{VERSION}}", version)
        } catch (_: Throwable) {
            null
        }

        if (html == null) {
            binding.webView.visibility = View.GONE
            binding.tvVersion.text = "说明文件缺失"
            return
        }
        binding.webView.loadDataWithBaseURL(
            "file:///android_asset/", html, "text/html", "utf-8", null
        )
    }

    /** 从已安装包信息里取版本名（本项目未开启 BuildConfig，不能直接用 BuildConfig.VERSION_NAME） */
    @Suppress("DEPRECATION")
    private fun versionName(): String = try {
        packageManager.getPackageInfo(packageName, 0).versionName ?: "1.3"
    } catch (_: Throwable) {
        "1.3"
    }

    override fun onDestroy() {
        // 及时释放，避免 WebView 持有 Activity
        try {
            binding.webView.stopLoading()
            binding.webView.destroy()
        } catch (_: Throwable) {
        }
        super.onDestroy()
    }
}
