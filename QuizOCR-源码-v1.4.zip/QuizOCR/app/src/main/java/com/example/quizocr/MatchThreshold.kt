package com.example.quizocr

import android.content.Context

/**
 * 匹配精度阈值（0~100，百分比）。
 *
 * 相似度采用「LCS 比率 + 包含覆盖率」计算，量纲与 rapidfuzz 的 fuzz.ratio 一致：
 * - 50%（默认）：容错更宽，题干被截断、有错字也能命中，适合题干识别不全的场景；
 * - 85% 以上：只留几乎完全一致的题干；
 * - 0%：不过滤，按相似度降序取前几条。
 *
 * 该设置同时作用于拍照搜题与识屏搜题（含面板里的关键词搜索）。
 */
object MatchThreshold {

    const val DEFAULT = 50

    /** 旧版本的默认阈值（85%），仅用于一次性迁移时判断「用户没改过」 */
    private const val LEGACY_DEFAULT = 85

    /** 默认值迁移标记：迁移只做一次，之后用户手动设回 85% 也不会被改掉 */
    private const val KEY_DEFAULT_MIGRATED = "match_threshold_default_migrated"

    private const val PREF_NAME = "quizocr_settings"
    private const val KEY_PERCENT = "match_threshold_percent"

    /** 旧版本按三档保存的枚举名，读取时迁移一次 */
    private const val KEY_LEGACY = "match_precision"

    /** 进程内共享的当前阈值，服务与界面都读这一份 */
    @Volatile
    var percent: Int = DEFAULT
        private set

    /** 供相似度比较使用的 0~1 阈值 */
    val ratio: Double get() = percent / 100.0

    /** 启动时读取已保存的阈值；没有记录则用默认 50% */
    fun load(context: Context) {
        val sp = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)

        val saved = sp.getInt(KEY_PERCENT, -1)
        if (saved in 0..100) {
            // 默认值从 85% 调到 50%：只在「还停在旧默认值」时迁移一次，
            // 用户自己调过的 60/70/90… 原样保留
            val migrated = sp.getBoolean(KEY_DEFAULT_MIGRATED, false)
            percent = if (!migrated && saved == LEGACY_DEFAULT) DEFAULT else saved
            sp.edit()
                .putInt(KEY_PERCENT, percent)
                .putBoolean(KEY_DEFAULT_MIGRATED, true)
                .apply()
            return
        }

        // 迁移上一版的三档设置：精准 80 / 适中 50 / 模糊 0
        val legacy = sp.getString(KEY_LEGACY, null)
        if (legacy != null) {
            percent = when (legacy) {
                "STRICT" -> 80
                "BALANCED" -> 50
                "LOOSE" -> 0
                else -> DEFAULT
            }
            sp.edit().putInt(KEY_PERCENT, percent).remove(KEY_LEGACY).apply()
        } else {
            percent = DEFAULT
        }
    }

    fun update(context: Context, value: Int) {
        val v = value.coerceIn(0, 100)
        percent = v
        context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
            .edit()
            .putInt(KEY_PERCENT, v)
            .apply()
    }
}
