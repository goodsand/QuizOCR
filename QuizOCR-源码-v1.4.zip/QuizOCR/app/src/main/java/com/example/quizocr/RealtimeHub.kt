package com.example.quizocr

/**
 * 无障碍服务与悬浮窗之间的实时通道。
 *
 * 为什么需要它：无障碍服务在独立对象里接收系统事件，悬浮窗服务负责匹配与渲染，
 * 两者之间没有直接引用。这里放一个单例「水槽」（sink）：
 * 悬浮窗打开面板时注册自己，收起时注销；服务只在 sink 非空时才会去采集。
 *
 * 这样天然保证「面板关着就不识别」——不会在后台空跑耗电。
 */
object RealtimeHub {

    interface Sink {
        /** 采到文字（已按框选区域过滤）；[inRegion] 表示文字是否来自框内 */
        fun onRealtimeText(text: String, inRegion: Boolean)

        /** 采到了节点但一个字都没有（多为 WebView / 自绘界面） */
        fun onRealtimeEmpty()

        /** 无障碍本身不可用（服务被系统关闭等），实时无法继续 */
        fun onRealtimeUnavailable()

        /**
         * 页面切换 / 滚动：画面内容可能整体换了。
         *
         * 用于放开「同一屏只截屏兜底一次」的限制——否则在 WebView 这类
         * 无障碍读不到字的页面里，翻到下一题也永远不会再兜底。
         */
        fun onRealtimePageChanged() {
            // 默认不关心
        }
    }

    @Volatile
    var sink: Sink? = null

    val active: Boolean get() = sink != null
}
