package com.example.quizocr

/**
 * 把 Excel 解析出的二维行数据映射为题目列表。
 *
 * 列位置映射（固定，不依赖表头文字）：
 * - 第 1 列（索引 0）：题目
 * - 第 2 列（索引 1）：答案
 * - 第 3 列起（索引 2,3,4…）：选项 A、B、C…… 数量不限，可到 F 乃至更多
 *
 * 约定：第一行视为表头，从第二行开始才是数据，导入时整行跳过表头。
 */
object BankImporter {

    /** 题目列索引 */
    private const val PROMPT_COL = 0
    /** 答案列索引 */
    private const val ANSWER_COL = 1
    /** 选项起始列索引（第 3 列） */
    private const val OPTION_START_COL = 2

    /**
     * @param rows 由 [XlsxReader] 解析出的全部行（含首行表头）
     * @return 解析出的题目列表，以及本次导入的题目总数
     */
    fun build(rows: List<List<String>>): Pair<List<Question>, Int> {
        if (rows.size <= 1) return emptyList<Question>() to 0

        // 跳过第一行表头，从第二行开始导入
        val list = rows.drop(1).mapNotNull { row ->
            val prompt = row.getOrNull(PROMPT_COL)?.trim().orEmpty()
            if (prompt.isBlank()) return@mapNotNull null

            val answer = row.getOrNull(ANSWER_COL)?.trim().orEmpty()

            // 第 3 列起全部视为选项，跳过空单元格，按 A、B、C… 顺序排列
            val options = row
                .drop(OPTION_START_COL)
                .mapNotNull { it.trim().takeIf { t -> t.isNotEmpty() } }

            Question(prompt, answer, options)
        }

        return list to list.size
    }
}
