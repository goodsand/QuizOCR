package com.example.quizocr

import android.content.Context
import java.util.concurrent.CopyOnWriteArrayList

/**
 * 实时识屏开关。
 *
 * 开启后，无障碍服务会在「屏幕内容变化并稳定下来」时自动采集文字并刷新结果，
 * 不再需要反复点悬浮球。默认关闭：实时会持续占用 CPU（OCR 兜底时更明显），
 * 由用户主动开启更稳妥。
 */
object RealtimeMode {

    private const val PREF_NAME = "quizocr_settings"
    private const val KEY_ENABLED = "realtime_enabled"

    @Volatile
    var enabled: Boolean = false
        private set

    private val listeners = CopyOnWriteArrayList<(Boolean) -> Unit>()

    fun load(context: Context) {
        enabled = try {
            context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
                .getBoolean(KEY_ENABLED, false)
        } catch (_: Throwable) {
            false
        }
    }

    fun update(context: Context, on: Boolean) {
        if (enabled == on) return
        enabled = on
        try {
            context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
                .edit()
                .putBoolean(KEY_ENABLED, on)
                .apply()
        } catch (_: Throwable) {
            // 存不下也不影响本次会话
        }
        listeners.forEach {
            try {
                it(on)
            } catch (_: Throwable) {
                // 单个监听器异常不影响其它
            }
        }
    }

    fun addListener(listener: (Boolean) -> Unit) {
        if (!listeners.contains(listener)) listeners.add(listener)
    }

    fun removeListener(listener: (Boolean) -> Unit) {
        listeners.remove(listener)
    }
}
