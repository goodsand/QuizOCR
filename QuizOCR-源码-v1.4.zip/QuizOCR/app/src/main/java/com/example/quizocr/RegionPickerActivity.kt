package com.example.quizocr

import android.graphics.RectF
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.example.quizocr.databinding.ActivityRegionPickerBinding
import kotlin.math.roundToInt

/**
 * 识别区域设置页（识别区域对「无障碍文字采集」和「截屏 OCR」同时生效）。
 *
 * 两种进入方式：
 * - 悬浮球面板 → 「区域」：先截当前屏幕作底图，可对着题目位置精确框选；
 * - 主界面 → 「区域」：无障碍未连接或截屏失败时没有底图，退化为示意模式，
 *   按比例框选同样有效（保存的是相对屏幕比例）。
 */
class RegionPickerActivity : AppCompatActivity() {

    private lateinit var binding: ActivityRegionPickerBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityRegionPickerBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // 全屏显示：底图与截图尺寸一致，框选位置才准确
        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, window.decorView).apply {
            hide(WindowInsetsCompat.Type.systemBars())
            systemBarsBehavior =
                WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }

        val bg = CaptureHolder.bitmap
        if (bg != null) {
            binding.ivBg.setImageBitmap(bg)
            binding.tvHint.text = "拖动四角框选 · 保存后无障碍文字与截屏 OCR 都只识别框内"
        } else {
            // 无底图：深灰背景 + 明确提示，避免用户以为界面加载失败
            binding.ivBg.setBackgroundColor(0xFF1E1E1E.toInt())
            binding.tvHint.text = "示意模式（无底图）· 保存后无障碍文字与截屏都只识别框内"
        }

        // 先挂回调再设置初始区域，确保首次也能刷新比例文字
        binding.overlay.onRegionChanged = { rel -> updateRegionInfo(rel) }
        binding.overlay.setRelativeRegion(ScanRegionStore.load(this))
        updateRegionInfo(ScanRegionStore.load(this))

        // 与悬浮窗框选、截屏裁剪共用同一「物理整屏」基准，避免状态栏/导航栏造成整体偏移
        binding.overlay.post {
            try {
                val loc = IntArray(2)
                binding.overlay.getLocationOnScreen(loc)
                val size = ScreenRegion.screenSize(this)
                binding.overlay.setScreenBase(loc[0], loc[1], size.x, size.y)
            } catch (_: Throwable) {
                // 忽略：退化为按视图尺寸换算
            }
        }

        binding.btnCancel.setOnClickListener { finish() }

        binding.btnReset.setOnClickListener {
            binding.overlay.setRelativeRegion(ScanRegionStore.defaultRegion())
            updateRegionInfo(ScanRegionStore.defaultRegion())
        }

        binding.btnConfirm.setOnClickListener {
            ScanRegionStore.save(this, binding.overlay.relativeRegion())
            CaptureHolder.bitmap = null
            Toast.makeText(this, "识别区域已保存", Toast.LENGTH_SHORT).show()
            finish()
        }
    }

    private fun updateRegionInfo(rel: RectF) {
        val left = (rel.left * 100).roundToInt()
        val top = (rel.top * 100).roundToInt()
        val width = ((rel.right - rel.left) * 100).roundToInt()
        val height = ((rel.bottom - rel.top) * 100).roundToInt()
        binding.tvRegionInfo.text = "左 $left% · 上 $top% · 宽 $width% · 高 $height%"
    }

    override fun onDestroy() {
        super.onDestroy()
        // 主动退出时释放底图，避免静态引用长期持有大图
        if (isFinishing) CaptureHolder.bitmap = null
    }
}
