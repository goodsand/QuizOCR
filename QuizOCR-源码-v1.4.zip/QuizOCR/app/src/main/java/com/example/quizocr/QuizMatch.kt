package com.example.quizocr

/**
 * 关联题目匹配结果。
 * @param question  命中的题目
 * @param score     匹配度（0~1）
 * @param highlight 本题答案对应的选项标识（如 "A"、"B"，或判断题的 对/错 项），
 *                  用于在关联结果页突出显示正确答案；题库浏览页不传该值（空）。
 * @param showScore 是否展示匹配度徽章（题库浏览页为 false）
 */
data class QuizMatch(
    val question: Question,
    val score: Double = 0.0,
    val highlight: Set<String> = emptySet(),
    val showScore: Boolean = false
)
