package com.example.quizocr

/**
 * 清除题干开头的**题目序号**，只服务于匹配，不改变展示原文。
 *
 * 拍照与识屏拿到的文字往往带序号（`1.`、`2、`、`（3）`、`①`、`第4题`、`五、`），
 * 而题库里的题干多半不带；序号一进相似度计算就会白白拉低分母，
 * 短题干时甚至能把分数压到阈值以下。去掉之后两侧对齐，命中率和分数都更实在。
 *
 * 关键点是**题库侧与识别侧走同一个方法**：即使个别正文被误剥（例如「一、二次函数」
 * 里的「一、」其实是章节序号），两边剥法一致，也不会造成单边失配。
 */
object StemCleaner {

    private val PATTERNS = listOf(
        // （1） (12) 【3】 [4]
        Regex("""^[（(【\[]\s*[0-9０-９]{1,3}\s*[）)】\]]\s*"""),
        // 1.  1、 1． 1， 1： 1） 1) ；后面紧跟数字时不剥（避免「2.5 倍」被切成「5 倍」）
        Regex("""^[0-9０-９]{1,3}\s*[.、．,，:：）)](?![0-9０-９])\s*"""),
        // 第3题 / 第十二题（必须有「题」字，「第一小组」不会被误伤）
        Regex("""^第\s*[0-9０-９一二三四五六七八九十百]{1,4}\s*题\s*[.、．:：]?\s*"""),
        // 三、 / 十二.（中文序号 + 分隔符）
        Regex("""^[一二三四五六七八九十]{1,3}\s*[、.．]\s*(?![0-9０-９])"""),
        // ① ② ③ …
        Regex("""^[①②③④⑤⑥⑦⑧⑨⑩⑪⑫⑬⑭⑮⑯⑰⑱⑲⑳]\s*"""),
        // 1 下列关于…（数字 + 空白 + 汉字）：PDF 复制常见，题干几乎不会以这类数字开头
        Regex("""^[0-9０-９]{1,3}\s+(?=[\u4e00-\u9fa5])""")
    )

    /**
     * 剥离开头的序号，返回可直接用于匹配的正文。
     * 最多剥 3 轮，兼容「1.（2）题干」这种叠加写法；剥空了则保留原文。
     */
    fun stripLeadingIndex(raw: String): String {
        if (raw.isEmpty()) return raw
        // 全角空格 / 不换行空格先统一，避免 \s 匹配不到导致序号残留
        var text = raw.replace('\u00A0', ' ').replace('\u3000', ' ').trimStart()
        var guard = 0
        var changed = true
        while (changed && guard < 3) {
            changed = false
            for (pattern in PATTERNS) {
                val next = pattern.replaceFirst(text, "")
                if (next != text) {
                    text = next.trimStart()
                    changed = true
                    break
                }
            }
            guard++
        }
        return text.ifBlank { raw }
    }
}
