package com.example.quizocr

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Point
import android.graphics.Rect
import android.graphics.RectF
import android.util.DisplayMetrics
import android.view.WindowManager
import kotlin.math.roundToInt

/**
 * 屏幕坐标与识别区域的唯一换算入口。
 *
 * 之前「设置里框的区域」和「悬浮球实际识别的区域」不一致，根因是三处各用了一套基准：
 * - 无障碍采集用 `currentWindowMetrics`；
 * - 区域浮层用 `maximumWindowMetrics`；
 * - 截屏裁剪直接按位图尺寸乘比例。
 * 三者在一部分机型上（尤其带手势条 / 挖孔 / 分辨率缩放）并不相等，比例就整体偏移。
 *
 * 这里统一为**物理整屏像素**（[DisplayMetrics] real metrics），它与
 * 无障碍节点的 `getBoundsInScreen`、`AccessibilityService.takeScreenshot()`
 * 返回的整屏位图是同一坐标系，换算后两边必然对得上。
 */
object ScreenRegion {

    /** 物理整屏尺寸（含状态栏、导航栏），全应用唯一基准 */
    fun screenSize(context: Context): Point {
        try {
            val wm = context.getSystemService(Context.WINDOW_SERVICE) as? WindowManager
            if (wm != null) {
                val dm = DisplayMetrics()
                @Suppress("DEPRECATION")
                wm.defaultDisplay.getRealMetrics(dm)
                if (dm.widthPixels > 0 && dm.heightPixels > 0) {
                    return Point(dm.widthPixels, dm.heightPixels)
                }
            }
        } catch (_: Throwable) {
            // 落到下面兜底
        }
        val dm = context.resources.displayMetrics
        return Point(dm.widthPixels, dm.heightPixels)
    }

    /**
     * 当前**生效**的识别区域（相对整屏比例）。
     *
     * 返回 null 表示「整屏」——用户没自定义过区域时，两条通道都按整屏处理，
     * 避免出现「无障碍读整屏、截屏却只裁中间」的两套行为。
     */
    fun effectiveRelative(context: Context): RectF? =
        if (ScanRegionStore.isCustomized(context)) ScanRegionStore.load(context) else null

    /** 比例区域 → 屏幕像素矩形 */
    fun rectPx(rel: RectF, screen: Point): Rect {
        val w = screen.x.coerceAtLeast(1)
        val h = screen.y.coerceAtLeast(1)
        val left = (w * rel.left).roundToInt().coerceIn(0, w - 1)
        val top = (h * rel.top).roundToInt().coerceIn(0, h - 1)
        val right = (w * rel.right).roundToInt().coerceIn(left + 1, w)
        val bottom = (h * rel.bottom).roundToInt().coerceIn(top + 1, h)
        return Rect(left, top, right, bottom)
    }

    /**
     * 按区域裁剪截图。
     *
     * 不能直接拿 `bitmap.width * rel.left`：截图的像素尺寸未必等于屏幕像素
     * （分辨率缩放、部分 ROM 的录屏尺寸），一旦不等，比例就会把区域推到别处。
     * 这里先把区域换算成**屏幕像素**，再按「位图 / 屏幕」的缩放系数映射到位图坐标。
     */
    fun crop(src: Bitmap, rel: RectF?, screen: Point): Bitmap {
        if (rel == null) return src
        val sw = screen.x.coerceAtLeast(1)
        val sh = screen.y.coerceAtLeast(1)
        val rect = rectPx(rel, screen)

        val sx = src.width.toFloat() / sw
        val sy = src.height.toFloat() / sh

        val left = (rect.left * sx).roundToInt().coerceIn(0, src.width - 1)
        val top = (rect.top * sy).roundToInt().coerceIn(0, src.height - 1)
        val right = (rect.right * sx).roundToInt().coerceIn(left + 1, src.width)
        val bottom = (rect.bottom * sy).roundToInt().coerceIn(top + 1, src.height)

        if (left == 0 && top == 0 && right == src.width && bottom == src.height) return src
        return try {
            Bitmap.createBitmap(src, left, top, right - left, bottom - top)
        } catch (_: Throwable) {
            src
        }
    }

    /** 人类可读的区域描述，用在面板状态里让用户核对（与设置页同一格式） */
    fun describe(rel: RectF?): String {
        if (rel == null) return "整屏"
        val top = (rel.top * 100).roundToInt()
        val height = ((rel.bottom - rel.top) * 100).roundToInt()
        return "上${top}% 高${height}%"
    }
}
