package com.example.quizocr

import android.content.Context

/**
 * 匹配模式：决定「拿哪些识别文字去和题库比对」。
 *
 * - [SINGLE] 单行：只取第一行，适合取景框对准一行题干、或界面上只有一行有效题目；
 * - [MULTI]  多行：取**连续的多行题干**，自动把选项行（A. / B、/ ① / (1) / "正确" 等）
 *   及其后面的内容排除掉，再把题干块整体（以及其中的单行、相邻拼接）作为候选去匹配。
 *
 * 该设置同时作用于拍照搜题与识屏搜题。
 */
enum class MatchMode(val label: String) {
    SINGLE("单行"),
    MULTI("多行");

    companion object {

        private const val PREF_NAME = "quizocr_settings"
        private const val KEY_MODE = "match_mode"

        /** 题干块最多合并的行数，再多大概率已经把选项卷进来了 */
        private const val MAX_STEM_LINES = 3

        /** 合并后的题干块长度上限，避免把无关内容粘成一大段稀释分数 */
        private const val STEM_MAX_LEN = 96

        /** 只有短于该长度的选项行才用于「上溯截断」；长行更可能是题干本身 */
        private const val SHORT_OPTION_LEN = 20

        /** 默认多行：取景框内通常只有一行题干，多行不会改变这种场景的结果； */
        /** 而识屏面对整屏文字，单行会直接失效，因此默认值取多行更安全。 */
        @Volatile
        var current: MatchMode = MULTI
            private set

        fun load(context: Context) {
            val saved = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
                .getString(KEY_MODE, null)
            current = try {
                if (saved.isNullOrBlank()) MULTI else valueOf(saved)
            } catch (_: Throwable) {
                MULTI
            }
        }

        fun update(context: Context, mode: MatchMode) {
            current = mode
            context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
                .edit()
                .putString(KEY_MODE, mode.name)
                .apply()
        }

        // ---------- 选项行识别 ----------

        /** A. / A、/ A．/ A) / A： 开头 */
        private val OPTION_LETTER = Regex("^[A-Ha-h]\\s*[.、．)）:：]")

        /** (A) / （A） / (1) / （1） 开头 */
        private val OPTION_PAREN = Regex("^[(（]\\s*[A-Ha-h1-9]\\s*[)）]")

        /** ① ② ③ 开头 */
        private val OPTION_CIRCLE = Regex("^[①②③④⑤⑥⑦⑧⑨⑩⑪⑫]")

        /** 选项A / 选项1 */
        private val OPTION_WORD = Regex("^选项\\s*[A-Ha-h1-9]")

        /** 判断题选项常单独成行 */
        private val JUDGE_WORDS = setOf("正确", "错误", "对", "错", "√", "×", "是", "否", "true", "false")

        /**
         * 是否为选项行。
         *
         * 只认误判率低的形态：字母序号、括号序号、圈号、"选项X"、判断题词。
         * 刻意不认 "1." "2、" 这类纯数字序号 —— 它们和题号长得太像，
         * 屏幕上的 "3. 下列哪项……" 会被误判成选项，反而把题干切没了。
         */
        fun isOptionLine(line: String): Boolean {
            val s = line.trim()
            if (s.isEmpty()) return false
            if (s.lowercase() in JUDGE_WORDS) return true
            return OPTION_LETTER.containsMatchIn(s) ||
                OPTION_PAREN.containsMatchIn(s) ||
                OPTION_CIRCLE.containsMatchIn(s) ||
                OPTION_WORD.containsMatchIn(s)
        }

        /** 取选项字母（A~H）；不是字母形态的选项（①②、(1)、判断题）返回 null */
        private fun optionLetter(line: String): Char? {
            val s = line.trim()
            if (s.isEmpty()) return null
            val c = s[0]
            if (c in 'A'..'H') {
                val rest = s.substring(1).trimStart()
                if (rest.isNotEmpty() && rest[0] in ".、．)）:：") return c
            }
            if (s.length >= 3 && (s[0] == '(' || s[0] == '（')) {
                val c2 = s[1]
                if (c2 in 'A'..'H') return c2
            }
            return null
        }

        /**
         * 定位「选项区」的起点行。
         *
         * 优先找连续字母序列（A→B→C…），这能排除掉以 "A、B两地相距……" 开头的题干 ——
         * 它虽然长得像选项，但后面接的是 "C." "D."，序列不成立，因此不会被当成选项区起点。
         * 若没有字母序列（圈号 / 括号数字 / 判断题），退化为一「第一行较短的选项行」。
         */
        private fun findOptionStart(lines: List<String>): Int {
            val letters = ArrayList<IntArray>() // [行号, 字母序号]
            lines.forEachIndexed { i, l ->
                val c = optionLetter(l) ?: return@forEachIndexed
                letters.add(intArrayOf(i, c - 'A'))
            }

            var runLen = 1
            var runStart = 0
            for (k in 1 until letters.size) {
                if (letters[k][1] == letters[k - 1][1] + 1) {
                    if (runLen == 1) runStart = letters[k - 1][0]
                    runLen++
                    if (runLen >= 2) return runStart
                } else {
                    runLen = 1
                }
            }

            val shortOpt = lines.indexOfFirst { isOptionLine(it) && it.trim().length <= SHORT_OPTION_LEN }
            if (shortOpt >= 0) return shortOpt

            return lines.indexOfFirst { isOptionLine(it) }
        }

        /**
         * 从识别出的行里挑出「连续题干块」。
         *
         * 以选项区起点为界向上取连续的行（最多 [MAX_STEM_LINES] 行）；
         * 若整屏没有选项行，则取开头的若干行。返回的列表保持原有顺序。
         */
        fun extractStemLines(lines: List<String>, maxLines: Int): List<String> {
            val src = lines.asSequence()
                .map { it.trim() }
                .filter { it.isNotEmpty() }
                // 丢掉 "12." 这类纯序号行，它对匹配没有帮助，展示时也碍眼
                .filter { it.length >= 4 || it.any { c -> c.code in 0x4E00..0x9FFF } }
                .take(maxLines)
                .toList()
            if (src.isEmpty()) return emptyList()

            val optIdx = findOptionStart(src)
            if (optIdx <= 0) {
                // 没有选项行，或整屏第一行就是选项：取开头几行当题干
                return src.filter { it.length >= 2 }.take(MAX_STEM_LINES)
            }

            val stem = ArrayList<String>()
            var i = optIdx - 1
            while (i >= 0 && stem.size < MAX_STEM_LINES) {
                val line = src[i]
                // 只有「短选项行」才截断；长行即使以字母开头也更可能是题干
                val blocksHere = isOptionLine(line) && line.length <= SHORT_OPTION_LEN
                if (blocksHere) break
                stem.add(0, line)
                i--
            }
            return stem.filter { it.length >= 2 }
        }

        /**
         * 由识别出的行构造用于匹配的候选串。
         *
         * 单行模式只返回第一行；多行模式返回题干块的多种组合：
         * 最完整的 2~3 行合并串、其中每一行、以及相邻两行拼接。
         * 多生成几种组合是为了容错 —— 题干前面若混进一行页面标题，
         * 合并串会被稀释，但「只取题干那几行」的候选仍能拿满分。
         */
        fun buildQueries(lines: List<String>, maxLines: Int, mergeMaxLen: Int = 60): List<String> {
            val src = lines.asSequence()
                .map { it.trim() }
                .filter { it.length >= 2 }
                .toList()
            if (src.isEmpty()) return emptyList()

            if (current == SINGLE) return listOf(src.first())

            val stem = extractStemLines(src, maxLines)
            if (stem.isEmpty()) return src.take(1)

            val out = LinkedHashSet<String>()

            // 优先放最完整的题干块，界面展示也用它
            for (n in minOf(MAX_STEM_LINES, stem.size) downTo 1) {
                val block = stem.takeLast(n).joinToString("")
                if (block.length <= STEM_MAX_LEN) out.add(block)
            }
            // 单行候选：题干块里每一行都单独试一次
            stem.forEach { if (it.length <= STEM_MAX_LEN) out.add(it) }
            // 相邻拼接：应对「题干被折成两行且单行分数不够」的情况
            for (i in 0 until stem.size - 1) {
                if (stem[i].length + stem[i + 1].length <= mergeMaxLen) {
                    out.add(stem[i] + stem[i + 1])
                }
            }
            return out.toList()
        }
    }
}
