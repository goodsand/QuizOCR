package com.example.quizocr

import android.content.Context
import android.graphics.RectF

/**
 * 截屏识别区域存储。
 *
 * 保存的是**相对屏幕的比例**（0~1），这样在不同分辨率、不同截图尺寸下都能准确复用。
 * 默认区域取屏幕中部偏上的一块矩形（常见题目区域）。
 */
object ScanRegionStore {

    private const val PREF = "scan_region_pref"
    private const val KEY_LEFT = "left"
    private const val KEY_TOP = "top"
    private const val KEY_RIGHT = "right"
    private const val KEY_BOTTOM = "bottom"
    private const val KEY_SET = "customized"

    private const val DEFAULT_LEFT = 0.06f
    private const val DEFAULT_TOP = 0.22f
    private const val DEFAULT_RIGHT = 0.94f
    private const val DEFAULT_BOTTOM = 0.72f

    /** 默认区域（相对比例） */
    fun defaultRegion(): RectF =
        RectF(DEFAULT_LEFT, DEFAULT_TOP, DEFAULT_RIGHT, DEFAULT_BOTTOM)

    fun load(context: Context): RectF {
        val sp = context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
        return RectF(
            sp.getFloat(KEY_LEFT, DEFAULT_LEFT),
            sp.getFloat(KEY_TOP, DEFAULT_TOP),
            sp.getFloat(KEY_RIGHT, DEFAULT_RIGHT),
            sp.getFloat(KEY_BOTTOM, DEFAULT_BOTTOM)
        )
    }

    fun save(context: Context, relative: RectF) {
        // 兜底纠正，避免保存出非法区域
        val l = relative.left.coerceIn(0f, 0.98f)
        val t = relative.top.coerceIn(0f, 0.98f)
        val r = relative.right.coerceIn(l + 0.02f, 1f)
        val b = relative.bottom.coerceIn(t + 0.02f, 1f)
        context.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit()
            .putFloat(KEY_LEFT, l)
            .putFloat(KEY_TOP, t)
            .putFloat(KEY_RIGHT, r)
            .putFloat(KEY_BOTTOM, b)
            .putBoolean(KEY_SET, true)
            .apply()
    }

    /** 用户是否自定义过区域 */
    fun isCustomized(context: Context): Boolean =
        context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
            .getBoolean(KEY_SET, false)

    fun reset(context: Context) {
        context.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit()
            .putFloat(KEY_LEFT, DEFAULT_LEFT)
            .putFloat(KEY_TOP, DEFAULT_TOP)
            .putFloat(KEY_RIGHT, DEFAULT_RIGHT)
            .putFloat(KEY_BOTTOM, DEFAULT_BOTTOM)
            .putBoolean(KEY_SET, false)
            .apply()
    }
}
