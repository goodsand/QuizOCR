package com.example.quizocr

import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.TextRecognizer
import com.google.mlkit.vision.text.chinese.ChineseTextRecognizerOptions

/**
 * 文字识别模型选择。
 *
 * 只保留中文模型：ML Kit 的中文识别模型同时覆盖**中文、拉丁字母、阿拉伯数字与常用标点**，
 * 因此无需再打包独立的拉丁模型（可省下一份模型与相关代码），识别范围完全满足题库场景。
 */
enum class OcrLanguage {
    CHINESE
}

/** 文字识别器工厂：返回同一个 [TextRecognizer] 接口。 */
object TextRecognizerFactory {
    fun create(language: OcrLanguage): TextRecognizer = when (language) {
        OcrLanguage.CHINESE ->
            TextRecognition.getClient(ChineseTextRecognizerOptions.Builder().build())
    }
}
