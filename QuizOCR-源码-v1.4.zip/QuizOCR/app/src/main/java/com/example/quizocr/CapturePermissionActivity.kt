package com.example.quizocr

import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity

/**
 * 透明中转页：拉起系统的「录屏/截屏授权」对话框，拿到结果后启动截屏服务。
 *
 * 为什么需要它：MediaProjection 授权必须由 Activity 接收结果，
 * 而悬浮窗服务无法直接处理，因此用这个无界面 Activity 兜一层。
 *
 * 用 ActivityResult API 而不是 startActivityForResult：后者在本页被系统对话框
 * 覆盖、或页面被重建时可能丢失回调，导致「授权了但服务没起来，下次又弹授权」。
 */
class CapturePermissionActivity : AppCompatActivity() {

    private val launcher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            handleResult(result.resultCode, result.data)
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // 页面被重建（如授权过程中内存不足）：等待 ActivityResultRegistry 回放结果
        if (savedInstanceState != null) {
            Handler(Looper.getMainLooper()).postDelayed({
                if (!isFinishing) finish()
            }, 3000)
            return
        }

        val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as? MediaProjectionManager
        if (manager == null) {
            ScreenCaptureService.afterReady = null
            toast("当前系统不支持截屏授权")
            finish()
            return
        }

        // 等窗口真正显示后再拉起授权框，避免个别 ROM 上请求被丢弃
        window.decorView.post {
            if (isFinishing || isDestroyed) return@post
            try {
                launcher.launch(manager.createScreenCaptureIntent())
            } catch (t: Throwable) {
                toast("无法发起截屏授权：${t.javaClass.simpleName}")
                finish()
            }
        }
    }

    private fun handleResult(resultCode: Int, data: Intent?) {
        if (resultCode == Activity.RESULT_OK && data != null) {
            ScreenCaptureService.start(this, resultCode, data)
            // 延迟确认会话是否真的建立：失败要当场告知原因，否则用户只会反复看到授权框
            Handler(Looper.getMainLooper()).postDelayed({
                val error = ScreenCaptureService.lastError
                val msg = if (ScreenCaptureService.isReady) {
                    "截屏授权已就绪，之后点悬浮球即可识别"
                } else {
                    "截屏授权未生效：${error ?: "截屏服务未能启动"}"
                }
                toast(msg)
            }, 1000)
        } else {
            // 用户取消：清空待续动作，避免下次授权成功时误触发一次识别
            ScreenCaptureService.afterReady = null
            toast("已取消截屏授权")
        }
        finish()
    }

    private fun toast(msg: String) {
        Toast.makeText(applicationContext, msg, Toast.LENGTH_LONG).show()
    }
}
