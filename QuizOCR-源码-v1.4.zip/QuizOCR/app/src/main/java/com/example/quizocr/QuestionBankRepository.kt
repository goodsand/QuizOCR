package com.example.quizocr

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/**
 * 题库仓库（内存单例 + 本地 JSON 持久化）。
 * 负责：加载已保存题库、写入导入结果、以及根据识别文字检索关联题目。
 */
object QuestionBankRepository {

    private const val FILE_NAME = "question_bank.json"

    private val _questions = mutableListOf<Question>()
    val questions: List<Question> get() = _questions

    /**
     * 题库题干的归一化结果缓存。
     *
     * 归一化现在多了一步「剥离开头序号」，每次搜索都对全库重算就白费了；
     * 题库只在导入 / 加载时变化，缓存后每轮搜索只算 query 一侧。
     */
    @Volatile
    private var promptCache: List<String>? = null

    /**
     * 题干 bigram 倒排索引（词组 → 题目下标）。
     *
     * 实时识屏每几百毫秒就要匹配一次，题库上千题时「逐题 LCS」会成为瓶颈
     * （1 万题约 0.5~1.5s）。倒排先按字符二元组召回几十道候选，再做精确相似度，
     * 匹配耗时能压到十几毫秒。
     *
     * 题库很小时（默认 < 400 题）不建索引：构建开销比省下的还多。
     */
    @Volatile
    private var bigramIndex: Map<String, IntArray>? = null

    /** 低于该题量直接全量扫描 */
    private const val INDEX_MIN_SIZE = 400

    /** 索引召回的候选上限 */
    private const val CANDIDATE_LIMIT = 80

    /** 当前题库中单题包含的最多选项数（A~F…），用于界面展示 */
    val maxOptionCount: Int get() = _questions.maxOfOrNull { it.options.size } ?: 0

    /** 应用启动时加载上次保存的题库 */
    fun load(context: Context) {
        _questions.clear()
        promptCache = null
        bigramIndex = null
        try {
            context.openFileInput(FILE_NAME).bufferedReader().use { reader ->
                val arr = JSONArray(reader.readText())
                for (i in 0 until arr.length()) {
                    val obj = arr.getJSONObject(i)
                    val prompt = obj.optString("prompt", "")
                    val answer = obj.optString("answer", "")
                    val opts = mutableListOf<String>()
                    obj.optJSONArray("options")?.let { oa ->
                        for (j in 0 until oa.length()) opts.add(oa.getString(j))
                    }
                    if (prompt.isNotBlank()) _questions.add(Question(prompt, answer, opts))
                }
            }
        } catch (_: Exception) {
            // 无已保存题库时忽略
        }
    }

    /** 写入并持久化新题库 */
    fun setQuestions(list: List<Question>, context: Context) {
        _questions.clear()
        _questions.addAll(list)
        promptCache = null
        bigramIndex = null
        save(context)
    }

    private fun save(context: Context) {
        try {
            val arr = JSONArray()
            for (q in _questions) {
                val obj = JSONObject().apply {
                    put("prompt", q.prompt)
                    put("answer", q.answer)
                    val oa = JSONArray()
                    q.options.forEach { oa.put(it) }
                    put("options", oa)
                }
                arr.put(obj)
            }
            context.openFileOutput(FILE_NAME, Context.MODE_PRIVATE).use {
                it.write(arr.toString().toByteArray())
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    /**
     * 根据识别到的文字在题库中检索关联题目，返回「题目 + 匹配度」列表（降序）。
     *
     * 关联策略：
     * - 仅与**题干（题目）**做匹配，不混入选项 / 答案，避免"答案或选项恰好相同"
     *   的无关题目被误判为关联。
     * - 相似度采用字符二元组（bigram）的 Dice 系数，对文字错位、少量 OCR 错字、
     *   中英文混排都更稳健；若识别文字整体被题干包含（或反之），记满分。
     * - 低于阈值的题目直接过滤，最多返回 limit 条。
     *
     * @param query  OCR 识别出的首行文字（已在外面只取第一行）
     * @param limit  最多返回条数
     */
    fun search(query: String, limit: Int = 5): List<QuizMatch> = searchMulti(listOf(query), limit)

    /**
     * 多候选检索：一次遍历题库，对每道题取「与所有候选串的最高相似度」。
     *
     * 供「匹配模式 = 多行」使用：候选串包含每一行、以及相邻两行拼接的结果，
     * 因此题干被换行切断时也能命中。只扫一遍题库，不会因为候选变多而线性变慢。
     */
    fun searchMulti(queries: List<String>, limit: Int = 5): List<QuizMatch> {
        val qs = queries.map { normalize(it).take(120) }
            .filter { it.length >= 2 }
            .distinct()
        if (qs.isEmpty() || _questions.isEmpty()) return emptyList()

        // 阈值由「设置 → 匹配精度」决定，拍照搜题与识屏搜题共用
        val minScore = MatchThreshold.ratio

        // 题库一侧的归一化结果复用缓存，只有 query 需要现算
        val prompts = promptCache ?: _questions.map { normalize(it.prompt) }.also { promptCache = it }

        // 先用倒排索引召回候选；题库小、或召回太少时退回全量扫描，保证不漏
        val candidate = candidateIndices(qs, prompts)
        val indices: Iterable<Int> = candidate?.asIterable() ?: prompts.indices

        val hits = ArrayList<QuizMatch>(16)
        for (i in indices) {
            val question = _questions[i]
            val prompt = prompts[i]
            var best = 0.0
            for (q in qs) {
                val score = similarity(q, prompt)
                if (score > best) best = score
                if (best >= 1.0) break
            }
            if (best >= minScore) {
                hits.add(QuizMatch(question, best, answerHighlight(question), showScore = true))
            }
        }
        return hits.sortedByDescending { it.score }.take(limit)
    }

    /**
     * 根据题面自身的答案，计算应在关联结果页高亮的选项标识集合。
     * - 答案为字母组合（如 "A"、"AB"）：高亮对应 A、B 选项；
     * - 答案为对错判断（对/错/正确/错误/√/×/true/false）：高亮文字命中该判断的选项。
     * 答案列空白或无匹配时返回空集合（不高亮）。
     */
    private fun answerHighlight(question: Question): Set<String> {
        val ans = question.answer
        val letters = ans.uppercase().filter { it in 'A'..'Z' }.toSet()
        val rightSet = setOf("对", "正确", "√", "true")
        val wrongSet = setOf("错", "错误", "×", "false")
        val wantRight = ans.any { it in "对正确√" } || ans.contains("true", ignoreCase = true)
        val wantWrong = ans.any { it in "错错误×" } || ans.contains("false", ignoreCase = true)

        val highlight = mutableSetOf<String>()
        question.options.forEachIndexed { i, opt ->
            val id = ('A' + i).toString()
            if (id[0] in letters) highlight.add(id)
            val no = normalize(opt)
            if ((wantRight && no in rightSet) || (wantWrong && no in wrongSet)) highlight.add(id)
        }
        return highlight
    }

    /**
     * 用 bigram 倒排召回候选题目下标。
     *
     * 返回 null 表示「不要用索引，全量扫」：题库太小、或召回到的题太少
     * （可能是错字多、query 太短），这时全量扫描更稳妥。
     */
    private fun candidateIndices(qs: List<String>, prompts: List<String>): IntArray? {
        if (prompts.size < INDEX_MIN_SIZE) return null
        val index = bigramIndex ?: buildIndex(prompts).also { bigramIndex = it }
        if (index.isEmpty()) return null

        // 统计每道题命中了多少个查询 bigram
        val hits = HashMap<Int, Int>(256)
        for (q in qs) {
            for (bg in bigrams(q)) {
                val list = index[bg] ?: continue
                for (idx in list) hits[idx] = (hits[idx] ?: 0) + 1
            }
        }
        if (hits.isEmpty()) return null

        fun top(minHit: Int): IntArray = hits.entries.asSequence()
            .filter { it.value >= minHit }
            .sortedByDescending { it.value }
            .take(CANDIDATE_LIMIT)
            .map { it.key }
            .toList()
            .toIntArray()

        // 先要求至少命中 2 个 bigram（压掉噪声），召回不足时放宽到 1 个
        val strict = top(2)
        if (strict.size >= 8) return strict
        val loose = top(1)
        return if (loose.size >= 8) loose else null
    }

    /** 构建 bigram → 题目下标 的倒排表 */
    private fun buildIndex(prompts: List<String>): Map<String, IntArray> {
        val tmp = HashMap<String, MutableList<Int>>(1 shl 12)
        for (i in prompts.indices) {
            for (bg in bigrams(prompts[i])) {
                tmp.getOrPut(bg) { ArrayList(4) }.add(i)
            }
        }
        val out = HashMap<String, IntArray>(tmp.size)
        for ((k, v) in tmp) out[k] = v.toIntArray()
        return out
    }

    /** 非字母、非数字字符（含中英文标点、空格、符号），归一化时整体去掉 */
    private val NON_WORD = Regex("[^\\p{L}\\p{N}]+")

    /**
     * 文本归一化，对齐 rapidfuzz 预处理习惯：
     * 0. **先剥掉题干开头的题目序号**（`1.` / `（2）` / `①` / `第3题`）——
     *    必须在 NFKC 之前做：NFKC 会把「①」拆成「1」、把「（１）」变成「(1)」，
     *    之后再想区分「序号」与「正文里的数字」就晚了；
     * 1. NFKC 兼容分解——全角数字/字母/标点转半角（ＩＰ → IP、"５" → "5"、"，" → ","）；
     * 2. 去掉所有标点、空格、符号，只保留汉字、字母、数字；
     * 3. 统一小写，抹平英文大小写差异。
     */
    private fun normalize(s: String): String {
        val stripped = StemCleaner.stripLeadingIndex(s)
        val half = try {
            java.text.Normalizer.normalize(stripped, java.text.Normalizer.Form.NFKC)
        } catch (_: Throwable) {
            stripped
        }
        return half.lowercase().replace(NON_WORD, "")
    }

    /**
     * 两串相似度（0~1），语义对齐 rapidfuzz：
     *
     * - 主指标为 **LCS 比率**（等价于 rapidfuzz 的 fuzz.ratio）：
     *   ratio = 2·LCS / (len(a)+len(b))，对错字、漏字、顺序错位稳健；
     * - 包含关系额外按**覆盖率**给分（0.80~1.00），用于「题干被取景框截断、
     *   只识别到半句」的场景：11/19 字得 0.926，8/19 字得 0.884；
     * - 覆盖判定要求短串 ≥ 8 字且占比 ≥ 35%，避免「下列」这类碎片拿高分。
     */
    private fun similarity(a: String, b: String): Double {
        if (a.isEmpty() || b.isEmpty()) return 0.0
        if (a == b) return 1.0

        val shorter = if (a.length <= b.length) a else b
        val longer = if (a.length <= b.length) b else a
        val contained = longer.contains(shorter)

        if (contained && shorter.length >= 8) {
            val coverage = shorter.length.toDouble() / longer.length
            if (coverage >= 0.35) return 0.80 + 0.20 * coverage
        }

        // 先用 O(n) 的 bigram 粗筛：明显不相关的题不必做 O(n·m) 的动态规划
        val rough = dice(a, b)
        if (!contained && rough < 0.30) return rough

        return lcsRatio(a, b)
    }

    /**
     * LCS 比率：2·|LCS| / (len(a)+len(b))，与 rapidfuzz 的 fuzz.ratio 等价
     * （fuzz.ratio 用 indel 距离归一化，indel = n+m-2·LCS，两者同值）。
     * 使用滚动数组，空间 O(min(n,m))。
     */
    private fun lcsRatio(a: String, b: String): Double {
        val n = a.length
        val m = b.length
        if (n == 0 || m == 0) return 0.0
        var prev = IntArray(m + 1)
        var cur = IntArray(m + 1)
        for (i in 1..n) {
            for (j in 1..m) {
                cur[j] = if (a[i - 1] == b[j - 1]) prev[j - 1] + 1
                else maxOf(prev[j], cur[j - 1])
            }
            val swap = prev
            prev = cur
            cur = swap
            java.util.Arrays.fill(cur, 0)
        }
        return 2.0 * prev[m] / (n + m)
    }

    /** 字符二元组 Dice 系数，仅用于快速粗筛 */
    private fun dice(a: String, b: String): Double {
        val ba = bigrams(a)
        val bb = bigrams(b)
        if (ba.isEmpty() || bb.isEmpty()) return 0.0
        val inter = ba.count { it in bb }
        return 2.0 * inter / (ba.size + bb.size)
    }

    /** 取字符二元组集合；长度不足 2 时退化为单字符，保证短串也能参与比较 */
    private fun bigrams(s: String): Set<String> {
        if (s.length <= 1) return setOf(s)
        val set = mutableSetOf<String>()
        for (i in 0 until s.length - 1) set.add(s.substring(i, i + 2))
        return set
    }
}
