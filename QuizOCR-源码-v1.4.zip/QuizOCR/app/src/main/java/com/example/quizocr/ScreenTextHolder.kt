package com.example.quizocr

import android.graphics.Bitmap
import android.os.SystemClock

/**
 * 无障碍服务与悬浮窗之间的桥接单例（同进程内存共享）。
 * 无障碍服务连接后置入实例，悬浮窗点击识别时按需采集文字或截屏。
 */
object ScreenTextHolder {

    /** 无障碍服务实例；服务连接后置入，断开 / 被系统关闭时清空 */
    var service: QuizAccessibilityService? = null

    /** 最近一次采集到的屏幕文本（按节点逐行拼接） */
    @Volatile
    var lastText: String = ""

    /**
     * 最近一次采集是否**只取了框选区域内的文字**。
     * false 表示未设置区域（整屏采集）。
     */
    @Volatile
    var lastTextInRegion: Boolean = false

    /** 最近一次采集所用的区域描述，例如「上22% 高50%」或「整屏」 */
    @Volatile
    var lastRegionDesc: String = ""

    /** 最近一次采集的详细统计（悬浮窗据此判断「框内有没有字」以及要不要走截屏兜底） */
    @Volatile
    var lastStats: Stats = Stats()

    /**
     * 一次采集的体检数据。
     *
     * 「读不到文字」有很多种原因，笼统报「未识别到题目」没法定位：
     * 是服务没连上？窗口没拿到？拿到了但界面不暴露文字？还是被区域过滤掉了？
     * 这里把每一步的计数都记下来。
     */
    data class Stats(
        /** 服务是否连接（服务被系统杀掉时会是 false） */
        val connected: Boolean = false,
        /** 系统报告的可交互窗口总数（含本应用悬浮窗） */
        val windows: Int = 0,
        /** 其中属于本应用的窗口数（悬浮球 / 面板 / 本应用界面） */
        val selfWindows: Int = 0,
        /** 实际拿到并参与采集的根节点数 */
        val roots: Int = 0,
        /** 根节点所属包名，逗号分隔 */
        val packages: String = "",
        /** 遍历到的节点总数 */
        val nodes: Int = 0,
        /** 其中带文字（text 或 contentDescription）的节点数 */
        val textNodes: Int = 0,
        /** 带文字但**没有任何屏幕位置信息**的节点数 */
        val textNodesNoBounds: Int = 0,
        /** 最终读取到的字符数 */
        val chars: Int = 0,
        /** 区域描述；整屏时为「整屏」 */
        val regionDesc: String = "整屏",
        /** 区域过滤后命中的文字节点数 */
        val regionTextNodes: Int = 0,
        /** 因为「界面不提供位置信息」而退回整屏采集 */
        val regionUnavailable: Boolean = false,
        /** 节点数触顶，可能没遍历完整 */
        val truncated: Boolean = false,
        val elapsedMs: Long = 0
    )

    /** 无障碍服务是否处于连接状态，用于区分「没开服务」与「开了但读不到」 */
    val isConnected: Boolean
        get() = service != null

    /**
     * 主动刷新并返回当前屏幕文本；无障碍未连接或采集失败时返回空串。
     *
     * 首次读不到时会**立即重试一次**（间隔 80ms）：点击悬浮球那一刻，目标界面
     * 可能正在刷新/重绘（列表滑停、页面刚切换），节点树会短暂为空；
     * 随选朗读是持续驻留读当前焦点节点，不受这个瞬时状态影响，所以这里补一次重试。
     */
    fun capture(): String {
        val svc = service ?: run {
            lastStats = Stats(connected = false)
            return ""
        }
        return try {
            svc.refreshScreenText()
            if (lastText.isBlank() && lastStats.roots > 0) {
                SystemClock.sleep(80)
                svc.refreshScreenText()
            }
            lastText
        } catch (_: Throwable) {
            ""
        }
    }

    /**
     * 通过无障碍能力截取当前屏幕（Android 11+，无需录屏授权）。
     * 无障碍未连接或不支持时回调 null。
     */
    fun captureScreenshot(onResult: (Bitmap?) -> Unit) {
        val svc = service
        if (svc == null) {
            onResult(null)
            return
        }
        try {
            svc.captureScreen(onResult)
        } catch (_: Throwable) {
            onResult(null)
        }
    }
}
