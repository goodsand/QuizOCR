package com.example.quizocr

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.os.Bundle
import android.os.SystemClock
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import android.view.ViewGroup
import android.view.animation.DecelerateInterpolator
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.FocusMeteringAction
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.quizocr.databinding.FragmentRecognizeBinding
import com.google.mlkit.vision.common.InputImage
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import kotlin.math.hypot

/**
 * 拍照识别页。
 *
 * 交互约定：**不使用 Toast**。识别过程与结果全部就地显示——
 * - 识别进度与关联结果：显示在结果面板顶部的状态行（与识屏搜题一致）；
 * - 系统/取景提示（权限、相机未就绪、框太小）：显示在识别文字区域。
 */
class RecognizeFragment : Fragment() {

    private var _binding: FragmentRecognizeBinding? = null
    private val binding get() = _binding!!

    private lateinit var cameraExecutor: ExecutorService
    private val recognizer = TextRecognizerFactory.create(OcrLanguage.CHINESE)
    private val matchAdapter = BankAdapter()

    /** 已绑定的相机实例，用于双指缩放控制 */
    private var camera: Camera? = null
    /** 是否正在识别：底部导航重复点击时据此忽略，避免同一帧被重复提交 */
    private var isBusy = false
    /** 双指捏合缩放手势检测器 */
    private lateinit var scaleDetector: ScaleGestureDetector

    /** 缩放提示的复位任务（替代原先的缩放 Toast） */
    private val resetZoomHint = Runnable {
        _binding?.tvScanHint?.text = "只识别此框内内容"
    }

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            startCamera()
        } else {
            binding.tvRecognized.text = "需要相机权限才能拍照识别，请在系统设置中授予相机权限"
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentRecognizeBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        cameraExecutor = Executors.newSingleThreadExecutor()
        binding.rvMatches.layoutManager = LinearLayoutManager(requireContext())
        // 与识屏搜题的结果面板完全一致：深色卡片 + 紧凑间距
        matchAdapter.dark = true
        matchAdapter.compact = true
        // 结果卡片字号跟随「设置 → 结果字体大小」
        matchAdapter.useResultTextSize = true
        binding.rvMatches.adapter = matchAdapter
        ResultTextSize.addListener(textSizeListener)

        // 状态行右侧：单行/多行切换 + 搜索框开关
        binding.btnMode.text = MatchMode.current.label
        binding.btnMode.setOnClickListener { toggleMatchMode() }
        binding.btnSearch.setOnClickListener { toggleSearch() }
        binding.btnSearchExec.setOnClickListener { doSearch(binding.etSearch.text.toString()) }
        binding.btnClear.setOnClickListener { binding.etSearch.setText("") }
        binding.etSearch.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                doSearch(binding.etSearch.text.toString())
                true
            } else {
                false
            }
        }

        // 结果列表默认收起（XML 中 gone），有结果后自动展开；
        // 面板高度固定为半屏，列表自然占满剩余空间

        // 双指捏合缩放：监听 PreviewView 触摸事件，映射到相机的 zoomRatio
        scaleDetector = ScaleGestureDetector(
            requireContext(),
            object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
                override fun onScale(detector: ScaleGestureDetector): Boolean {
                    val cam = camera ?: return false
                    val state = cam.cameraInfo.zoomState.value ?: return true
                    val ratio = (state.zoomRatio * detector.scaleFactor)
                        .coerceIn(state.minZoomRatio, state.maxZoomRatio)
                    cam.cameraControl.setZoomRatio(ratio)
                    return true
                }

                override fun onScaleEnd(detector: ScaleGestureDetector) {
                    val state = camera?.cameraInfo?.zoomState?.value ?: return
                    val hint = _binding?.tvScanHint ?: return
                    hint.removeCallbacks(resetZoomHint)
                    hint.text = "只识别此框内内容 · %.1f×".format(state.zoomRatio)
                    hint.postDelayed(resetZoomHint, 1200)
                }
            }
        )
        // 预览触摸：双指捏合缩放 + 单击自动对焦
        var downX = 0f
        var downY = 0f
        var downAt = 0L
        binding.previewView.setOnTouchListener { _, event ->
            scaleDetector.onTouchEvent(event)
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = event.x
                    downY = event.y
                    downAt = SystemClock.uptimeMillis()
                }

                MotionEvent.ACTION_UP -> {
                    val elapsed = SystemClock.uptimeMillis() - downAt
                    val slop = 12f * resources.displayMetrics.density
                    // 短按 + 位移小 + 非缩放中 → 视为单击，点哪对焦哪
                    if (elapsed < 300 && hypot(event.x - downX, event.y - downY) < slop &&
                        !scaleDetector.isInProgress && event.pointerCount == 1
                    ) {
                        focusAt(event.x, event.y)
                    }
                }
            }
            true
        }

        checkPermission()
    }

    private fun checkPermission() {
        when {
            ContextCompat.checkSelfPermission(requireContext(), Manifest.permission.CAMERA)
                == PackageManager.PERMISSION_GRANTED -> startCamera()

            shouldShowRequestPermissionRationale(Manifest.permission.CAMERA) -> {
                binding.tvRecognized.text = "需要相机权限以进行拍照识别"
                permissionLauncher.launch(Manifest.permission.CAMERA)
            }

            else -> permissionLauncher.launch(Manifest.permission.CAMERA)
        }
    }

    private fun startCamera() {
        val future = ProcessCameraProvider.getInstance(requireContext())
        future.addListener({
            val provider = future.get()
            val preview = Preview.Builder().build().also {
                it.setSurfaceProvider(binding.previewView.surfaceProvider)
            }
            provider.unbindAll()
            camera = provider.bindToLifecycle(
                viewLifecycleOwner,
                CameraSelector.DEFAULT_BACK_CAMERA,
                preview
            )
        }, ContextCompat.getMainExecutor(requireContext()))
    }

    /**
     * 单击预览：在点击位置做一次 AF + AE 对焦，并在该点闪一个对焦框。
     *
     * 3 秒后自动取消该对焦区域，相机回到默认的连续对焦，不会一直锁在点击处。
     */
    private fun focusAt(x: Float, y: Float) {
        val cam = camera ?: return
        val preview = _binding?.previewView ?: return
        showFocusRing(x, y)
        try {
            // meteringPointFactory 已考虑 fillCenter 的裁剪与旋转，View 坐标可直接使用
            val point = preview.meteringPointFactory.createPoint(x, y)
            val action = FocusMeteringAction.Builder(
                point,
                FocusMeteringAction.FLAG_AF or FocusMeteringAction.FLAG_AE
            ).setAutoCancelDuration(3, TimeUnit.SECONDS).build()
            cam.cameraControl.startFocusAndMetering(action)
        } catch (_: Throwable) {
            // 少数机型不支持点对焦，忽略即可，不影响拍照识别
        }
    }

    /** 对焦框：出现在点击点中心，先放大再缩回并淡出 */
    private fun showFocusRing(x: Float, y: Float) {
        val b = _binding ?: return
        val ring = b.focusRing
        val preview = b.previewView
        val half = ring.width / 2f
        if (half <= 0f) return

        ring.animate().cancel()
        val maxX = (preview.width - ring.width).toFloat().coerceAtLeast(0f)
        val maxY = (preview.height - ring.height).toFloat().coerceAtLeast(0f)
        ring.translationX = (x - half).coerceIn(0f, maxX)
        ring.translationY = (y - half).coerceIn(0f, maxY)
        ring.alpha = 0.95f
        ring.scaleX = 1.3f
        ring.scaleY = 1.3f
        ring.animate()
            .scaleX(1f)
            .scaleY(1f)
            .alpha(0f)
            .setDuration(560)
            .setInterpolator(DecelerateInterpolator())
            .start()
    }

    /**
     * 仅识别取景框（虚线内）区域：
     * 直接从当前预览帧取出取景框对应的矩形区域裁切出来，再交给 OCR，
     * 从而彻底忽略框外内容（所见即所识，无需再做照片旋转/比例换算）。
     */
    private fun captureInRegion() {
        val preview = binding.previewView
        val full = preview.getBitmap()
        if (full == null) {
            binding.tvRecognized.text = "相机尚未就绪，请稍候再试"
            setResultStatus(null)
            return
        }

        // 取景框相对 PreviewView 在窗口坐标系下的位置
        val pvLoc = IntArray(2); preview.getLocationInWindow(pvLoc)
        val srLoc = IntArray(2); binding.scanRegion.getLocationInWindow(srLoc)
        val left = (srLoc[0] - pvLoc[0]).coerceAtLeast(0)
        val top = (srLoc[1] - pvLoc[1]).coerceAtLeast(0)
        val right = (left + binding.scanRegion.width).coerceAtMost(preview.width)
        val bottom = (top + binding.scanRegion.height).coerceAtMost(preview.height)

        // getBitmap() 返回的位图尺寸可能与 View 像素尺寸不同，按比例换算到实际位图坐标
        val scaleX = full.width.toFloat() / preview.width
        val scaleY = full.height.toFloat() / preview.height
        val cropLeft = (left * scaleX).toInt().coerceAtLeast(0)
        val cropTop = (top * scaleY).toInt().coerceAtLeast(0)
        val cropRight = (right * scaleX).toInt().coerceAtMost(full.width)
        val cropBottom = (bottom * scaleY).toInt().coerceAtMost(full.height)

        if (cropRight - cropLeft < 16 || cropBottom - cropTop < 16) {
            full.recycle()
            binding.tvRecognized.text = "取景框区域过小，请把题目置于框内后重试"
            setResultStatus(null)
            return
        }

        val cropped = Bitmap.createBitmap(
            full, cropLeft, cropTop,
            cropRight - cropLeft, cropBottom - cropTop
        )
        full.recycle()

        // 用界面状态代替「识别中…」Toast
        setBusy(true)
        setResultStatus("识别中…")
        binding.tvRecognized.text = if (MatchMode.current == MatchMode.SINGLE) {
            "正在识别框内首行…"
        } else {
            "正在识别框内文字…"
        }
        // 在单线程执行器里做 OCR，避免阻塞 UI
        cameraExecutor.execute { runOcr(cropped) }
    }

    private fun runOcr(bitmap: Bitmap) {
        try {
            val inputImage = InputImage.fromBitmap(bitmap, 0)
            recognizer.process(inputImage)
                .addOnSuccessListener { visionText ->
                    // 按「设置 → 匹配模式」决定用几行文字参与匹配：
                    // 单行只取框内第一行；多行取全部行，并额外尝试相邻两行拼接。
                    val lines = visionText.textBlocks
                        .flatMap { it.lines }
                        .map { it.text.trim() }
                        .filter { it.isNotBlank() }

                    val queries = MatchMode.buildQueries(lines, maxLines = 6)

                    // 按题干匹配关联题目
                    val matches = QuestionBankRepository.searchMulti(queries)

                    // 展示实际参与匹配的题干（多行模式下已排除选项部分）
                    val shown = if (MatchMode.current == MatchMode.SINGLE) {
                        queries.firstOrNull().orEmpty()
                    } else {
                        MatchMode.extractStemLines(lines, 6).joinToString("\n")
                    }
                    activity?.runOnUiThread { showResult(shown, matches) }
                    bitmap.recycle()
                }
                .addOnFailureListener {
                    activity?.runOnUiThread {
                        setBusy(false)
                        binding.tvRecognized.text = "识别失败，请调整取景框后重试"
                        setResultStatus("识别失败")
                    }
                    bitmap.recycle()
                }
        } catch (e: Exception) {
            activity?.runOnUiThread {
                setBusy(false)
                binding.tvRecognized.text = "识别失败，请调整取景框后重试"
                setResultStatus("识别失败")
            }
            bitmap.recycle()
        }
    }

    private fun showResult(text: String, matches: List<QuizMatch>) {
        setBusy(false)
        // 展示与匹配保持一致：开头序号（1. / （2） / ① / 第3题）先剥掉
        val shownText = text.lines()
            .joinToString("\n") { StemCleaner.stripLeadingIndex(it) }
            .trim()
        binding.tvRecognized.text = if (shownText.isEmpty()) {
            "框内未识别到文字"
        } else if (MatchMode.current == MatchMode.SINGLE) {
            "用于匹配的首行：\n$shownText"
        } else {
            "用于匹配的题干：\n$shownText"
        }

        if (matches.isEmpty()) {
            matchAdapter.submit(emptyList())
            binding.rvMatches.visibility = View.GONE
            setResultStatus("未找到匹配题目 · 精度「${MatchThreshold.percent}%」")
        } else {
            matchAdapter.submit(matches)
            binding.rvMatches.visibility = View.VISIBLE
            val top = (matches.first().score * 100).toInt()
            setResultStatus("找到 ${matches.size} 道，最高匹配 $top%，正确答案已高亮")
        }
    }

    /**
     * 状态行文字：与识屏面板的 tvStatus 同一位置与样式。
     * 传 null 表示回到就绪态；识别进度与结果都走这里，不用 Toast。
     */
    private fun setResultStatus(status: String?) {
        _binding?.tvMatchesTitle?.text =
            if (status.isNullOrBlank()) "拍照识别 · 就绪" else "拍照识别 · $status"
    }

    /** 识别期间置忙：底部导航的重复点击据此忽略，避免同一帧被重复提交 */
    private fun setBusy(busy: Boolean) {
        isBusy = busy
    }

    /** 单行 / 多行切换：与设置里的「匹配模式」是同一个持久化项，两处始终一致 */
    private fun toggleMatchMode() {
        val next = if (MatchMode.current == MatchMode.SINGLE) MatchMode.MULTI else MatchMode.SINGLE
        MatchMode.update(requireContext(), next)
        _binding?.btnMode?.text = next.label
        // 已经有结果时不清空列表，只在状态行说明这次切换何时生效
        _binding?.tvMatchesTitle?.text = "拍照识别 · 已切换为${next.label}，下次拍照生效"
    }

    /** 🔍：显示 / 隐藏关键词搜索框 */
    private fun toggleSearch() {
        val b = _binding ?: return
        val show = b.searchRow.visibility != View.VISIBLE
        b.searchRow.visibility = if (show) View.VISIBLE else View.GONE
        val imm = requireContext()
            .getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        if (show) {
            b.etSearch.requestFocus()
            b.etSearch.setSelection(b.etSearch.text.length)
            imm.showSoftInput(b.etSearch, InputMethodManager.SHOW_IMPLICIT)
        } else {
            b.etSearch.clearFocus()
            imm.hideSoftInputFromWindow(b.etSearch.windowToken, 0)
        }
    }

    /** 关键词搜索：与识屏面板的搜索同一条链路，结果直接替换卡片列表 */
    private fun doSearch(raw: String) {
        val b = _binding ?: return
        val query = raw.trim()
        if (query.isEmpty()) {
            setResultStatus("请输入关键词")
            return
        }
        b.etSearch.clearFocus()
        (requireContext().getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
            .hideSoftInputFromWindow(b.etSearch.windowToken, 0)
        setResultStatus("搜索中…")
        cameraExecutor.execute {
            val matches = try {
                QuestionBankRepository.search(query, limit = 15)
            } catch (_: Throwable) {
                emptyList()
            }
            activity?.runOnUiThread {
                val bb = _binding ?: return@runOnUiThread
                if (matches.isEmpty()) {
                    matchAdapter.submit(emptyList())
                    bb.rvMatches.visibility = View.GONE
                    setResultStatus("未搜到题目 · 精度「${MatchThreshold.percent}%」")
                } else {
                    matchAdapter.submit(matches)
                    bb.rvMatches.visibility = View.VISIBLE
                    setResultStatus("搜索到 ${matches.size} 道 · 答案已高亮")
                }
            }
        }
    }

    /** 设置里改过匹配模式后返回本页，按钮文案要跟着变 */
    override fun onResume() {
        super.onResume()
        _binding?.btnMode?.text = MatchMode.current.label
    }

    /**
     * 底部导航「拍照搜题」在已经停留本页时被再次点击 → 直接完成一次拍照搜题。
     *
     * 页面里已无拍照按钮，这是拍照搜题的唯一起点：识别中忽略（避免重复提交同一帧），
     * 相机尚未就绪时不拦截，交给 captureInRegion 就地给出「请稍候再试」。
     */
    fun triggerCapture() {
        if (!isResumed || isBusy || _binding == null) return
        captureInRegion()
    }

    /** 字号调整后立即重绘已展示的结果 */
    private val textSizeListener: () -> Unit = {
        matchAdapter.notifyDataSetChanged()
    }

    override fun onDestroyView() {
        ResultTextSize.removeListener(textSizeListener)
        _binding?.tvScanHint?.removeCallbacks(resetZoomHint)
        cameraExecutor.shutdown()
        recognizer.close()
        _binding = null
        super.onDestroyView()
    }
}
