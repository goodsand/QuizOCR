package com.example.quizocr

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.RectF
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.WindowManager
import android.widget.Toast
import androidx.appcompat.view.ContextThemeWrapper
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.example.quizocr.databinding.ViewRegionPickBinding
import kotlin.math.roundToInt

/**
 * 识别区域选择浮层（悬浮窗方式）。
 *
 * 相比旧的 [RegionPickerActivity]（截一张静止底图再框选），这里把选择框直接浮在
 * 真实屏幕之上：框外压暗、框内透明，用户对着正在显示的题目就能把范围框准，
 * 不用先截图、也不会因为底图与真实界面的时间差而错位。
 *
 * 流程刻意分成两步：
 * 1. 拖动四角调整范围 → 点「预览」，浮层临时隐藏后截取框内画面；
 * 2. 预览卡里确认真实画面无误，再点「应用」写入 [ScanRegionStore]。
 *    这样不会出现「框歪了却直接保存，等到识别失败才发现」的情况。
 */
class RegionPickService : Service() {

    companion object {
        private const val CHANNEL_ID = "region_pick_state"
        private const val NOTIFICATION_ID = 20262

        /** 选择浮层是否已显示 */
        @Volatile
        var isRunning = false
            private set

        /** 结束回调（无论应用还是取消）：悬浮窗服务用它恢复小球显示 */
        @Volatile
        var onFinish: (() -> Unit)? = null

        fun canOverlay(context: Context): Boolean =
            Build.VERSION.SDK_INT < Build.VERSION_CODES.M || Settings.canDrawOverlays(context)

        /**
         * 启动框选浮层。
         * @return false 表示没有悬浮窗权限或启动失败，调用方应回退到旧的全屏框选页。
         */
        fun start(context: Context): Boolean {
            if (!canOverlay(context)) return false
            if (isRunning) return true
            return try {
                ContextCompat.startForegroundService(
                    context,
                    Intent(context, RegionPickService::class.java)
                )
                true
            } catch (_: Throwable) {
                false
            }
        }
    }

    private lateinit var wm: WindowManager
    private var binding: ViewRegionPickBinding? = null
    private lateinit var params: WindowManager.LayoutParams
    private var added = false
    private var finishing = false

    private val ui = Handler(Looper.getMainLooper())

    /** 预览请求编号：连续点击 / 中途返回时丢弃过期回调 */
    private var previewRequestId = 0
    private var previewing = false
    private var previewBitmap: Bitmap? = null

    override fun onCreate() {
        super.onCreate()
        promoteToForeground()

        if (!canOverlay(this)) {
            toast("缺少「显示在其他应用上层」权限，无法浮动框选")
            stopSelf()
            return
        }

        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        try {
            showPicker()
        } catch (t: Throwable) {
            toast("区域选择浮层显示失败：${t.javaClass.simpleName}")
            stopSelf()
        }
    }

    private fun themedContext(): Context = ContextThemeWrapper(this, R.style.Theme_QuizOCR)

    // ---------------- 浮层 ----------------

    private fun showPicker() {
        val b = ViewRegionPickBinding.inflate(LayoutInflater.from(themedContext()))
        binding = b

        b.overlay.maskAlpha = 0.58f
        b.overlay.onRegionChanged = { updateInfo(it) }

        val saved = ScanRegionStore.load(this)
        b.overlay.setRelativeRegion(saved)
        updateInfo(saved)

        b.btnCancel.setOnClickListener { finishPick() }
        b.btnReset.setOnClickListener {
            val def = ScanRegionStore.defaultRegion()
            b.overlay.setRelativeRegion(def)
            updateInfo(def)
        }
        b.btnPreview.setOnClickListener { startPreview() }
        b.btnBack.setOnClickListener { backToPick() }
        b.btnApply.setOnClickListener { applyRegion() }
        b.btnPreviewCancel.setOnClickListener { finishPick() }
        // 预览时压暗层吃掉点击，避免误触到下层应用
        b.scrim.setOnClickListener { }

        val size = screenSize()
        params = WindowManager.LayoutParams(
            size[0],
            size[1],
            overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            // 与屏幕左上角严格对齐、尺寸取整屏像素：视图坐标 == 屏幕坐标，
            // 保存的比例才能和截图裁剪严格对应
            gravity = Gravity.TOP or Gravity.START
            x = 0
            y = 0
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                layoutInDisplayCutoutMode =
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
        }

        wm.addView(b.root, params)
        added = true
        isRunning = true
        // 布局完成后校正「窗口坐标 ↔ 屏幕坐标」的偏移，保证保存的比例与截图严格对应
        b.root.post { syncScreenBase() }
    }

    /** 悬浮窗在个别机型上会被状态栏/导航栏挤压，这里把实际偏移与整屏尺寸告诉选择控件 */
    private fun syncScreenBase() {
        val b = binding ?: return
        try {
            val loc = IntArray(2)
            b.root.getLocationOnScreen(loc)
            val size = screenSize()
            // 无条件写入：即使这次偏移为 0，也要把「整屏尺寸」作为基准，
            // 否则会退化成按视图尺寸换算，与截图坐标系差出状态栏那一截
            b.overlay.setScreenBase(loc[0], loc[1], size[0], size[1])
        } catch (_: Throwable) {
            // 忽略：退化为按视图尺寸换算
        }
    }

    private fun updateInfo(rel: RectF) {
        val b = binding ?: return
        val text = regionText(rel)
        b.tvRegionInfo.text = text
        b.tvPreviewInfo.text = "当前范围：$text"
    }

    private fun regionText(rel: RectF): String {
        val left = (rel.left * 100).roundToInt()
        val top = (rel.top * 100).roundToInt()
        val width = ((rel.right - rel.left) * 100).roundToInt()
        val height = ((rel.bottom - rel.top) * 100).roundToInt()
        return "左 $left% · 上 $top% · 宽 $width% · 高 $height%"
    }

    // ---------------- 预览 ----------------

    /**
     * 预览：先把整层浮层隐藏（否则会把遮罩和按钮拍进预览图），
     * 再截屏并按当前范围裁剪，最后把结果放进预览卡。
     * 没有截屏通道时不阻断流程，预览卡里显示占位说明，仍可应用。
     */
    private fun startPreview() {
        val b = binding ?: return
        if (previewing) return
        previewing = true

        val rel = RectF(b.overlay.relativeRegion())
        val id = ++previewRequestId
        var delivered = false

        fun deliver(src: Bitmap?) {
            if (delivered || id != previewRequestId) {
                // 超时兜底已经出过卡片时，迟到的截图直接释放，避免大图泄漏
                try {
                    src?.recycle()
                } catch (_: Throwable) {
                    // 忽略
                }
                return
            }
            delivered = true
            binding?.root?.visibility = View.VISIBLE
            showPreviewCard(src, rel)
        }

        b.root.visibility = View.INVISIBLE

        ui.postDelayed({
            if (id != previewRequestId) return@postDelayed
            if (!ScreenCapture.isReady()) {
                deliver(null)
                return@postDelayed
            }
            try {
                ScreenCapture.capture { bitmap -> ui.post { deliver(bitmap) } }
            } catch (_: Throwable) {
                ui.post { deliver(null) }
            }
        }, 180)

        // 兜底：截屏回调迟迟不来时也要让预览卡出现，不能卡在「看不见的界面」上
        ui.postDelayed({ deliver(null) }, 2600)
    }

    private fun showPreviewCard(src: Bitmap?, rel: RectF) {
        val b = binding ?: return
        b.overlay.visibility = View.GONE
        b.header.visibility = View.GONE
        b.bar.visibility = View.GONE
        b.scrim.visibility = View.VISIBLE
        b.previewCard.visibility = View.VISIBLE

        // 换图前先解除 ImageView 引用，避免回收仍在使用中的 Bitmap
        try {
            b.ivPreview.setImageDrawable(null)
        } catch (_: Throwable) {
            // 忽略
        }
        previewBitmap?.recycle()
        previewBitmap = null

        if (src != null) {
            val cropped = cropByRegion(src, rel)
            if (cropped !== src) {
                try {
                    src.recycle()
                } catch (_: Throwable) {
                    // 忽略
                }
            }
            previewBitmap = cropped
            b.ivPreview.setImageBitmap(cropped)
            b.ivPreview.visibility = View.VISIBLE
            b.tvPreviewEmpty.visibility = View.GONE
            startOcrPreview(cropped)
        } else {
            b.ivPreview.visibility = View.GONE
            b.tvPreviewEmpty.visibility = View.VISIBLE
            b.tvPreviewOcr.visibility = View.GONE
        }
        b.tvPreviewInfo.text = "当前范围：${regionText(rel)}"
    }

    /**
     * 预览里顺带跑一次 OCR，直接告诉用户「框内读到了什么字」。
     * 用副本识别，避免用户点「重新框选」时回收了正在识别的位图。
     */
    private fun startOcrPreview(region: Bitmap) {
        val b = binding ?: return
        val token = previewRequestId
        b.tvPreviewOcr.visibility = View.VISIBLE
        b.tvPreviewOcr.text = "正在识别框内文字…"

        val input = try {
            region.copy(Bitmap.Config.ARGB_8888, false)
        } catch (_: Throwable) {
            null
        } ?: run {
            b.tvPreviewOcr.visibility = View.GONE
            return
        }

        try {
            OcrHelper.recognizeLines(input) { lines ->
                ui.post {
                    try {
                        input.recycle()
                    } catch (_: Throwable) {
                        // 忽略
                    }
                    if (token != previewRequestId || previewing.not()) return@post
                    val card = binding ?: return@post
                    val text = lines.joinToString(" ")
                        .replace(Regex("\\s+"), " ")
                        .trim()
                    card.tvPreviewOcr.visibility = View.VISIBLE
                    card.tvPreviewOcr.text = when {
                        text.isEmpty() -> "框内没读到文字，建议框大一些或避开空白处"
                        text.length > 52 -> "识别预览：${text.take(52)}…"
                        else -> "识别预览：$text"
                    }
                }
            }
        } catch (_: Throwable) {
            b.tvPreviewOcr.visibility = View.GONE
        }
    }

    private fun backToPick() {
        previewRequestId++
        previewing = false
        val b = binding ?: return
        try {
            b.ivPreview.setImageDrawable(null)
        } catch (_: Throwable) {
            // 忽略
        }
        previewBitmap?.recycle()
        previewBitmap = null

        b.previewCard.visibility = View.GONE
        b.scrim.visibility = View.GONE
        b.overlay.visibility = View.VISIBLE
        b.header.visibility = View.VISIBLE
        b.bar.visibility = View.VISIBLE
        b.root.visibility = View.VISIBLE
    }

    private fun applyRegion() {
        val b = binding ?: return
        // overlay 虽然被隐藏，区域数据仍保留，可直接读取
        val rel = RectF(b.overlay.relativeRegion())
        ScanRegionStore.save(this, rel)
        toast("识别区域已应用 · ${regionText(rel)}")
        finishPick()
    }

    private fun finishPick() {
        if (finishing) return
        finishing = true
        previewRequestId++
        stopSelf()
    }

    /** 按当前拖动中的比例裁剪截图（与悬浮窗识别共用同一套换算） */
    private fun cropByRegion(src: Bitmap, rel: RectF): Bitmap =
        try {
            ScreenRegion.crop(src, rel, ScreenRegion.screenSize(this))
        } catch (_: Throwable) {
            src
        }

    // ---------------- 窗口尺寸 / 生命周期 ----------------

    /** 与识别链路共用同一屏幕基准，避免「框选比例」与「截图裁剪」各用一套尺寸 */
    private fun screenSize(): IntArray {
        val p = ScreenRegion.screenSize(this)
        return intArrayOf(p.x, p.y)
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        if (!added) return
        // 旋转后重设窗口尺寸；比例由 RegionOverlayView 自行按新尺寸还原
        ui.post {
            try {
                val size = screenSize()
                params.width = size[0]
                params.height = size[1]
                params.x = 0
                params.y = 0
                binding?.let { wm.updateViewLayout(it.root, params) }
                binding?.root?.post { syncScreenBase() }
            } catch (_: Throwable) {
                // 忽略
            }
        }
    }

    private fun overlayType(): Int =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

    private fun promoteToForeground() {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            if (nm.getNotificationChannel(CHANNEL_ID) == null) {
                nm.createNotificationChannel(
                    NotificationChannel(
                        CHANNEL_ID,
                        "识别区域设置",
                        NotificationManager.IMPORTANCE_LOW
                    ).apply { setShowBadge(false) }
                )
            }
        }

        val openPi = PendingIntent.getActivity(
            this,
            102,
            Intent(this, MainActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            },
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            } else {
                PendingIntent.FLAG_UPDATE_CURRENT
            }
        )

        val notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_menu_edit)
            .setContentTitle("正在设置识别区域")
            .setContentText("拖动四角调整范围，预览确认后应用")
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setContentIntent(openPi)
            .build()

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                startForeground(
                    NOTIFICATION_ID,
                    notification,
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
                )
            } else {
                startForeground(NOTIFICATION_ID, notification)
            }
        } catch (_: Throwable) {
            // 前台化失败不阻断浮层显示
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        isRunning = false
        previewRequestId++

        try {
            binding?.ivPreview?.setImageDrawable(null)
        } catch (_: Throwable) {
            // 忽略
        }
        previewBitmap?.recycle()
        previewBitmap = null

        val b = binding
        if (added && b != null) {
            try {
                wm.removeView(b.root)
            } catch (_: Throwable) {
                // 视图可能已被移除
            }
        }
        added = false
        binding = null

        @Suppress("DEPRECATION")
        try {
            stopForeground(true)
        } catch (_: Throwable) {
            // 忽略
        }

        val callback = onFinish
        onFinish = null
        try {
            callback?.invoke()
        } catch (_: Throwable) {
            // 忽略
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_NOT_STICKY

    override fun onBind(intent: Intent?): IBinder? = null

    private fun toast(msg: String) {
        try {
            Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
        } catch (_: Throwable) {
            // 后台 Toast 受限时忽略
        }
    }
}
