package com.example.quizocr

import android.content.Context

/**
 * 搜题结果的字号（sp）。
 *
 * 只作用于「关联结果」的题目卡片（拍照搜题结果页、识屏搜题悬浮面板），
 * 题库浏览页保持固定字号，避免影响列表密度。
 *
 * 取值为题干的字号，选项与答案在此基础上小 2sp，匹配度徽章小 3sp，
 * 默认 15sp 与改动前的界面完全一致。
 */
object ResultTextSize {

    const val MIN = 12
    const val MAX = 24
    const val DEFAULT = 15

    private const val PREF_NAME = "quizocr_settings"
    private const val KEY_SP = "result_text_sp"

    /** 进程内共享的当前字号，界面直接读取 */
    @Volatile
    var sp: Int = DEFAULT
        private set

    /** 字号变化后需要刷新的列表（拍照结果页、悬浮面板） */
    private val listeners = mutableListOf<() -> Unit>()

    fun load(context: Context) {
        val saved = context
            .getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
            .getInt(KEY_SP, DEFAULT)
        sp = saved.coerceIn(MIN, MAX)
    }

    fun update(context: Context, value: Int) {
        val v = value.coerceIn(MIN, MAX)
        if (v == sp) return
        sp = v
        context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
            .edit()
            .putInt(KEY_SP, v)
            .apply()
        // 已展示的结果立即按新字号重绘
        listeners.toList().forEach { runCatching { it() } }
    }

    fun addListener(listener: () -> Unit) {
        if (!listeners.contains(listener)) listeners.add(listener)
    }

    fun removeListener(listener: () -> Unit) {
        listeners.remove(listener)
    }
}
