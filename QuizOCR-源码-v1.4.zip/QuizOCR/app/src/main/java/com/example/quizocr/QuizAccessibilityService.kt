package com.example.quizocr

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Rect
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.Display
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Toast
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

/**
 * 无障碍服务：按需读取当前界面节点树文字，供悬浮窗匹配题库。
 *
 * 稳定性要点：
 * - **不在事件回调里做全量遍历**，只在点击悬浮球时按需采集一次，避免高频事件拖死主线程；
 * - 采集使用显式栈迭代（深度优先）并限制节点上限，避免超大节点树导致 StackOverflow / ANR。
 *
 * 能力要点（「读不到文字」的根因）：
 * - [onServiceConnected] 中重新赋值 serviceInfo 会整体替换系统登记配置，
 *   必须**显式补齐** CAPABILITY_CAN_RETRIEVE_WINDOW_CONTENT 与
 *   FLAG_RETRIEVE_INTERACTIVE_WINDOWS，否则 rootInActiveWindow 恒为 null。
 *
 * 与「随选朗读」的差异（为什么系统朗读能读、本应用读不到）：
 * - 随选朗读只需要**手指下那一个节点**，节点没字时还有 OCR 兜底，且它是系统服务不受窗口读取限制；
 * - 本应用需要**整棵树的遍历**才能凑出题干，因此会受到节点上限、窗口权限、区域过滤三处影响。
 *   这里逐个放开：遍历改为深度优先（先到叶子文字）、上限提高到 3000、
 *   拿不到窗口时给出可诊断的计数，并在界面不提供位置信息时允许区域过滤失效回退整屏。
 *
 * 区域过滤：用户框选过识别区域后，只采集**落在框内**的节点文字，与截屏 OCR 的区域一致；
 * 未设置区域时采整屏。
 */
class QuizAccessibilityService : AccessibilityService() {

    companion object {
        /**
         * 单次采集的节点上限。
         *
         * 原来是 1200。广度优先在大页面上会先被浅层容器吃满配额，还没走到叶子文字节点就到顶，
         * 表现就是「明明满屏文字却读到 0 字」。改成深度优先 + 3000 上限后，
         * 文字节点在遍历早期就能被收集到。
         */
        private const val MAX_NODES = 3000

        /** 切页面后的静默期：短一些，用户打开新题能尽快看到结果 */
        private const val DEBOUNCE_PAGE_MS = 140L

        /** 内容变化 / 滚动后的静默期：等滚停再采，避免滚动过程中反复识别 */
        private const val DEBOUNCE_CONTENT_MS = 320L

        /** 点击后的静默期：换题往往是「点一下下一题」，给界面一点切换时间 */
        private const val DEBOUNCE_CLICK_MS = 120L
    }

    private val scanHandler = Handler(Looper.getMainLooper())

    /** 采集放到独立线程：遍历 3000 节点要几十毫秒，且 [ScreenTextHolder.capture] 内还有 80ms 重试 */
    private val scanExecutor = Executors.newSingleThreadExecutor { r ->
        Thread(r, "realtime-scan").apply { isDaemon = true }
    }

    /** 同一时刻只允许一次采集，避免事件密集时任务堆积 */
    private val scanBusy = AtomicBoolean(false)

    /** 采集期间又有新的界面变化，结束后需要补采一次 */
    @Volatile
    private var dirty = false

    override fun onServiceConnected() {
        super.onServiceConnected()

        // 不要在这里 new 一个 AccessibilityServiceInfo 再赋值！
        // 那会整体替换系统登记配置，丢掉 CAPABILITY_CAN_RETRIEVE_WINDOW_CONTENT，
        // 导致 rootInActiveWindow 恒为 null。
        //
        // 这里只是**就地补充**事件类型（点击），复用系统给的已有配置，
        // 能力位不受影响；XML 里也声明了同样的类型，二者取并集。
        try {
            val info = serviceInfo
            if (info != null) {
                val wanted = info.eventTypes or AccessibilityEvent.TYPE_VIEW_CLICKED
                if (wanted != info.eventTypes) {
                    info.eventTypes = wanted
                    serviceInfo = info
                }
            }
        } catch (_: Throwable) {
            // 个别 ROM 不允许修改，退回 XML 声明
        }

        ScreenTextHolder.service = this
        // 预热一次，方便首次点击立即有内容
        refreshScreenText()
        Toast.makeText(this, "包哥搜题：无障碍服务已连接", Toast.LENGTH_SHORT).show()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // 实时识屏：只在「开关打开 + 面板正在显示」时工作。
        // 面板收起时 sink 为空，这里直接返回，保证不在后台空跑耗电。
        if (event == null) return
        if (!RealtimeMode.enabled || !RealtimeHub.active) return

        // 本应用自己的界面（悬浮球 / 面板 / 设置页）不触发识别，
        // 否则面板刷新结果 → 内容变化事件 → 再次识别，形成死循环。
        val pkg = try {
            event.packageName?.toString()
        } catch (_: Throwable) {
            null
        }
        if (pkg != null && pkg == packageName) return

        val delay = when (event.eventType) {
            // 切页面 / 窗口变化：用户刚打开题目，尽快给结果
            AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED -> {
                notifyPageChanged()
                DEBOUNCE_PAGE_MS
            }

            AccessibilityEvent.TYPE_WINDOWS_CHANGED -> DEBOUNCE_PAGE_MS

            // 内容变化 / 滚动：滚动过程中事件极密集，等它停下来再采
            AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED,
            AccessibilityEvent.TYPE_VIEW_SCROLLED -> {
                // 滚动视为「画面整体换了一屏」，允许对新画面重新走一次截屏兜底；
                // 内容变化不算（很多页面每秒抛几十次，会把兜底无限推迟）
                if (event.eventType == AccessibilityEvent.TYPE_VIEW_SCROLLED) notifyPageChanged()
                DEBOUNCE_CONTENT_MS
            }

            // 点击：不少题目页换题只是点了「下一题」，既不换窗口也不抛滚动事件，
            // 这里当作换屏信号，尽快重采一次（延迟短，避免点选答案时误判）
            AccessibilityEvent.TYPE_VIEW_CLICKED -> {
                notifyPageChanged()
                DEBOUNCE_CLICK_MS
            }

            else -> return
        }

        scheduleRealtimeScan(delay)
    }

    /** 通知悬浮窗：画面整体换了（切页 / 滚动），上一屏的兜底结论不再适用 */
    private fun notifyPageChanged() {
        try {
            RealtimeHub.sink?.onRealtimePageChanged()
        } catch (_: Throwable) {
            // 回调异常不影响采集
        }
    }

    /** 供悬浮窗在开启实时时主动触发一次采集（面板刚弹出，页面可能还没有任何变化事件） */
    fun requestRealtimeScan() {
        if (!RealtimeMode.enabled) return
        scheduleRealtimeScan(60L)
    }

    /** 采集结束后补采一次（方法体内引用，避免 runnable 初始化期自引用） */
    private fun scheduleFollowUpScan() {
        scanHandler.postDelayed(scanRunnable, DEBOUNCE_CONTENT_MS)
    }

    /** 去抖：每次新事件都把计时重置，只有「安静了 [delay] 毫秒」才真正采集一次 */
    private fun scheduleRealtimeScan(delay: Long) {
        dirty = true
        scanHandler.removeCallbacks(scanRunnable)
        scanHandler.postDelayed(scanRunnable, delay)
    }

    private val scanRunnable: Runnable = Runnable {
        if (!RealtimeMode.enabled || !RealtimeHub.active) return@Runnable
        // 上一次采集还没结束时丢弃本次，避免任务在单线程池里越积越多
        if (!scanBusy.compareAndSet(false, true)) return@Runnable
        dirty = false

        scanExecutor.execute {
            try {
                val text = try {
                    ScreenTextHolder.capture()
                } catch (_: Throwable) {
                    ""
                }
                val sink = RealtimeHub.sink
                if (sink == null) return@execute
                if (text.isBlank()) {
                    sink.onRealtimeEmpty()
                } else {
                    sink.onRealtimeText(text, ScreenTextHolder.lastTextInRegion)
                }
            } finally {
                scanBusy.set(false)
                // 采集期间画面又变了：补一次，保证最终结果对应当前画面
                if (dirty && RealtimeMode.enabled && RealtimeHub.active) {
                    scheduleFollowUpScan()
                }
            }
        }
    }

    override fun onInterrupt() {
        // 无需中断处理
    }

    override fun onUnbind(intent: Intent?): Boolean {
        scanHandler.removeCallbacks(scanRunnable)
        ScreenTextHolder.service = null
        ScreenTextHolder.lastText = ""
        ScreenTextHolder.lastTextInRegion = false
        return super.onUnbind(intent)
    }

    /**
     * 通过无障碍服务自带的截屏能力抓取当前屏幕（Android 11+，**无需录屏授权**）。
     *
     * 用于目标界面不向无障碍暴露文字节点（WebView / Flutter / 游戏自绘）时的兜底：
     * 截屏后交给 ML Kit 做端侧 OCR，再从识别结果里匹配题库。
     *
     * 要求 accessibility_service_config.xml 中声明 android:canTakeScreenshot="true"。
     */
    fun captureScreen(onResult: (Bitmap?) -> Unit) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) {
            // Android 11 以下无此能力
            onResult(null)
            return
        }
        try {
            takeScreenshot(
                Display.DEFAULT_DISPLAY,
                mainExecutor,
                object : TakeScreenshotCallback {
                    override fun onSuccess(screenshot: ScreenshotResult) {
                        val bitmap = try {
                            val hardware = Bitmap.wrapHardwareBuffer(
                                screenshot.hardwareBuffer,
                                screenshot.colorSpace
                            )
                            // 硬件位图 ML Kit 无法直接处理，转为软件位图
                            val soft = hardware?.copy(Bitmap.Config.ARGB_8888, false)
                            hardware?.recycle()
                            soft
                        } catch (_: Throwable) {
                            null
                        } finally {
                            try {
                                screenshot.hardwareBuffer.close()
                            } catch (_: Throwable) {
                                // 忽略
                            }
                        }
                        onResult(bitmap)
                    }

                    override fun onFailure(errorCode: Int) {
                        onResult(null)
                    }
                }
            )
        } catch (_: Throwable) {
            onResult(null)
        }
    }

    /**
     * 采集当前界面文字，并把每一步的计数写入 [ScreenTextHolder.lastStats]。
     *
     * 优先取 rootInActiveWindow；拿不到时退化为遍历所有可交互窗口
     * （悬浮窗存在时，活动窗口有时是系统窗口而非目标应用）。
     *
     * **按框选区域采集**：只保留「中心落在框内」或「一半以上面积在框内」的节点。
     * 但若整个界面所有文字节点都没有屏幕坐标（部分 WebView / 自绘控件如此），
     * 区域过滤根本无法执行，此时退回整屏采集并标注 `regionUnavailable`，
     * 而不是直接返回空串让用户以为「无障碍坏了」。
     */
    fun refreshScreenText() {
        val started = SystemClock.elapsedRealtime()
        val selfPkg = packageName

        var windowCount = 0
        var selfWindows = 0
        val selfIds = HashSet<Int>()
        val roots = mutableListOf<AccessibilityNodeInfo>()

        // ① 活动窗口（最常用、最快）
        try {
            val active = rootInActiveWindow
            if (active != null) {
                if (active.packageName?.toString() != selfPkg) {
                    roots.add(active)
                } else if (selfIds.add(active.windowId)) {
                    selfWindows++
                }
            }
        } catch (_: Throwable) {
            // 忽略，走多窗口兜底
        }

        // ② 所有可交互窗口：活动窗口是本应用悬浮窗、或为 null 时的主要来源
        try {
            windows?.forEach { window ->
                windowCount++
                val root = window.root ?: return@forEach
                if (root.packageName?.toString() == selfPkg) {
                    if (selfIds.add(root.windowId)) selfWindows++
                    return@forEach
                }
                if (roots.none { it.windowId == root.windowId }) roots.add(root)
            }
        } catch (_: Throwable) {
            // 无权限或系统限制时忽略
        }

        val packages = roots.mapNotNull { it.packageName?.toString() }
            .distinct()
            .take(3)
            .joinToString(", ")

        if (roots.isEmpty()) {
            ScreenTextHolder.lastText = ""
            ScreenTextHolder.lastTextInRegion = false
            ScreenTextHolder.lastRegionDesc = ""
            ScreenTextHolder.lastStats = ScreenTextHolder.Stats(
                connected = true,
                windows = windowCount,
                selfWindows = selfWindows,
                elapsedMs = SystemClock.elapsedRealtime() - started
            )
            return
        }

        val rel = try {
            ScreenRegion.effectiveRelative(this)
        } catch (_: Throwable) {
            null
        }
        val region = try {
            rel?.let { ScreenRegion.rectPx(it, ScreenRegion.screenSize(this)) }
        } catch (_: Throwable) {
            null
        }

        val col = collect(roots, region, selfPkg)

        // 界面完全不提供位置信息时，区域过滤没有依据，只能退回整屏
        val regionUnavailable = region != null && col.textNodes > 0 &&
                col.regionTextNodes == 0 && col.textNodesNoBounds == col.textNodes

        val text = when {
            region == null -> col.allText
            regionUnavailable -> col.allText
            else -> col.regionText
        }

        ScreenTextHolder.lastText = text
        ScreenTextHolder.lastTextInRegion = region != null && !regionUnavailable && text.isNotBlank()
        ScreenTextHolder.lastRegionDesc = if (regionUnavailable) "整屏" else ScreenRegion.describe(rel)
        ScreenTextHolder.lastStats = ScreenTextHolder.Stats(
            connected = true,
            windows = windowCount,
            selfWindows = selfWindows,
            roots = roots.size,
            packages = packages,
            nodes = col.nodes,
            textNodes = col.textNodes,
            textNodesNoBounds = col.textNodesNoBounds,
            chars = text.length,
            regionDesc = if (regionUnavailable) "整屏" else ScreenRegion.describe(rel),
            regionTextNodes = col.regionTextNodes,
            regionUnavailable = regionUnavailable,
            truncated = col.truncated,
            elapsedMs = SystemClock.elapsedRealtime() - started
        )
    }

    private class Collected(
        val regionText: String,
        val allText: String,
        val nodes: Int,
        val textNodes: Int,
        val textNodesNoBounds: Int,
        val regionTextNodes: Int,
        val truncated: Boolean
    )

    /**
     * 深度优先遍历节点树，同时产出「区域内文字」和「整屏文字」两份结果。
     *
     * 深度优先是刻意的：广度优先会把配额先花在浅层容器上，层级一多就到顶，
     * 叶子上的文字一个都收不到。深度优先能第一时间下探到文字节点。
     * 两份文本一次遍历同时产出，避免为了回退整屏再走一遍树。
     *
     * [selfPkg] 用于逐节点再排一次本应用文字：现在采集时面板保持可见（不再临时隐藏），
     * 万一某个窗口的 root 包名读不到、没被 activeRoots 挡掉，
     * 面板上的「搜索」「关联题目结果」也不会混进题干。
     */
    private fun collect(
        roots: List<AccessibilityNodeInfo>,
        region: Rect?,
        selfPkg: String
    ): Collected {
        val regionSb = StringBuilder()
        val allSb = StringBuilder()
        var visited = 0
        var textNodes = 0
        var textNodesNoBounds = 0
        var regionTextNodes = 0
        var truncated = false

        val nodeRect = Rect()
        val interRect = Rect()

        for (root in roots) {
            if (visited >= MAX_NODES) {
                truncated = true
                break
            }
            val stack = ArrayDeque<AccessibilityNodeInfo>()
            stack.addLast(root)
            while (stack.isNotEmpty()) {
                if (visited >= MAX_NODES) {
                    truncated = true
                    break
                }
                val node = stack.removeLast()
                visited++
                try {
                    val isSelf = node.packageName?.toString() == selfPkg
                    val text = if (isSelf) null else node.text?.toString()?.takeIf { it.isNotBlank() }
                    val desc = if (isSelf) null else
                        node.contentDescription?.toString()?.takeIf { it.isNotBlank() }

                    if (text != null || desc != null) {
                        textNodes++
                        text?.let { allSb.append(it).append('\n') }
                        desc?.let { allSb.append(it).append('\n') }

                        if (region != null) {
                            node.getBoundsInScreen(nodeRect)
                            val hasArea = nodeRect.width() > 0 && nodeRect.height() > 0
                            if (!hasArea) {
                                textNodesNoBounds++
                            } else if (inRegion(nodeRect, region, interRect)) {
                                regionTextNodes++
                                text?.let { regionSb.append(it).append('\n') }
                                desc?.let { regionSb.append(it).append('\n') }
                            }
                        }
                    }

                    // 子节点逆序入栈，保证遍历顺序与视觉顺序一致（对结果无影响，便于排查）
                    val count = node.childCount
                    for (i in count - 1 downTo 0) {
                        if (visited + stack.size >= MAX_NODES) {
                            truncated = true
                            break
                        }
                        node.getChild(i)?.let { stack.addLast(it) }
                    }
                } catch (_: Throwable) {
                    // 单个节点读取失败不影响整体采集
                }
                // 不调用 recycle()：API 33 起已废弃，重复回收反而会抛异常
            }
        }

        return Collected(
            regionText = regionSb.toString().trim(),
            allText = allSb.toString().trim(),
            nodes = visited,
            textNodes = textNodes,
            textNodesNoBounds = textNodesNoBounds,
            regionTextNodes = regionTextNodes,
            truncated = truncated
        )
    }

    /** 节点中心在框内，或一半以上面积在框内 */
    private fun inRegion(nodeRect: Rect, region: Rect, interRect: Rect): Boolean {
        if (region.contains(nodeRect.centerX(), nodeRect.centerY())) return true
        interRect.set(nodeRect)
        val overlap = interRect.intersect(region)
        val nodeArea = nodeRect.width().toLong() * nodeRect.height()
        return overlap && nodeArea > 0 &&
                interRect.width().toLong() * interRect.height() * 2 >= nodeArea
    }
}
