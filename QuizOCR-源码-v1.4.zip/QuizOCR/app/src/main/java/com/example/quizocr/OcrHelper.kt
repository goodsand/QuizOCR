package com.example.quizocr

import android.graphics.Bitmap
import android.graphics.Color
import com.google.mlkit.vision.common.InputImage
import java.util.concurrent.Executors

/**
 * 截屏 OCR 辅助：把手机屏幕截图交给端侧中文识别模型，按行返回文字。
 *
 * 用于「无障碍读不到文字」的兜底场景（WebView / Flutter / 游戏自绘界面等）。
 * 识别结果按行拆分后逐行匹配题库，比整段文本匹配准确得多。
 *
 * 性能上的三点处理：
 * - **识别器全局复用**（`by lazy`），不重复初始化模型；
 * - **回调放到后台线程**：ML Kit 的 `addOnSuccessListener` 默认回主线程，
 *   解析 textBlocks 的那段代码会占用 UI 线程，这里指定单线程执行器；
 * - **[warmUp]**：首次 `process` 会加载约 10MB 模型（300~800ms），
 *   在悬浮窗/主页启动时预热，避免第一次识屏莫名慢一大截。
 */
object OcrHelper {

    private val recognizer by lazy { TextRecognizerFactory.create(OcrLanguage.CHINESE) }

    /** 结果回调线程：不占主线程 */
    private val callbackExecutor = Executors.newSingleThreadExecutor { r ->
        Thread(r, "ocr-callback").apply { isDaemon = true }
    }

    @Volatile
    private var warmedUp = false

    /**
     * 预热识别模型：跑一张 48×48 的空白图，把模型加载、引擎初始化提前做掉。
     * 幂等，可以在任意时机多次调用。
     */
    fun warmUp() {
        if (warmedUp) return
        warmedUp = true
        Thread({
            try {
                val tiny = Bitmap.createBitmap(48, 48, Bitmap.Config.ARGB_8888)
                tiny.eraseColor(Color.WHITE)
                recognizer.process(InputImage.fromBitmap(tiny, 0))
                    .addOnCompleteListener { tiny.recycle() }
            } catch (_: Throwable) {
                // 预热失败不影响正常识别
            }
        }, "ocr-warmup").apply { isDaemon = true }.start()
    }

    /** 识别整张截图，回调在后台线程执行，调用方需自行切回主线程更新 UI */
    fun recognizeLines(bitmap: Bitmap, onResult: (List<String>) -> Unit) {
        val image = try {
            InputImage.fromBitmap(bitmap, 0)
        } catch (_: Throwable) {
            onResult(emptyList())
            return
        }
        recognizer.process(image)
            .addOnSuccessListener(callbackExecutor) { text ->
                val lines = text.textBlocks
                    .flatMap { it.lines }
                    .map { it.text.trim() }
                    .filter { it.isNotBlank() }
                onResult(lines)
            }
            .addOnFailureListener(callbackExecutor) {
                onResult(emptyList())
            }
    }
}
