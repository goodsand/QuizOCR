package com.example.quizocr

import android.Manifest
import android.accessibilityservice.AccessibilityServiceInfo
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.PorterDuff
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.view.accessibility.AccessibilityManager
import android.widget.ImageView
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SwitchCompat
import androidx.core.content.ContextCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.fragment.app.Fragment
import com.example.quizocr.databinding.ActivityMainBinding
import com.google.android.material.slider.Slider
import kotlin.math.roundToInt

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    /** 因缺少权限跳转到系统设置时置位，返回后自动续启悬浮窗 */
    private var pendingStart = false

    /** 无障碍引导本次会话只弹一次，避免反复打扰 */
    private var guideShown = false

    /** 底部 Dock 的入口视图，key → item 根视图 */
    private val dockViews = LinkedHashMap<String, View>()

    /** 「识屏搜题」上的运行中红点 */
    private var screenDot: View? = null

    /** 当前选中的页面 Tab（动作型入口不改变它） */
    private var currentTab = TAB_BANK

    companion object {
        private const val TAB_BANK = "bank"
        private const val TAB_RECOGNIZE = "recognize"
        private const val TAB_SCREEN = "screen"
        private const val TAB_SETTINGS = "settings"
        private const val TAB_ABOUT = "about"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // 启动时加载已保存的题库、匹配精度、匹配模式与结果字号
        QuestionBankRepository.load(this)
        MatchThreshold.load(this)
        MatchMode.load(this)
        ResultTextSize.load(this)
        RealtimeMode.load(this)

        // 底部悬浮 Dock：题库 / 设置 / 拍照搜题 / 识屏搜题 / 关于
        setupDock()

        // 默认显示题库
        if (savedInstanceState == null) {
            switchTo(BankFragment())
            applyPageTone(dark = false)
        } else {
            // 重建后按实际恢复的页面校正选中态：否则页面上是拍照页，
            // currentTab 却仍是题库，第一次点「拍照搜题」只会切页而不会拍照
            val current = supportFragmentManager.findFragmentById(R.id.fragmentContainer)
            currentTab = if (current is RecognizeFragment) TAB_RECOGNIZE else TAB_BANK
            updateDockSelection()
            applyPageTone(dark = currentTab == TAB_RECOGNIZE)
        }
    }

    override fun onResume() {
        super.onResume()
        // 从「显示在其他应用上层」设置页返回后，若已授权则自动开启悬浮窗
        if (pendingStart && hasOverlayPermission()) {
            pendingStart = false
            startFloatService()
        }
        refreshScreenBadge()
    }

    /** 「识屏搜题」运行中时在悬浮球入口上打一个红点，便于知道悬浮球仍在后台 */
    private fun refreshScreenBadge() {
        screenDot?.visibility = if (FloatWindowService.isRunning) View.VISIBLE else View.GONE
    }

    // ---------------- 底部悬浮 Dock ----------------

    private data class DockSpec(val key: String, val iconRes: Int, val label: String)

    private val dockSpecs = listOf(
        DockSpec(TAB_BANK, R.drawable.ic_nav_bank, "题库"),
        DockSpec(TAB_SETTINGS, R.drawable.ic_nav_settings, "设置"),
        DockSpec(TAB_RECOGNIZE, R.drawable.ic_nav_camera, "拍照搜题"),
        DockSpec(TAB_SCREEN, R.drawable.ic_nav_scan, "识屏搜题"),
        DockSpec(TAB_ABOUT, R.drawable.ic_nav_about, "关于")
    )

    private fun setupDock() {
        dockSpecs.forEach { spec ->
            val item = layoutInflater.inflate(R.layout.item_nav, binding.navItems, false)
            item.findViewById<ImageView>(R.id.ivIcon).setImageResource(spec.iconRes)
            item.findViewById<TextView>(R.id.tvLabel).text = spec.label
            item.setOnClickListener { onDockItemClick(spec.key) }
            binding.navItems.addView(item)
            dockViews[spec.key] = item
            if (spec.key == TAB_SCREEN) screenDot = item.findViewById(R.id.dotBadge)
        }
        updateDockSelection()
    }

    private fun onDockItemClick(key: String) {
        when (key) {
            TAB_BANK -> selectTab(TAB_BANK)
            TAB_RECOGNIZE -> {
                // 已经停在拍照页：再点一次直接拍照，不用再去点页面里的按钮
                if (currentTab == TAB_RECOGNIZE) {
                    // 切页是异步提交的，先落地再取 fragment，避免刚切过来时点到旧页面
                    supportFragmentManager.executePendingTransactions()
                    (supportFragmentManager.findFragmentById(R.id.fragmentContainer)
                            as? RecognizeFragment)?.triggerCapture()
                } else {
                    selectTab(TAB_RECOGNIZE)
                }
            }
            // 动作型入口：执行后仍停留在当前页，不参与选中态
            TAB_SCREEN -> openFloatWindow()
            TAB_SETTINGS -> showSettings()
            TAB_ABOUT -> startActivity(Intent(this@MainActivity, HelpActivity::class.java))
        }
    }

    private fun selectTab(key: String) {
        if (currentTab == key) return
        currentTab = key
        if (key == TAB_RECOGNIZE) {
            switchTo(RecognizeFragment())
            applyPageTone(dark = true)
        } else {
            switchTo(BankFragment())
            applyPageTone(dark = false)
        }
        updateDockSelection()
    }

    /** 选中项：白色图标文字 + 白色 13% 胶囊；未选中：中性灰 */
    private fun updateDockSelection() {
        val onColor = Color.WHITE
        val offColor = Color.parseColor("#8E8E96")
        dockViews.forEach { (key, view) ->
            val selected = key == currentTab
            view.isSelected = selected
            val color = if (selected) onColor else offColor
            view.findViewById<ImageView>(R.id.ivIcon).setColorFilter(color, PorterDuff.Mode.SRC_IN)
            view.findViewById<TextView>(R.id.tvLabel).apply {
                setTextColor(color)
                typeface = Typeface.create(
                    Typeface.DEFAULT,
                    if (selected) Typeface.BOLD else Typeface.NORMAL
                )
            }
        }
    }

    /**
     * 设置面板：识别区域 / 截屏授权 / 无障碍服务，以及平铺三档的匹配精度。
     *
     * 精度直接内嵌为三行单选，点一下即保存，不必再进二级弹窗。
     */
    private fun showSettings() {
        val region = ScanRegionStore.load(this)
        // 未自定义时实际生效的是「整屏」（无障碍与截屏两条通道一致），不能写成「默认」
        val regionDesc = if (ScanRegionStore.isCustomized(this)) {
            val top = (region.top * 100).roundToInt()
            val height = ((region.bottom - region.top) * 100).roundToInt()
            "上 $top% · 高 $height%"
        } else {
            "整屏"
        }
        val captureDesc = when {
            ScreenCaptureService.isReady -> "已授权"
            ScreenCaptureService.persistentUnavailable -> "机型受限"
            !ScreenCaptureService.lastError.isNullOrBlank() -> "未授权"
            else -> "未授权"
        }
        val a11yDesc = if (isAccessibilityServiceEnabled()) "已开启" else "未开启"

        val content = layoutInflater.inflate(R.layout.dialog_settings, null)
        content.findViewById<TextView>(R.id.tvRegionValue).text = regionDesc
        content.findViewById<TextView>(R.id.tvCaptureValue).text = captureDesc
        content.findViewById<TextView>(R.id.tvA11yValue).text = a11yDesc

        val dialog = AlertDialog.Builder(this)
            .setTitle("设置")
            .setView(content)
            .setNegativeButton("关闭", null)
            .create()

        content.findViewById<View>(R.id.rowRegion).setOnClickListener {
            dialog.dismiss()
            openRegionPicker()
        }
        content.findViewById<View>(R.id.rowCapture).setOnClickListener {
            dialog.dismiss()
            requestCapturePermission()
        }
        content.findViewById<View>(R.id.rowA11y).setOnClickListener {
            dialog.dismiss()
            openAccessibilitySettings()
        }

        // 实时识屏开关：与悬浮窗面板上的「实时」按钮共享同一份设置
        val switchRealtime = content.findViewById<SwitchCompat>(R.id.swRealtime)
        switchRealtime.isChecked = RealtimeMode.enabled
        switchRealtime.setOnCheckedChangeListener { _, checked ->
            RealtimeMode.update(this, checked)
            if (checked) toast("实时识屏已开启：点开悬浮面板后，题目界面变化会自动刷新")
        }

        // 匹配精度：0~100% 滑块，拖动即生效
        val slider = content.findViewById<Slider>(R.id.sliderPrecision)
        val valueText = content.findViewById<TextView>(R.id.tvPrecisionValue)
        val initial = MatchThreshold.percent
        valueText.text = "$initial%"
        slider.value = initial.toFloat().coerceIn(slider.valueFrom, slider.valueTo)
        slider.addOnChangeListener { _, value, fromUser ->
            val percent = value.roundToInt()
            valueText.text = "$percent%"
            if (fromUser) MatchThreshold.update(this, percent)
        }

        // 匹配模式：单行 / 多行，点选即生效
        val btnSingle = content.findViewById<TextView>(R.id.btnModeSingle)
        val btnMulti = content.findViewById<TextView>(R.id.btnModeMulti)
        val modeValue = content.findViewById<TextView>(R.id.tvModeValue)

        fun renderMode(mode: MatchMode) {
            val single = mode == MatchMode.SINGLE
            btnSingle.setBackgroundResource(
                if (single) R.drawable.bg_segment_on else R.drawable.bg_segment_off
            )
            btnMulti.setBackgroundResource(
                if (single) R.drawable.bg_segment_off else R.drawable.bg_segment_on
            )
            btnSingle.setTextColor(if (single) 0xFFFFFFFF.toInt() else 0xFF4A4A52.toInt())
            btnMulti.setTextColor(if (single) 0xFF4A4A52.toInt() else 0xFFFFFFFF.toInt())
            modeValue.text = mode.label
        }

        renderMode(MatchMode.current)
        btnSingle.setOnClickListener {
            MatchMode.update(this, MatchMode.SINGLE)
            renderMode(MatchMode.SINGLE)
        }
        btnMulti.setOnClickListener {
            MatchMode.update(this, MatchMode.MULTI)
            renderMode(MatchMode.MULTI)
        }

        // 结果字体大小：12~24sp 滑块，只作用于搜题结果卡片
        val sizeSlider = content.findViewById<Slider>(R.id.sliderResultTextSize)
        val sizeText = content.findViewById<TextView>(R.id.tvResultTextSizeValue)
        val sizeInitial = ResultTextSize.sp
        sizeText.text = "${sizeInitial}sp"
        sizeSlider.value = sizeInitial.toFloat()
            .coerceIn(sizeSlider.valueFrom, sizeSlider.valueTo)
        sizeSlider.addOnChangeListener { _, value, fromUser ->
            val sp = value.roundToInt()
            sizeText.text = "${sp}sp"
            if (fromUser) ResultTextSize.update(this, sp)
        }

        // 悬浮窗运行中才显示关闭入口
        if (FloatWindowService.isRunning) {
            content.findViewById<View>(R.id.dividerClose).visibility = View.VISIBLE
            content.findViewById<View>(R.id.rowCloseFloat).apply {
                visibility = View.VISIBLE
                setOnClickListener {
                    dialog.dismiss()
                    stopService(Intent(this@MainActivity, FloatWindowService::class.java))
                    toast("悬浮窗已关闭")
                    binding.root.postDelayed({ refreshScreenBadge() }, 200)
                }
            }
        }

        // 设置项较多：内容超出时底部提示「上滑查看更多」，滚到底自动消失
        val settingsScroll = content.findViewById<ScrollView>(R.id.settingsScroll)
        val scrollHint = content.findViewById<View>(R.id.scrollHint)
        fun refreshScrollHint() {
            scrollHint.visibility =
                if (settingsScroll.canScrollVertically(1)) View.VISIBLE else View.GONE
        }
        scrollHint.setOnClickListener {
            settingsScroll.smoothScrollBy(0, (settingsScroll.height * 0.8f).toInt())
        }
        // 滚动监听用 ViewTreeObserver，兼容 minSdk 21（View.setOnScrollChangeListener 需要 23）
        settingsScroll.viewTreeObserver.addOnScrollChangedListener { refreshScrollHint() }

        dialog.setOnShowListener {
            // 去掉对话框给自定义内容加的左右内边距，行内 20dp 即为最终缩进
            val host = content.parent as? View ?: return@setOnShowListener
            host.setPadding(0, host.paddingTop, 0, host.paddingBottom)

            // 内容超过屏幕 2/3 就固定高度改为内部滚动，避免把「关闭」按钮顶出屏幕。
            // 用布局回调而不是 post：show() 返回时子视图往往还没完成第一次布局
            val maxHeight = (resources.displayMetrics.heightPixels * 0.70f).toInt()
            settingsScroll.addOnLayoutChangeListener(object : View.OnLayoutChangeListener {
                override fun onLayoutChange(
                    v: View, left: Int, top: Int, right: Int, bottom: Int,
                    oldLeft: Int, oldTop: Int, oldRight: Int, oldBottom: Int
                ) {
                    val childHeight = settingsScroll.getChildAt(0)?.height ?: 0
                    if (childHeight <= 0) return
                    settingsScroll.removeOnLayoutChangeListener(this)
                    if (childHeight > maxHeight) {
                        content.layoutParams = content.layoutParams?.apply { height = maxHeight }
                        content.requestLayout()
                    } else {
                        // 内容本来就装得下：去掉给上滑提示预留的底部留白
                        settingsScroll.setPadding(
                            settingsScroll.paddingLeft,
                            settingsScroll.paddingTop,
                            settingsScroll.paddingRight,
                            0
                        )
                    }
                    settingsScroll.post { refreshScrollHint() }
                }
            })
        }

        dialog.show()
    }

    /** 申请 / 管理 MediaProjection 截屏授权（不依赖无障碍） */
    private fun requestCapturePermission() {
        if (ScreenCaptureService.isReady) {
            AlertDialog.Builder(this)
                .setTitle("截屏权限已授权")
                .setMessage(
                    "当前截屏识别走系统录屏授权（MediaProjection），无需开启无障碍。\n\n" +
                    "点悬浮球即可截屏识别；若要释放授权，可在此停止，或点通知栏的「停止」。"
                )
                .setPositiveButton("停止截屏") { _, _ ->
                    ScreenCaptureService.stop(this)
                    toast("截屏授权已释放")
                }
                .setNegativeButton("知道了", null)
                .show()
            return
        }

        // 该机型授权后会被系统立即终止：不再无谓地弹一次授权框，先给出可行方案
        if (ScreenCaptureService.persistentUnavailable) {
            AlertDialog.Builder(this)
                .setTitle("该机型限制持续截屏")
                .setMessage(
                    "系统在你授权后立即终止了截屏会话，这通常是机型的「持续录屏」限制，App 无法绕过。\n\n" +
                    "建议改用无障碍：开启后可直接截屏识别，不受该限制影响，也不需要每次授权。"
                )
                .setPositiveButton("开启无障碍") { _, _ -> openAccessibilitySettings() }
                .setNeutralButton("仍要重试") { _, _ ->
                    ScreenCaptureService.clearUnavailableFlag()
                    startCapturePermission()
                }
                .setNegativeButton("取消", null)
                .show()
            return
        }

        startCapturePermission()
    }

    private fun startCapturePermission() {
        try {
            startActivity(Intent(this, CapturePermissionActivity::class.java))
        } catch (t: Throwable) {
            toast("无法打开截屏授权：${t.javaClass.simpleName}")
        }
    }

    private fun openAccessibilitySettings() {
        try {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        } catch (_: Throwable) {
            toast("无法打开无障碍设置，请手动前往 设置 → 无障碍")
        }
    }

    /**
     * 主界面设置识别区域。
     *
     * 优先用悬浮窗框选（「显示在其他应用上层」已授权时）：选择框直接叠在真实屏幕上，
     * 框内可见真实画面；调好后先预览、再应用。
     *
     * 没有悬浮窗权限时回退到旧的全屏框选页（截底图，无权限也能按比例设置）。
     *
     * 保存后对**无障碍文字采集**与**截屏 OCR**同时生效。
     */
    private fun openRegionPicker() {
        // 主界面进入时不涉及小球，先清掉悬浮窗服务可能残留的恢复回调
        RegionPickService.onFinish = null
        if (RegionPickService.start(this)) {
            toast("已开启框选浮层，可先切到题目界面，再拖动四角调整")
            return
        }
        if (!ScreenCapture.isReady()) {
            CaptureHolder.bitmap = null
            launchRegionPicker()
            return
        }
        toast("正在截取当前屏幕作底图…")
        ScreenCapture.capture { bitmap ->
            CaptureHolder.bitmap = bitmap
            if (isFinishing || isDestroyed) return@capture
            if (bitmap == null) toast("截屏不可用，将以示意模式设置区域")
            launchRegionPicker()
        }
    }

    private fun launchRegionPicker() {
        try {
            startActivity(Intent(this, RegionPickerActivity::class.java))
        } catch (t: Throwable) {
            toast("无法打开区域设置：${t.javaClass.simpleName}")
        }
    }

    /**
     * 开启悬浮窗。
     *
     * 注意：无障碍服务是否开启**不再作为启动前置条件**——小球只依赖悬浮窗权限，
     * 无障碍仅影响「点击小球能否读到文字」。这样先保证小球能显示，问题定位也更清晰。
     */
    private fun openFloatWindow() {
        if (FloatWindowService.isRunning) {
            AlertDialog.Builder(this)
                .setTitle("识屏搜题运行中")
                .setMessage(
                    "屏幕上已有红色「识」小球：\n\n" +
                    "· 点击小球 → 识别屏幕文字并匹配题库\n" +
                    "· 长按小球 → 收起结果面板\n" +
                    "· 拖动小球 → 移到不遮挡的位置"
                )
                .setPositiveButton("关闭悬浮窗") { _, _ ->
                    stopService(Intent(this, FloatWindowService::class.java))
                    toast("悬浮窗已关闭")
                    binding.root.postDelayed({ refreshScreenBadge() }, 200)
                }
                .setNegativeButton("知道了", null)
                .show()
            return
        }

        if (!hasOverlayPermission()) {
            pendingStart = true
            toast("请允许「显示在其他应用上层」，授权后返回会自动开启悬浮窗")
            try {
                startActivity(
                    Intent(
                        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")
                    )
                )
            } catch (_: Throwable) {
                try {
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION))
                } catch (_: Throwable) {
                    toast("无法打开悬浮窗权限设置页，请手动到「设置 → 应用 → 特殊权限」中开启")
                }
            }
            return
        }

        startFloatService()
    }

    private fun startFloatService() {
        if (FloatWindowService.isRunning) return

        // Android 13+ 前台服务通知需要通知权限；未授予也不影响服务运行，仅通知不显示
        ensureNotificationPermission()

        try {
            startService(Intent(this, FloatWindowService::class.java))
        } catch (t: Throwable) {
            toast("悬浮窗启动失败：${t.message ?: t.javaClass.simpleName}")
            return
        }

        // 服务启动是异步的，稍后确认小球是否真的显示出来
        binding.root.postDelayed({
            if (isFinishing || isDestroyed) return@postDelayed
            if (FloatWindowService.isRunning) {
                toast("悬浮窗已开启：屏幕上出现红色「识」小球")
                refreshScreenBadge()
                // 没有任何截屏通道时，引导选择识别方式（截屏授权 或 无障碍）
                if (!ScreenCapture.isReady()) {
                    showCaptureGuide()
                }
            } else {
                toast("悬浮球未能显示，请确认「显示在其他应用上层」已允许，且未安装旧版本")
            }
        }, 800)
    }

    private fun hasOverlayPermission(): Boolean =
        Build.VERSION.SDK_INT < Build.VERSION_CODES.M || Settings.canDrawOverlays(this)

    private fun ensureNotificationPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val granted = ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
            if (!granted) {
                try {
                    requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1001)
                } catch (_: Throwable) {
                    // 忽略：未授予时前台服务仍可运行
                }
            }
        }
    }

    /** 首次开启悬浮窗时引导选择识别方式（推荐截屏授权，无需无障碍） */
    private fun showCaptureGuide() {
        if (guideShown || isFinishing) return
        guideShown = true

        AlertDialog.Builder(this)
            .setTitle("选择识别方式（任选其一）")
            .setMessage(
                "悬浮球已显示。读取屏幕内容有两种方式：\n\n" +
                "① 授予截屏权限（推荐）：无需开启无障碍。基于系统录屏授权，网页、视频、游戏画面里的文字都能识别。\n\n" +
                "② 开启无障碍服务：无需授权，但只能读取界面上「可被无障碍识别」的文字，图片里的字读不到。\n\n" +
                "之后随时可在底部「设置」里切换或释放授权。"
            )
            .setPositiveButton("授予截屏权限") { _, _ ->
                try {
                    startActivity(Intent(this, CapturePermissionActivity::class.java))
                } catch (t: Throwable) {
                    toast("无法打开截屏授权：${t.javaClass.simpleName}")
                }
            }
            .setNeutralButton("开启无障碍") { _, _ -> openAccessibilitySettings() }
            .setNegativeButton("稍后", null)
            .show()
    }

    /** 判断本应用的无障碍服务是否已在系统中启用（两种方式任一命中即视为已启用） */
    private fun isAccessibilityServiceEnabled(): Boolean {
        val target = "$packageName/${QuizAccessibilityService::class.java.name}"

        val enabled = Settings.Secure.getString(
            contentResolver,
            Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        )
        if (enabled != null && enabled.split(':').any { it.equals(target, ignoreCase = true) }) {
            return true
        }

        val am = getSystemService(ACCESSIBILITY_SERVICE) as AccessibilityManager
        return am.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_ALL_MASK)
            .any { info ->
                val si = info.resolveInfo.serviceInfo
                "${si.packageName}/${si.name}" == target
            }
    }

    private fun switchTo(fragment: Fragment) {
        // 同一页面重复切换时保留现场（避免重建、回到顶部）
        val current = supportFragmentManager.findFragmentById(R.id.fragmentContainer)
        if (current != null && current.javaClass == fragment.javaClass) return
        supportFragmentManager.beginTransaction()
            .replace(R.id.fragmentContainer, fragment)
            .commit()
    }

    /**
     * 页面底色与状态栏跟随当前页面：
     * 题库页浅灰底 + 深色图标，拍照页纯黑底 + 白色图标。
     * Dock 四周的留白靠根布局底色透出，因此一并切换。
     */
    private fun applyPageTone(dark: Boolean) {
        try {
            val tone = if (dark) Color.BLACK else Color.parseColor("#F5F5F5")
            binding.root.setBackgroundColor(tone)
            window.statusBarColor = tone
            WindowInsetsControllerCompat(window, window.decorView)
                .isAppearanceLightStatusBars = !dark
        } catch (_: Throwable) {
            // 配色失败不影响功能
        }
    }

    private fun toast(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
    }
}
