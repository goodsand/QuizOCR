package com.example.quizocr

import android.content.Context
import android.net.Uri
import org.xmlpull.v1.XmlPullParser
import org.xmlpull.v1.XmlPullParserFactory
import java.io.ByteArrayInputStream
import java.io.InputStream
import java.util.zip.ZipInputStream

/**
 * 轻量 XLSX 读取器（不依赖 Apache POI）。
 *
 * XLSX 本质是一个 ZIP 包：
 * - xl/sharedStrings.xml 存放共享字符串表（单元格文字在此索引）
 * - xl/worksheets/sheetN.xml 存放单元格数据
 * 这里用系统自带的 XmlPullParser 直接解析，体积小、兼容性好。
 *
 * 仅读取第一个工作表，返回按行组织的二维字符串列表。
 */
object XlsxReader {

    fun read(context: Context, uri: Uri): List<List<String>> {
        context.contentResolver.openInputStream(uri)?.use { input ->
            return parse(input)
        }
        return emptyList()
    }

    private fun parse(input: InputStream): List<List<String>> {
        val factory = XmlPullParserFactory.newInstance().apply { isNamespaceAware = true }

        // 先把整个 ZIP 读入内存（按条目名缓存字节），避免条目顺序导致解析错位。
        // 许多 XLSX 中 sheetN.xml 排在 sharedStrings.xml 之前，若边遍历边解析会因
        // 共享字符串表尚未就绪而把所有文字单元格读成空串。
        val entries = mutableMapOf<String, ByteArray>()
        val zip = ZipInputStream(input)
        var entry = zip.nextEntry
        while (entry != null) {
            entries[entry.name] = zip.readBytes()
            zip.closeEntry()
            entry = zip.nextEntry
        }
        zip.close()

        val sharedStrings = entries["xl/sharedStrings.xml"]
            ?.let { parseSharedStrings(ByteArrayInputStream(it), factory) }
            ?: emptyList()

        val sheetName = entries.keys.firstOrNull { name ->
            name.startsWith("xl/worksheets/sheet") && name.endsWith(".xml")
        } ?: return emptyList()

        return parseSheet(ByteArrayInputStream(entries[sheetName]!!), factory, sharedStrings)
    }

    private fun parseSharedStrings(stream: InputStream, factory: XmlPullParserFactory): List<String> {
        val parser = factory.newPullParser()
        parser.setInput(stream, "UTF-8")
        val strings = mutableListOf<String>()
        val buf = StringBuilder()
        var inSi = false
        var inT = false
        var event = parser.next()
        while (event != XmlPullParser.END_DOCUMENT) {
            when (event) {
                XmlPullParser.START_TAG -> when (parser.name) {
                    "si" -> { inSi = true; buf.clear() }
                    "t" -> if (inSi) inT = true
                }
                XmlPullParser.TEXT -> if (inT) buf.append(parser.text)
                XmlPullParser.END_TAG -> when (parser.name) {
                    "t" -> inT = false
                    "si" -> { strings.add(buf.toString()); inSi = false; buf.clear() }
                }
            }
            event = parser.next()
        }
        return strings
    }

    private fun parseSheet(
        stream: InputStream,
        factory: XmlPullParserFactory,
        sharedStrings: List<String>
    ): List<List<String>> {
        val parser = factory.newPullParser()
        parser.setInput(stream, "UTF-8")
        val rows = mutableListOf<List<String>>()
        var currentRow = mutableListOf<String>()
        var maxCol = -1
        var cellRef: String? = null
        var cellType: String? = null
        var inV = false
        var inIs = false
        var inT = false
        val buf = StringBuilder()
        var event = parser.next()
        while (event != XmlPullParser.END_DOCUMENT) {
            when (event) {
                XmlPullParser.START_TAG -> when (parser.name) {
                    "row" -> { currentRow = mutableListOf(); maxCol = -1 }
                    "c" -> {
                        cellRef = parser.getAttributeValue(null, "r")
                        cellType = parser.getAttributeValue(null, "t")
                        buf.clear(); inV = false; inIs = false; inT = false
                    }
                    "v" -> inV = true
                    "is" -> inIs = true
                    "t" -> if (inIs) inT = true
                }
                XmlPullParser.TEXT -> if (inV || (inIs && inT)) buf.append(parser.text)
                XmlPullParser.END_TAG -> when (parser.name) {
                    "v" -> inV = false
                    "t" -> inT = false
                    "is" -> inIs = false
                    "c" -> {
                        val col = colIndex(cellRef ?: "")
                        if (col >= 0) {
                            val value = when (cellType) {
                                "s" -> {
                                    val idx = buf.toString().toIntOrNull() ?: -1
                                    sharedStrings.getOrNull(idx).orEmpty()
                                }
                                else -> buf.toString() // 数字或内联字符串
                            }
                            while (currentRow.size <= col) currentRow.add("")
                            currentRow[col] = value
                            if (col > maxCol) maxCol = col
                        }
                    }
                    "row" -> {
                        while (currentRow.size <= maxCol) currentRow.add("")
                        rows.add(currentRow.toList())
                    }
                }
            }
            event = parser.next()
        }
        return rows
    }

    /** 将单元格引用（如 "AB12"）中的列字母转换为从 0 开始的列索引 */
    private fun colIndex(ref: String): Int {
        var idx = 0
        for (ch in ref) {
            if (ch in 'A'..'Z' || ch in 'a'..'z') {
                idx = idx * 26 + (ch.uppercaseChar() - 'A' + 1)
            } else break
        }
        return idx - 1
    }
}
