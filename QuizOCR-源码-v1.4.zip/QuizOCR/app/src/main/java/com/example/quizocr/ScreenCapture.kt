package com.example.quizocr

import android.graphics.Bitmap
import android.os.Build

/**
 * 截屏统一入口，按可用性自动选择通道：
 *
 * 1. **无障碍 takeScreenshot**（Android 11+）—— 走无障碍能力，不建立录屏会话，
 *    因此不会触发部分 ROM 的「限制持续录屏」策略被立刻终止；无障碍已开启时优先使用；
 * 2. **MediaProjection**（`ScreenCaptureService`）—— 不依赖无障碍，适用面最广
 *    （含 WebView / Flutter / 游戏画面），但个别机型会限制持续投影。
 *
 * 调用方只管拿 Bitmap，不需要关心走的是哪条通道。
 */
object ScreenCapture {

    /** 当前是否有可直接使用的截屏通道 */
    fun isReady(): Boolean =
        (ScreenTextHolder.isConnected && Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) ||
            ScreenCaptureService.isReady

    /**
     * 截取当前屏幕。
     * 无任何可用通道时会回调 null，调用方据此提示用户授权。
     */
    fun capture(callback: (Bitmap?) -> Unit) {
        // 优先无障碍截屏：不建立录屏会话，不会被「持续录屏」类限制终止
        if (ScreenTextHolder.isConnected && Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            ScreenTextHolder.captureScreenshot { bitmap ->
                if (bitmap != null) {
                    callback(bitmap)
                } else if (!ScreenCaptureService.capture(callback)) {
                    // 无障碍截屏失败且没有可用会话时才返回 null
                    callback(null)
                }
            }
            return
        }

        if (ScreenCaptureService.capture(callback)) return
        callback(null)
    }
}
